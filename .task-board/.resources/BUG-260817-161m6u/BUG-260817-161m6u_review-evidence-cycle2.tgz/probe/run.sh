#!/bin/bash
set -u
ROOT="/Users/alexis/src/relux-works/relux-agents-infra/.temp/BUG-260817-161m6u/cycle2/probe"
PROJECT="$ROOT/project"
PHOME="$ROOT/home"
PIASSET="/Users/alexis/src/relux-works/relux-agents-infra/.temp/TASK-260817-2h8hn4/pi-standalone-darwin-arm64-0.84.2/pi"
rm -rf "$PROJECT" "$PHOME"
mkdir -p "$PROJECT/.agents/.configs" "$PHOME"
cat > "$PROJECT/.agents/.configs/project-config.toml" <<'TOML'
[agents.pi.primary_session]
profile = "probe"
pi_compatibility = "github-release:earendil-works/pi@v0.84.2:darwin-arm64#sha256-c996e888b7f7dce44bcf24f69176ac646c44139d3916bd49a6b28e5a8c5e3a65"

[agents.pi.profiles."probe"]
provider = "local-provider"
model = "Model"
base_url = "http://127.0.0.1:18099/v1"
api = "openai-completions"
reasoning = false
input = ["text"]
context_window = 8192
max_tokens = 1024
thinking = "off"
requested_capabilities = ["text", "tools"]

[agents.pi.profiles."probe".compat]
supports_developer_role = false
supports_reasoning_effort = false
supports_usage_in_streaming = true
supports_finish_reason = true
max_tokens_field = "max_tokens"

[agents.pi.profiles."probe".runtime]
executable = "/bin/echo"
argv = ["serve", "--model", "Model", "--host", "127.0.0.1", "--port", "18099"]
readiness_path = "/models"
startup_timeout_seconds = 5
shutdown_timeout_seconds = 2
TOML

probe() {
  local label="$1"; shift
  rm -rf "$PHOME"; mkdir -p "$PHOME"
  ( cd "$PROJECT" && env -i HOME="$PHOME" PATH="$PIASSET:/usr/bin:/bin" TERM=dumb "$@" /Users/alexis/.local/bin/pi-infra --version ) \
    > "$ROOT/$label.out" 2> "$ROOT/$label.err"
  local code=$?
  echo "### $label exit=$code"
  echo "--- stderr:"; cat "$ROOT/$label.err"
  echo "--- state after run (HOME tree):"; find "$PHOME" -mindepth 1 | head -20
  echo
}

probe control
probe llama_model   env LLAMA_ARG_MODEL=SECRETMODELPATH42
probe llama_ctx     env LLAMA_ARG_CTX_SIZE=SECRETCTX99
probe llama_lower   env llama_arg_model=SECRETLOWER77
probe dyld_control  env DYLD_INSERT_LIBRARIES=SECRETDYLD11
