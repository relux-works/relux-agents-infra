#!/bin/bash
set -u
ROOT="/Users/alexis/src/relux-works/relux-agents-infra/.temp/BUG-260817-161m6u/cycle2/probe"
PROJECT="$ROOT/project"
PHOME="$ROOT/home2"
PIASSET="/Users/alexis/src/relux-works/relux-agents-infra/.temp/TASK-260817-2h8hn4/pi-standalone-darwin-arm64-0.84.2/pi"
probe() {
  local label="$1"; shift
  rm -rf "$PHOME"; mkdir -p "$PHOME/Library/Caches"
  ( cd "$PROJECT" && env -i HOME="$PHOME" PATH="$PIASSET:/usr/bin:/bin" TERM=dumb "$@" /Users/alexis/.local/bin/pi-infra --version ) \
    > "$ROOT/$label.out" 2> "$ROOT/$label.err"
  local code=$?
  echo "### $label exit=$code"
  echo "--- stderr (head):"; head -4 "$ROOT/$label.err"
  echo "--- managed state under HOME:"; find "$PHOME/Library" -mindepth 1 -maxdepth 5 | head -12
  echo "--- secret leak check:"; grep -c "SECRET" "$ROOT/$label.out" "$ROOT/$label.err"
  echo
}
probe control2
probe llama_model2 env LLAMA_ARG_MODEL=SECRETMODELPATH42
probe llama_ctx2   env LLAMA_ARG_CTX_SIZE=SECRETCTX99
