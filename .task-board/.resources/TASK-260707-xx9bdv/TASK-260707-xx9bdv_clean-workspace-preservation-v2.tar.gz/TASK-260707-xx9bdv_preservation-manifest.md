# TASK-260707-xx9bdv preservation manifest (clean-workspace rework)

## Exact preservation claim

This artifact preserves exactly these removed materials:

1. The one project-specific global workflow bullet removed from the source
   module, in the full pre-removal file
   `preserved-removed-material/source-INSTRUCTIONS_WORKFLOW.before.md`.
2. The same one workflow bullet from the installed global module, in the full
   pre-removal file
   `preserved-removed-material/installed-INSTRUCTIONS_WORKFLOW.before.md`.
3. The four stale project-local instruction files that had been installed in
   the global runtime and were removed from that runtime:
   - `preserved-removed-material/AGENTS.project.md`
   - `preserved-removed-material/INSTRUCTIONS_IOS_SWIFT_PACKAGES.md`
   - `preserved-removed-material/INSTRUCTIONS_PROJECT_LOCAL.md`
   - `preserved-removed-material/INSTRUCTIONS_RELUX_MODULES.md`

The four files are preserved in full, so every x-platform-airdrop,
Tap2Cash, Swipe2Cash, XPAirDrop, and S2C passage they contained remains
recoverable for later project-local placement. This manifest does not claim
that every line in those four files was previously part of the versioned
global source tree.

The exact removed global workflow bullet is:

> * For `/Users/alexis/src/x-platform-airdrop` Tap2Cash BLE pairing/messaging performance work, record durable findings and fixes in `docs/tap2cash-ble-messaging-kb.md` and link the relevant `.task-board/...` outcome artifact. Raw role-swap logs stay in `.temp/`.

## Supporting snapshots

- `current-source-pre-refresh/` is the complete current source instruction tree
  before this refresh.
- `installed-global-pre-refresh/` is the complete installed global instruction
  tree moved out of `~/.agents/.instructions` immediately before refresh.
- `installed-global-post-refresh/` is the complete installed instruction tree
  after refresh.
- `rendered-pre-refresh/` and `rendered-post-refresh/` preserve the Codex and
  Claude rendered entrypoints around the refresh.
- `source-INSTRUCTIONS_WORKFLOW.removal.diff` and
  `installed-INSTRUCTIONS_WORKFLOW.removal.diff` show the preserved workflow
  snapshots against the current source and refreshed installed modules. Each
  diff command exited 1 because a diff was present; this is expected artifact
  generation, not a passing gate.
- `TASK-260707-xx9bdv_prior-corrected-preservation.tar.gz` is the previously
  attached corrected preservation bundle, retained unchanged for provenance.

## Provenance

- Clean Story workspace: `STORY-260830-3uerxs`
- Workspace branch: `task-board/story/STORY-260830-3uerxs`
- Workspace HEAD before work: `71230fc187e6b11eb9aea5520616b20967e223e3`
- Source removal commit: `d1c8d7d5649c37df394d3401101a9650491b4893`
- Introduction commit for the removed global workflow rule:
  `04bc7e8ac7539f9f721faca8609a8c3f8985d1ad`
- Prior corrected bundle SHA-256:
  `2611265e4fb08d9c5e4707235106269a484350bc75ae5567b687c211c91a0d4c`

No file from the old Story worktree was read or copied. The historical inputs
came only from Git history and task-board-owned outcome resources.

## Preserved-file SHA-256

| File | SHA-256 |
| --- | --- |
| `AGENTS.project.md` | `062070f743fd9f96c5010b6c7a1026b1d80d6080c07383a84be2f622b284c2bb` |
| `INSTRUCTIONS_IOS_SWIFT_PACKAGES.md` | `2a3145c7741905e7924091d8cf796b163889851265c90b14203fa33813f1aecf` |
| `INSTRUCTIONS_PROJECT_LOCAL.md` | `643f071042d0329f002eb8afcac8a640748635db3e5f818d5a680c76e0eb71c3` |
| `INSTRUCTIONS_RELUX_MODULES.md` | `13c20ab5bc38dab41569d7f8be943bf2c7ad8bcdb964fb9eff06646f12dcc1e9` |
| `installed-INSTRUCTIONS_WORKFLOW.before.md` | `460143b7be00c0a6a5833934f613cedd261c8295e7bc5689c93333ea0e04d311` |
| `source-INSTRUCTIONS_WORKFLOW.before.md` | `460143b7be00c0a6a5833934f613cedd261c8295e7bc5689c93333ea0e04d311` |

