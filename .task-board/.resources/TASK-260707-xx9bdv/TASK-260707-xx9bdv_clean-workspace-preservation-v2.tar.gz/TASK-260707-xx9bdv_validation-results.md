# TASK-260707-xx9bdv validation results (clean-workspace rework)

Validation revision: `71230fc187e6b11eb9aea5520616b20967e223e3`

## Runtime refresh

- `agents-infra setup global --source-dir <clean Story workspace>`: exit 0.
- `agents-infra verify global`: exit 0.
- `agents-infra doctor global`: exit 0.
- The previous `~/.agents/.instructions` directory was moved intact to
  `installed-global-pre-refresh/`; the path was absent before setup recreated
  it.

## Negative alias gates

- Strict alias refusal across `.instructions`, `~/.agents/.instructions`,
  `~/.codex/AGENTS.md`, and `~/.claude/CLAUDE.md`: exit 0. The gate fails if
  `x-platform-airdrop`, `Tap2Cash`, `Swipe2Cash`, `XPAirDrop`, or `T2C` is
  found and distinguishes ripgrep no-match (1) from read/error (>1).
- Separator/case-flexible refusal across the same four production surfaces:
  exit 0. The gate additionally rejects flexible `airdrop`, `tap...cash`, and
  `swipe...cash` shapes.
- `diff -qr .instructions ~/.agents/.instructions`: exit 0.

## Preservation gates

- Both pre-removal workflow snapshots contain the exact removed global bullet.
- The four stale project-local files are present in full and have the SHA-256
  values recorded in `TASK-260707-xx9bdv_preservation-manifest.md`.
- The source and installed before snapshots are byte-identical.
- Source and installed removal-diff generation each exited 1, truthfully
  indicating a diff was written.

## Repository validation

- `go test ./... -count=1`: exit 0.
  - root package: `136.714s`
  - `internal/attachments`: `1.829s`
  - `internal/infra`: `296.125s`
  - `internal/modelharness`: `1.567s`
  - `cmd/model-harness`: no test files
- `go vet ./...`: exit 0.
- `go build ./...`: exit 0.
- `gofmt -l .` empty-output assertion: exit 0.
- `git diff --check`: exit 0.
- Final `git status --short --branch`: clean; no tracked or untracked
  non-ignored repository delta.

The first `go test` invocation exceeded the initial 30-second tool yield, and
its session identifier was not retained by the wrapper. Its exit was therefore
treated as unknown and was not counted. The directly observed rerun above was
followed through terminal exit 0 and is the reported test evidence.

## Workspace freshness context

The workspace was clean and exactly equal to `origin/main` at
`71230fc187e6b11eb9aea5520616b20967e223e3` when the run started. During the
test suite, `origin/main` advanced by two commits (`9679941`, `3295c7d`) that
changed only `README.md` and `tools/agents-infra/internal/infra/infra_test.go`.
The managed Story branch was not rebased, merged, or switched, as required by
the workspace contract. A read-only strict alias gate against
`origin/main:.instructions` also exited 0 with no forbidden aliases.

## Readiness probe corrections

- Initial `task-board version` was an unsupported spelling; the corrected
  `task-board -v` probe exited 0 and reported version `0.24.3-167-g42c7d2b7`.
- The first broad ripgrep probe included a missing project-local `.agents`
  path and exited 2; it was not counted. All reported negative gates use only
  resolved production paths and distinguish no-match from read failure.
- The first archive extraction/checksum attempt named its not-yet-created
  directory as the process working directory, so process creation failed before
  any command ran. The directory was then created from the repository root;
  archive extraction exited 0 and all six internal checksum checks exited 0.

## Artifact validation

- Archive: `TASK-260707-xx9bdv_clean-workspace-preservation-v2.tar.gz`
- The final archive size and SHA-256 are intentionally recorded in the
  separately attached board outcome, not inside the archive itself.
- `tar -tzf`: exit 0.
- Fresh extraction: exit 0.
- Extracted `shasum -a 256 -c SHA256SUMS`: exit 0 for all six claimed
  preserved files.
