# TASK-260707-xx9bdv Global Instruction Reset Artifact

This task-scoped bundle preserves the source and installed instruction state
used to remove project-specific x-platform-airdrop/Tap2Cash material from the
global relux-agents-infra runtime.

## Preserved source evidence

- `alexis-agents-infra-worktree.diff` captures the source worktree before the
  project-specific workflow rule was removed.
- `alexis-agents-infra-worktree.after-source-cleanup.diff` captures the source
  worktree after the removal.
- `source-INSTRUCTIONS_WORKFLOW.before.md` preserves the complete source
  workflow module containing the removed Tap2Cash BLE knowledge-base rule.
- `infra-untracked-files/` preserves the source files that were untracked at
  the original cleanup checkpoint.

## Preserved installed evidence

- `global-installed-INSTRUCTIONS_WORKFLOW.before.md` preserves the installed
  global workflow module before cleanup.
- `installed-global-removed-before-refresh/` is the exact installed global
  instruction tree moved out of `~/.agents/.instructions` immediately before
  the 2026-08-30 refresh.
- `installed-global-after-refresh/` is the instruction tree produced by that
  refresh.
- `rendered-codex-AGENTS.after-refresh.md` and
  `rendered-claude-CLAUDE.after-refresh.md` preserve the rendered delivery
  surfaces after refresh.

## Recovered project-local files

The earlier task summary named the following four stale installed files but
did not actually preserve their bytes. This rework copied their recoverable
project-local originals from
`/Users/alexis/src/x-platform-airdrop/.agents/.instructions`:

- `global-extra-AGENTS.project.md` — SHA-256
  `062070f743fd9f96c5010b6c7a1026b1d80d6080c07383a84be2f622b284c2bb`
- `global-extra-INSTRUCTIONS_IOS_SWIFT_PACKAGES.md` — SHA-256
  `2a3145c7741905e7924091d8cf796b163889851265c90b14203fa33813f1aecf`
- `global-extra-INSTRUCTIONS_PROJECT_LOCAL.md` — SHA-256
  `643f071042d0329f002eb8afcac8a640748635db3e5f818d5a680c76e0eb71c3`
- `global-extra-INSTRUCTIONS_RELUX_MODULES.md` — SHA-256
  `13c20ab5bc38dab41569d7f8be943bf2c7ad8bcdb964fb9eff06646f12dcc1e9`

`SHA256SUMS` covers every other regular file in this bundle at the time the
manifest was generated. The manifest itself is intentionally excluded.

## Refresh and verification context

- Story worktree HEAD: `cf21665dde35274cc14e66e26a93574e0c18c15c`
- The worktree was 63 commits behind local `main` and carried unrelated dirty
  Story changes; this task did not modify or stage those paths.
- `agents-infra setup global --source-dir "$PWD"` rebuilt the installed global
  runtime after the exact installed instruction directory was moved into this
  bundle.
- `agents-infra verify global` and `agents-infra doctor global` exited 0.
- Strict and separator/case-flexible negative searches found no
  x-platform-airdrop, Tap2Cash, Swipe2Cash, XPAirDrop, or T2C aliases in the
  source module tree, installed module tree, rendered Codex file, or rendered
  Claude file.

