# AGENTS.md

# Global Instructions

This document loads all instruction modules automatically.

## Modules

@~/.agents/.instructions/INSTRUCTIONS_PLATFORM.md
@~/.agents/.instructions/INSTRUCTIONS_STRUCTURE.md
@~/.agents/.instructions/INSTRUCTIONS_ATTACHMENTS.md
@~/.agents/.instructions/INSTRUCTIONS_TOOLS.md
@~/.agents/.instructions/INSTRUCTIONS_SKILLS.md
@~/.agents/.instructions/INSTRUCTIONS_SKILL_TRIGGERS.md
@~/.agents/.instructions/INSTRUCTIONS_DIAGRAMS.md
@~/.agents/.instructions/INSTRUCTIONS_TESTING.md
@~/.agents/.instructions/INSTRUCTIONS_WORKFLOW.md
@~/.agents/.instructions/INSTRUCTIONS_DOCS.md
@~/.agents/.instructions/INSTRUCTIONS_STYLE.md
@./.agents/.instructions/INSTRUCTIONS_IOS_SWIFT_PACKAGES.md
@./.agents/.instructions/INSTRUCTIONS_RELUX_MODULES.md

## Workspace Repository Model

- `/Users/alexis/src/x-platform-airdrop` is an agent workspace root, not a Git repository root.
- The workspace intentionally groups multiple related Git repositories that belong to one product initiative. Keep loading and reasoning over the whole workspace context when working on the initiative.
- Before Git-specific operations, discover and use the concrete child repository root, for example `ios/swipe2cash/app`, `ios/swipe2cash/packages/Swipe2Cash`, or `ios/swipe2cash/packages/XPAirDrop`.
- Do not treat the absence of `.git` at the workspace root as a broken checkout or a reason to narrow context to one child repository.
- Use the workspace-level `.task-board/`, `.temp/`, and project instructions for cross-repository coordination unless a task or script explicitly requires a child-repository-local artifact path.

## Workspace Task Board Workflow

- `/Users/alexis/src/x-platform-airdrop/.task-board/` is the authoritative task tracker for this workspace, including `ios/swipe2cash`.
- Before any code, documentation, or local-instruction change in this workspace, run `task-board q 'project_config()'` from `/Users/alexis/src/x-platform-airdrop` or with `--board-dir /Users/alexis/src/x-platform-airdrop/.task-board`.
- Use the `project-management` skill and `task-board` CLI for task lifecycle writes. Create or reopen the relevant board element and move it to the correct active status before implementation.
- Do not create or append to child-repo fallback files such as `ios/swipe2cash/app/.temp/tasks.md` while the workspace root board is available. Use `.temp/` only for scratch logs/artifacts referenced from the board.
- For Swipe2Cash money-transfer UI work, prefer existing board context under `STORY-260430-32p8cf` and create focused bugs/tasks there instead of reusing stale completed or `to-review` implementation tasks.

## Source Language Policy

- Cyrillic/Russian text is allowed only in localization resources, for example `Localizable.strings`, stringsdict files, and generated localization accessors that contain localization keys.
- Swift, Objective-C, Kotlin, Java, scripts, tests, comments, debug messages, error literals, accessibility identifiers, task specs, and documentation must use English-only source text.
- User-facing Russian copy must be referenced through localization APIs instead of inline source literals.
- Before finishing iOS code changes, run `rg -n "[А-Яа-яЁё]" <changed source/test paths>` and fix every non-localization hit.

## Local Device Build

Physical BLE testing should use `Isaac Clarke (2)` as the default target device.
Cross-platform physical e2e testing should use `Isaac Clarke (2)` plus the
connected Xiaomi Android device.

Product roadmap direction:

- iOS is the primary product platform for the next phase.
- `ios/demo` is the target demo app that will consume the reusable XPAirDrop umbrella package.
- Android work remains prototype-oriented for now and should be used as the cross-device counterpart for the iOS demo app.
- Do not prioritize an Android demo app until the iOS demo app and umbrella integration are proven; the analogous Android demo app is a later phase.

Swipe2Cash package ownership:

- For `ios/swipe2cash`, min-target and scaffold sync changes may touch only S2C-owned packages and app-local scaffold packages.
- Treat `relux-works/*`, `MTS*`, and other local dependency checkouts as external; do not change their platform/min-target versions unless explicitly requested for that dependency.

## Swipe2Cash State-Machine Architecture

- When fixing Swipe2Cash/XPAirDrop flow bugs, do not accumulate one-off condition stacks, suppression timers, rearm paths, or retry branches as the default solution. The number of runtime cases is too large for guard-heavy fixes to stay reliable.
- Prefer the smallest generalized model that makes the invalid state impossible: explicit ownership for discovery, role, session lifecycle, retry policy, teardown, and UI presentation.
- A transport event must not silently change product role. Role transitions belong to explicit product/UI actions, for example the main send/receive tab or a flow-start action.
- Discovery must stay separate from session ownership. Lookup may update peer lists, but it must not start, rearm, replace, or recover sessions unless an explicit idle-state product rule says so.
- If a connection/session breaks before product commit, prefer a clear interrupted/failed terminal state and manual user retry over hidden automatic rearm. Add automatic retry only when it is a first-class domain rule with tests and visible state.
- Recipient/session replacement should target exactly the selected peer. While a selected outgoing target is pending, do not opportunistically pair with other nearby peers.
- Before adding a new conditional guard to a Swipe2Cash/XPAirDrop state machine, first ask whether a boundary, state owner, or invariant should be refactored instead. Keep guards only when they encode a stable domain invariant or protect against externally invalid input.

Active app bundle id for Klasta mimic mode: `com.nuum.membrana.ios.app`
Historical bundle id: `ru.mws.ios.x-platform-airdrop.app`
Active team id for Klasta mimic mode: `W7UTS93M7J`

- Device name: `Isaac Clarke (2)`
- Device id: `00008030-000E28640210802E`
- Device model seen by Xcode CLI: `iPhone 11 Pro`
- Android device model: `M2101K6G`
- Android adb id: `535a1632`
- Android adb path: `/Users/alexis/Library/Android/sdk/platform-tools/adb`

Preferred command from `ios/prototype`:

```bash
DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer tuist generate --no-open
```

```bash
DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer \
xcodebuild \
  -workspace Prototype.xcworkspace \
  -scheme Prototype \
  -destination 'id=00008030-000E28640210802E' \
  -derivedDataPath DerivedData \
  build
```

Useful checks:

```bash
DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer xcrun xcdevice list
DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer xcrun devicectl list devices
DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer \
xcodebuild \
  -workspace Prototype.xcworkspace \
  -scheme Prototype \
  -destination 'id=00008030-000E28640210802E' \
  -showBuildSettings
```

Notes:

- `xcodebuild -showdestinations` may report stale OS mismatch data for `Isaac Clarke (2)`, but direct destination by device id is the reliable path.
- The current blocker for installable device builds is signing, not device reachability.
- Keep the old `ru.mws.ios.x-platform-airdrop.app` identifier in mind for rollback, docs, and searching historical configs.
- That entitlement is wired from `ios/prototype/Project.swift` and `ios/prototype/Tuist/ProjectDescriptionHelpers/AppCapabilities.swift`.

## iOS UI Test Triage

For flaky iOS UI tests, especially SDKSSO auth on Simulator or `Isaac Clarke (2)`, do not rely on the textual `xcodebuild` log alone.

- Prefer step screenshots or `XCTAttachment` screenshots at key checkpoints (`gate`, `SSO open`, `phone focus`, `phone typed`, `OTP`, post-auth surface).
- After each triage run, inspect the `xcresult` attachments/screenshots first to see the last real UI state before changing waits or queries.
- If a UI test is missing step screenshots, add them before spending more time guessing from accessibility logs.

## BLE Pair Measurement Workflow

Use the physical iOS/iOS role-swap e2e timeline as the default measurement method for Swipe2Cash BLE pairing and money-transfer messaging.

Swipe2Cash has separate dev and prod role-swap harnesses. Keep them distinct:

- Use `.scripts/ui-tests_multidevice/run-ios-ios-money-transfer-role-swap-regression.sh` for the dev/transport 2x2 role-swap. It must launch with `SWIPE2CASH_APP_ENV=dev` through `UITest.Args.devRoleSwapE2EArguments` and use the deterministic `.success` automation transfer stub.
- Use `.scripts/ui-tests_multidevice/run-ios-ios-money-transfer-role-swap-prod-regression.sh` for the prod 2x2 role-swap. It must launch with `SWIPE2CASH_APP_ENV=prod` and `S2C_AUTOMATION_TRANSFER_API_SCENARIO=prod-success`.
- Prod e2e still uses real prod app config/SSO, but money-transfer terminal backend calls are stubbed: sender OTP confirmation, sender terminal balance refresh, receiver transfer status check, and receiver terminal balance refresh. Do not let prod e2e call the real OTP/transfer backend unless the user explicitly asks for a live-backend manual check.
- Do not rely on `Configuration.AppConfig` fallback when choosing an e2e stand. Pass the intended app environment explicitly through the test arguments or harness.

Run from `ios/swipe2cash/app` with an explicit run directory and timeline logging enabled:

```bash
RUN_DIR=/Users/alexis/src/x-platform-airdrop/.temp/ble-profile-role-swap-YYMMDD-NN
mkdir -p "$RUN_DIR"
DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer \
S2C_E2E_LOG_TIMELINE=1 \
RUN_DIR="$RUN_DIR" \
.scripts/ui-tests_multidevice/run-ios-ios-money-transfer-role-swap-regression.sh 2>&1 | tee "$RUN_DIR/run.log"
```

Primary artifacts:

- `$RUN_DIR/peer-a-xcodebuild.log`
- `$RUN_DIR/peer-b-xcodebuild.log`
- `$RUN_DIR/pair-xcodebuild.log`
- `$RUN_DIR/marker-bridge.log`
- `$RUN_DIR/peer-a.xcresult`
- `$RUN_DIR/peer-b.xcresult`

Extract timeline rows with:

```bash
rg -n "S2C_TIMELINE" "$RUN_DIR"/peer-a-xcodebuild.log "$RUN_DIR"/peer-b-xcodebuild.log
```

Interpret stage deltas this way:

- Sender `lookup_started -> confirmation` measures BLE pairing plus money-transfer requisites exchange until the sender can confirm.
- Receiver `requisites_exchange -> wait_for_confirmation` measures `transferRequested` ack, `receiverReady`, its ack, and the receiver wait-state handoff.
- Sender `confirmed -> otp_submitted -> result` includes sender-side backend transfer initiation/OTP confirmation plus `senderProcessing` and `senderCompleted` messaging.
- Receiver `transfer_progress -> result` includes `senderCompleted`, transaction status checking, and close handling. Add dedicated status-check start/end markers before attributing this interval to BLE.
- Always compare both directions of the role-swap run. A one-direction result is not enough for latency conclusions.

Use `recentMessages` in each `S2C_TIMELINE` row to verify both directions:

- Handshake: `system.hello`, `system.helloAck`.
- Sender to receiver: `moneyTransfer.transferRequested`, `moneyTransfer.senderProcessing`, `moneyTransfer.senderCompleted`.
- Receiver to sender: `moneyTransfer.receiverReady`.
- Ack linkage: `system.ack` rows must reference the expected message IDs.

Keep raw logs in `.temp/`. Put durable conclusions, stage deltas, and follow-up hypotheses into the relevant `task-board` element as an outcome resource. Do not use live device console logs as the primary profiler for this flow unless investigating app crashes, OS permission prompts, or missing `xcodebuild` output.

## Jira Management

When the user explicitly asks for Jira work (`jira`, `джира`, Jira ticket/issue/epic/story/board/sprint/comment/DoD), use the `jira-management` skill first.

- Do not access Jira proactively. Read or write Jira only after an explicit user request for Jira.
- Use `jira-mgmt` DSL commands for reads and searches.
- Use `jira-mgmt` write commands for create/update/transition/comment/DoD operations.
- When the user explicitly asks to change Jira, execute the requested write operation through `jira-mgmt`; confirm only destructive or ambiguous changes.
- If Jira credentials or project config are missing, report the required instance, project, board, or credentials before attempting writes.
- Default Jira context for Swipe2Cash demo/umbrella work: `https://jira.mts.ru/browse/SEARCH-139` (`SEARCH-139`, Epic, `Swipe2Cash переводы`).
