# iOS Swift Package Conventions

These rules come from `ios/swipe2cash/packages/XPAirDrop` and should guide reusable iOS Swift packages in this project.

## Manifest

- Use Swift tools `6.2`, Swift language mode `v6`, strict concurrency settings, `defaultLocalization: "ru"`, and iOS-only platform `.iOS(.v16)` unless a package explicitly needs something else.
- Keep `Package.swift` as the source of truth. Generated `.xcodeproj`, `.xcworkspace`, `.swiftpm`, `.build`, `Derived*`, and `*.xcresult` artifacts must stay ignored.
- Declare package layout explicitly in the manifest, for example target `path: "Sources"` and resources `.process("Resources")`.
- Add a test target for every reusable package and keep tests under `Tests/`.

## Swipe2Cash iOS Tree

- `ios/swipe2cash/app` is the Tuist app shell. It owns workspace/project generation, host app lifecycle, entitlements, bundle configuration, and top-level composition.
- `ios/swipe2cash/packages/<PackageName>` contains standalone reusable Swift packages. Each package should be able to live as its own local Git repo with its own `.gitignore`.
- App product logic belongs in packages such as `Swipe2Cash` and `XPAirDrop`, not in the app target.
- `ios/swipe2cash/packages/XPAirDrop` is project-owned for Swipe2Cash work, not an external dependency. Agents may change it freely when Swipe2Cash discovery, session, transport, or e2e behavior requires protocol or transport changes.
- The app target consumes package products through the app `Package.swift` and Tuist manifests; package-to-package dependencies should stay explicit in each package manifest.
- Source roots are flat and explicit: `Sources` for production code, `Sources/Resources` for package resources, and `Tests` for package tests.

## Package Boundaries

- Prefer separate Swift packages for reusable product layers when linkage/product boundaries matter, not only when source ownership differs.
- Keep `XPAirDrop` and `Swipe2Cash` as separate packages so Tuist can control each product type independently, for example `XPAirDrop.framework` and `Swipe2Cash.framework`.
- Do not collapse reusable layers into multiple targets inside one Swift package only for convenience. Target dependencies inside one package weaken the product/linkage boundary and make it easier for composition to become effectively static/internal.
- Use one package with multiple targets only when the targets are implementation details of one deliverable and do not need separate framework embedding, binary distribution, or release/linkage control.

## Swipe2Cash UI Layers

- `Swipe2CashDemo` app should open the application module through public entrypoints such as `Swipe2Cash.UI.EntryPoint`; it should not import or use `Swipe2CashUIKit` directly.
- `Swipe2Cash` owns product flow screens and the `Swipe2Cash.UI` namespace. It may depend on `Swipe2CashUIKit` for reusable visual primitives.
- `Swipe2CashUIKit` is the lower UI/design-kit package. It owns components, typography, palette, icon/font adapters, and dependencies on design-system packages such as `MTSDesignSystem` and `MTSIcon`.
- Typography may live in a separate package target/product such as `Swipe2CashTypography` when font registration/adapters need an independent linkage boundary. Keep public usage under `Swipe2CashUIKit.Typography` and re-export through the UI kit facade when needed.
- Host app startup hooks for design-system setup should be exposed through the application module, for example `Swipe2Cash.UI.registerFonts()`. The app target should not import `Swipe2CashUIKit` or `Swipe2CashTypography` only to bootstrap fonts.
- Wrap external design-system APIs behind project-level SwiftUI modifiers, for example `Text("hello").font(.mtsCompact, .title3)`, instead of leaking raw external style enums through product UI code.
- Root Swipe2Cash views must put `Swipe2Cash.UI.Customization` into SwiftUI environment with `.swipe2CashCustomization(...)`. Host app entrypoints and explicit preview overrides may accept customization, but regular feature containers should not pass it down manually.
- Relux containers own state and actions. Pages read `@Environment(\.swipe2CashCustomization)` and map it into component-level palette models before constructing child views.
- Swipe2Cash UI components with appearance must declare their own small `Palette` model and accept `Props`, `Actions`, and `Palette` as separate inputs. Do not pass the whole `Swipe2Cash.UI.Customization` into components, and avoid accepting the whole `Swipe2Cash.UI.Palette` unless the component is explicitly adapting a lower-level `Swipe2CashUIKit` primitive.
- `Swipe2CashUIKit` must not depend on `Swipe2Cash`, `XPAirDrop`, backend clients, money-transfer business logic, or app composition state.
- Root app `Package.swift` may list transitive local packages so Tuist can resolve and configure product types, but target-level dependencies must still reflect the conceptual ownership.

## Namespaces

- Expose one public root namespace enum matching the package/module name, for example `public enum XPAirDrop {}`.
- Internal helper targets in a facade package may extend the facade namespace instead of exposing their module name when the facade deliberately re-exports them, for example `Swipe2CashTypography` owns `Swipe2CashUIKit.Typography`.
- Add public domain namespaces through extensions, for example `XPAirDrop.Business` and `XPAirDrop.UI`.
- Public API types should live inside the relevant domain namespace, for example `XPAirDrop.UI.EntryView`, rather than as unrelated top-level symbols.
- Name files by namespace path, for example `XPAirDrop+Namespace.swift` and `XPAirDrop+UI+EntryView.swift`.

## Localization

- Keep localization access behind an internal `l10n` namespace; UI and business code should not use raw localization keys directly.
- Split localization accessors by feature or surface, for example `l10n+entry_view.swift`, with keys such as `l10n.entry_view.hello`.
- Resolve package strings with `String(localized: ..., bundle: .module)` so resources come from the SwiftPM module bundle.
- Store strings under `Sources/Resources/<locale>.lproj/Localizable.strings`.

## Package Tests

- Treat `~/.agents/skills/ios-testing-tools/SKILL.md` as the reference for developing, testing, and debugging iOS app/package tests in this repo.
- Use `ios-testing-tools` guidance when adding or fixing Swift Testing suites, snapshot tests, UI tests, test identifiers, xcresult diagnostics, and screenshot-based triage.
- Use Swift Testing tooling for unit, integration, package, and snapshot tests: `import Testing`, `@Suite`, `@Test`, and `#expect`.
- In local shorthand, "swift-testing-tools" means the Swift Testing workflow from the `ios-testing-tools` skill unless a concrete package with that name is present.
- For Swipe2Cash package UI snapshots, use the app-hosted iOS `SnapshotTests` target from `ios/swipe2cash/app`. Do not run package UI snapshots with plain `swift test` or `swift test --filter` from `ios/swipe2cash/packages/Swipe2Cash`.
- Mirror the production namespace tree in tests. Example: `XPAirDrop.Test.UI.Namespace` tests `XPAirDrop.UI` contracts.
- Keep the test namespace internal to tests, usually with `extension <Module> { enum Test {} }` and nested domains such as `l10n`, `UI`, and `Business`.
- Name test files by namespace path and test role, for example `XPAirDrop+Test+Namespace.swift`, `XPAirDrop+Test+UI+Namespace.swift`, and `XPAirDrop+Test+l10n.swift`.
- Use `@MainActor` on SwiftUI suites or tests that construct views. Do not add platform availability annotations only to silence host test issues.
- Use XCTest/XCUITest for UI tests only, or when touching legacy XCTest coverage that has not been migrated yet.
- If an integration test needs app/test-bundle runtime, entitlements, app groups, keychain access groups, or other Xcode-hosted behavior, keep the hosted target but write the test itself with Swift Testing.

## Verification

- Do not add macOS availability annotations only to satisfy host `swift test` for an iOS-only package.
- Verify iOS-only package products through Xcode/Tuist iOS simulator builds and iOS test plans. Plain `swift test` runs on the macOS host, may validate the package graph against an inferred macOS deployment target, and can fail with false platform-graph errors for iOS-only packages.
- If a package declares only `.iOS(...)`, do not report host `swift test` platform failures as package build failures. Use `xcodebuild` with an iOS Simulator destination, the app workspace/scheme, or an app-hosted package test scheme instead.
- For `ios/swipe2cash/packages/Swipe2Cash`, do not use plain `swift test` as a verification gate. It is expected to hit the macOS host dependency graph (`SwiftUIRelux`, `XPAirDrop`, `HttpClient`, and similar products with higher macOS deployment targets). Verify Swipe2Cash package changes through the app-hosted iOS workflow from `ios/swipe2cash/app`, for example:
  `make integration-test IOS_TEST_DESTINATION='platform=iOS Simulator,name=iPhone 17 Pro,OS=latest' INTEGRATION_TEST_OPTIONS='-only-testing:Swipe2CashDemoIntegrationTests/Swipe2CashMoneyTransferFlowCommandingTests'`
- For Swipe2Cash package UI snapshots, run the app-hosted iOS snapshot target from `ios/swipe2cash/app`, for example:
  `make snapshot-test-sender-nearby-lookup IOS_TEST_DESTINATION='platform=iOS Simulator,name=iPhone 17 Pro,OS=latest'`
- Do not add `SNAPSHOT_TEST_OPTIONS=-only-testing:...` for Swift Testing snapshot filtering unless you have verified the log contains a Swift Testing summary such as `Test run with ... tests`. On Xcode 26.5 this project can enumerate Swift Testing identifiers but still execute 0 tests for `-only-testing`, so the stable local command intentionally runs the active `SnapshotTests` suite.
- For the full active Swipe2Cash snapshot suite, run `make snapshot-test` from `ios/swipe2cash/app`. If a reference image update is intentional, use the same targets with `S2C_RECORD_SNAPSHOTS=1`; do not switch back to SwiftPM host testing.
- If package Swift Testing suites must run in CI or locally, add an explicit iOS test runner / Tuist wiring instead of weakening package source availability or switching package tests back to XCTest.
