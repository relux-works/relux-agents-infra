# Project Local Reinforcements

## Canonical Paths

* Store durable findings, research notes, decision logs, comparison matrices, and prototype learnings in `.artifacts/`.
* Store temporary files, logs, manifests, worktrees, generated dumps, and scratch outputs in `.temp/`.
* Treat `.темп/` and `.артефактс/` only as compatibility aliases for older references. `.temp/` and `.artifacts/` are the canonical local directories for this repo.
* Keep the task board in `.task-board/` and manage it only through the `task-board` CLI. The board and its config are intentionally gitignored in this repo.

## Workflow

* Before substantial research, planning, or implementation, create or select the relevant board element in `task-board`.
* Attach important specs and findings to board elements as precondition or outcome resources instead of leaving them only in chat context.
* When research produces a durable file in `.artifacts/`, reference it from the relevant epic, story, or task on the board.

## Jira Workflows

* When the user explicitly asks for Jira work (`jira`, `джира`, Jira ticket/issue/epic/story/board/sprint/comment/DoD), use the `jira-management` skill first.
* Do not access Jira proactively. Read or write Jira only after an explicit user request for Jira.
* Use `jira-mgmt` DSL commands for reads and searches, and `jira-mgmt` write commands for create/update/transition/comment/DoD operations.
* When the user explicitly asks to change Jira, execute the requested write operation through `jira-mgmt`; confirm only destructive or ambiguous changes.
* If Jira credentials or project config are missing, report the required instance, project, board, or credentials before attempting writes.
* Default Jira context for Swipe2Cash demo/umbrella work is `https://jira.mts.ru/browse/SEARCH-139` (`SEARCH-139`, Epic, `Swipe2Cash переводы`).

## Project Focus

* The active product direction is a cross-platform AirDrop analogue for iOS and Android.
* Favor discovery, transport, pairing, and security analysis before committing to a deeper prototype.
* Keep platform constraints explicit: iOS connectivity restrictions, Android version and permission variance, and the trade-offs between BLE, LAN, mDNS, QR bootstrap, and hybrid approaches.
* For the next productization phase, iOS is the primary platform: build `ios/demo` as the demo app that consumes the reusable XPAirDrop umbrella package.
* Continue Android work as a prototype/counterpart used to validate cross-device interaction with the iOS demo app.
* Do not prioritize an Android demo app until the iOS demo app and umbrella integration are proven; an analogous Android demo app is a later roadmap phase.

## iOS Workflows

* For iOS app project work, setup, scaffolding, Tuist project operations, module management, or project-structure changes, explicitly use the `ios-app-manager` skill first.
* For iOS UI tests, screenshot validation, accessibility identifiers, Page Object flows, snapshot tests, or UI verification, explicitly use the `ios-testing-tools` skill first.
* When an iOS task spans both app implementation and validation, use both skills together: `ios-app-manager` for project/app operations and `ios-testing-tools` for test/validation workflow.
* Treat these two skills as the default local path for iOS app work in this repo, not as optional nice-to-haves.
* Before developing, testing, or debugging iOS app/package test code, read the relevant section of `~/.agents/skills/ios-testing-tools/SKILL.md` and apply it as the local testing reference.
* Use `ios-testing-tools` for Swift Testing unit/integration tests, snapshot tests, UI tests, test identifiers, xcresult/screenshot triage, and debugging broken test flows.
* For iOS unit, integration, package, and snapshot tests, use the local Swift Testing workflow ("swift-testing-tools" shorthand): `import Testing`, `@Suite`, `@Test`, and `#expect`.
* Use XCTest/XCUITest for UI tests only, or when touching legacy XCTest coverage that has not been migrated yet.
* For `ios-app-manager` scaffold changes or missing scaffold capabilities, follow the canonical `Scaffold Change Policy` section in the `ios-app-manager` skill instead of duplicating scaffold rules in project-local instructions.
* Treat the generated section of iOS app `Makefile`s as owned by `ios-app-manager`; do not patch generated targets by hand when the behavior should survive regeneration.
* Put project-specific Makefile behavior in the preserved custom section. For build/test artifact cleanup, use the generated `clean-package-artifacts` hook by overriding `PACKAGE_ARTIFACT_CLEANUP_CMD` there instead of replacing generated `build` or `test` targets.
* Keep cleanup implementations project-local. The cleanup command may know about local checkout layout and vendored package quirks, while `ios-app-manager` should only provide the lifecycle hook.
* If the user says "simulators are broken", "simulators drifted", "симы отъехали", or similar shorthand, interpret that as a Tuist/Xcode/CoreSimulator recovery request rather than a generic build failure.
* In that case, consult `~/.agents/skills/ios-app-manager/references/tree-tuist.md` in `G. Troubleshooting + Recovery Patterns`, especially item `9. Tuist/Xcode cache corruption or stale artifacts`, and use `~/.agents/skills/ios-app-manager/references/workflows.md` as the quick loop reference.
* Default simulator recovery order for this repo:
  * `ios-app-manager clean --deep --kill-xcode`
  * `make setup`
  * `xcrun simctl delete unavailable` if old/unavailable runtimes are cluttering CoreSimulator
  * re-check `Makefile` / destination overrides so they do not pin a stale simulator OS that no longer matches the installed Xcode SDK/runtime
  * rebuild against a currently available runtime from `xcrun simctl list devices available`
* Keep the iOS app target thin: lifecycle entrypoints, entitlements, host wiring, and top-level composition belong there, while product logic should live in packages/modules outside the app target.
* Build the iOS product as a portable root umbrella module over lower-level packages/modules so the nearby product can be moved into another app shell without rewriting the feature stack.
* For host-side backend/API integration on iOS, mirror the `swift-httpclient` scaffold pattern used in `xflow-ios` and `membrana`.
* Concretely:
  * app target owns registration of `(any IRpcAsyncClientStubbable)`, `(any IRpcAsyncClient)`, and local `IRpcStubsConfigurator`
  * package/module fetchers depend only on `(any IRpcAsyncClient)` and typed endpoint config objects
  * `IRpcAsyncClient` should resolve from the stubbable client so UI tests can intercept the same transport graph
  * launch-argument parsing and stub application belong in an app-target `RpcStubsConfigurator`, not in reusable packages
  * stub tokens/constants belong in dedicated `TestEnv` targets so app code and UI tests reuse one catalog
* Prefer a lightweight closure-based API configurator adapter for fetchers, similar to `AppConfig.Data.ApiConfigurator` in `xflow-ios`, when endpoints depend on runtime environment/config.
* Keep host-only auth transport and token exchange layers outside umbrella/product packages even if the umbrella later consumes the resulting `TokenProvider` and `IdentityProvider` contracts.

## Swipe2Cash Physical 2x2 E2E Stands

* Treat Swipe2Cash dev and prod physical iOS/iOS role-swap harnesses as different scenarios, not interchangeable aliases.
* Dev/transport 2x2 role-swap uses `.scripts/ui-tests_multidevice/run-ios-ios-money-transfer-role-swap-regression.sh`. It must explicitly launch with `SWIPE2CASH_APP_ENV=dev` through `UITest.Args.devRoleSwapE2EArguments` and use the deterministic `.success` automation transfer stub.
* Prod 2x2 role-swap uses `.scripts/ui-tests_multidevice/run-ios-ios-money-transfer-role-swap-prod-regression.sh`. It must explicitly launch with `SWIPE2CASH_APP_ENV=prod` and `S2C_AUTOMATION_TRANSFER_API_SCENARIO=prod-success`.
* Prod e2e uses real prod app config and SSO, but the transfer backend remains stubbed for sender OTP confirmation, sender balance refresh, receiver transaction status check, and receiver balance refresh. Do not run prod 2x2 e2e against live OTP/transfer endpoints unless the user explicitly asks for a live-backend manual check.
* Never rely on the app environment fallback for e2e. Pass the intended stand explicitly in launch arguments or the harness so test failures do not accidentally switch between dev and prod behavior.

## Swipe2Cash State-Machine Architecture

* When fixing Swipe2Cash/XPAirDrop flow bugs, do not accumulate one-off condition stacks, suppression timers, rearm paths, or retry branches as the default solution. The number of runtime cases is too large for guard-heavy fixes to stay reliable.
* Prefer the smallest generalized model that makes the invalid state impossible: explicit ownership for discovery, role, session lifecycle, retry policy, teardown, and UI presentation.
* A transport event must not silently change product role. Role transitions belong to explicit product/UI actions, for example the main send/receive tab or a flow-start action.
* Discovery must stay separate from session ownership. Lookup may update peer lists, but it must not start, rearm, replace, or recover sessions unless an explicit idle-state product rule says so.
* If a connection/session breaks before product commit, prefer a clear interrupted/failed terminal state and manual user retry over hidden automatic rearm. Add automatic retry only when it is a first-class domain rule with tests and visible state.
* Recipient/session replacement should target exactly the selected peer. While a selected outgoing target is pending, do not opportunistically pair with other nearby peers.
* Before adding a new conditional guard to a Swipe2Cash/XPAirDrop state machine, first ask whether a boundary, state owner, or invariant should be refactored instead. Keep guards only when they encode a stable domain invariant or protect against externally invalid input.

## Android Workflows

* For Android UI tests, screenshot validation, test tags, snapshot tests, Compose/Espresso/UIAutomator verification, or visual regression checks, explicitly use the `android-testing-tools` skill first.
* Treat Android app architecture as modular by default: prefer clear module boundaries over feature sprawl in a single app module.
* Treat Android presentation/state flow as MVI-first by default unless an existing local slice already proves a stronger alternative.
* Keep the Android app module thin: app lifecycle, manifest/permission wiring, host composition, and entrypoints belong there, while product logic should live in reusable Gradle modules outside the app module.
* Build the Android product as a portable root umbrella module over lower-level modules so the nearby product can be moved into another app shell without rewriting the feature stack.
* For Android dependency wiring in the current phase, prefer Gradle Git/self-hosted connection patterns over publish-to-registry workflow first.
* Concretely, prefer this order:
  * `includeBuild(...)` / composite-build style local attachment during active development
  * Gradle `sourceControl { gitRepository(uri(\"ssh://git@host/path.git\")) { producesModule(\"group:artifact\") } }` for Git-backed integration without a registry
  * only then consider publish-to-registry flow
* Keep Android library coordinates explicit:
  * `rootProject.name` acts as artifact id
  * `group` lives in the library build script
  * `version` should align with Git tag when the dependency is consumed remotely
* Keep `RepositoriesMode.FAIL_ON_PROJECT_REPOS` at settings level unless there is a strong reason to break that boundary.
* Keep dependency boundaries explicit: domain/protocol/core modules must not depend on app UI modules, and transport/discovery contracts should stay reusable across Android modules.
* Treat `android-testing-tools`, modularity, MVI, and local self-hosted Gradle wiring as the default local path for Android app work in this repo, not as optional extras.

## Naming

* Prefer descriptive artifact names such as `research-ios-connectivity.md`, `matrix-discovery-options.md`, `decision-mvp-path.md`, and `prototype-scope.md`.
* Do not keep findings only in board notes when they deserve a durable artifact file.
