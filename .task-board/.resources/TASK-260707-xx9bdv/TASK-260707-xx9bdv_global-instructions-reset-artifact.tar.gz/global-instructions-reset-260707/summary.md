# Global Instructions Reset Summary

Task: `TASK-260707-xx9bdv remove-project-specific-global-instructions`

## What Was Preserved

- `alexis-agents-infra-worktree.diff` and `alexis-agents-infra-worktree.after-source-cleanup.diff` preserve the source repo worktree diff before and after removing the global project-specific workflow line.
- `infra-untracked-files/` preserves untracked source repo files, including the browser automation instruction module, task-board task folders/resources, and `tools/agents-infra/main_test.go`.
- `global-extra-AGENTS.project.md`, `global-extra-INSTRUCTIONS_IOS_SWIFT_PACKAGES.md`, `global-extra-INSTRUCTIONS_PROJECT_LOCAL.md`, and `global-extra-INSTRUCTIONS_RELUX_MODULES.md` preserve stale project-local instruction files that had leaked into `~/.agents/.instructions`.
- `global-installed-INSTRUCTIONS_WORKFLOW.before.md` and `source-INSTRUCTIONS_WORKFLOW.before.md` preserve the pre-cleanup workflow instruction files.

## Source Cleanup

Removed this project-specific global workflow rule from `alexis-agents-infra/.instructions/INSTRUCTIONS_WORKFLOW.md`:

```text
For `/Users/alexis/src/x-platform-airdrop` Tap2Cash BLE pairing/messaging performance work, record durable findings and fixes in `docs/tap2cash-ble-messaging-kb.md` and link the relevant `.task-board/...` outcome artifact. Raw role-swap logs stay in `.temp/`.
```

## Global Reset

- Deleted installed global instruction material: `~/.agents/.instructions`, `~/.codex/AGENTS.md`, and `~/.claude/CLAUDE.md`.
- Ran `agents-infra setup global --source-dir /Users/alexis/src/relux-works/alexis-agents-infra`.

## Verification

- `agents-infra doctor global` passed.
- `go test ./...` passed from `/Users/alexis/src/relux-works/alexis-agents-infra/tools/agents-infra`.
- `global-project-specific-hits.after-setup.txt` is empty.
- `global-installed-extra-instruction-files.after-setup.txt` is empty.
