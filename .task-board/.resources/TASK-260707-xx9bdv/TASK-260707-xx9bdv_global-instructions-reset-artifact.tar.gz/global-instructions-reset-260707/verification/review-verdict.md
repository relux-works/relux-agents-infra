# TASK-260707-xx9bdv Review Verdict

Verdict: **changes requested** (`to-dev`)

## Findings

### F1 — Required preservation is incomplete and the outcome overstates it

The task artifact summary says these stale installed project-local instruction
files were preserved under
`/Users/alexis/src/x-platform-airdrop/ios/swipe2cash/.temp/global-instructions-reset-260707`:

- `global-extra-AGENTS.project.md`
- `global-extra-INSTRUCTIONS_IOS_SWIFT_PACKAGES.md`
- `global-extra-INSTRUCTIONS_PROJECT_LOCAL.md`
- `global-extra-INSTRUCTIONS_RELUX_MODULES.md`

None of the four files exists in that artifact tree. The artifact contains only
their basenames and a grep hit list. Their recoverable originals still exist at
`/Users/alexis/src/x-platform-airdrop/.agents/.instructions`, so this is
ordinary rework, not a blocker.

This is the negative-evidence shape **absent evidence treated as satisfied**:
the outcome claims preservation that the persisted artifact does not contain.
It fails the explicit DoD item to preserve source and installed global
instruction diffs/material under task-scoped artifacts and the AC that removed
material be preserved for later project-local placement.

Required rework: copy all four original files into the task-scoped artifact,
record byte digests or comparisons, and update the board outcome so its claims
match the persisted bytes.

### F2 — The required green-suite claim does not currently reproduce

On current `/Users/alexis/src/relux-works/relux-agents-infra` `main`, an
uncached `go test ./... -count=1` failed
`TestPiLaunchReadinessServiceUnavailableStillHonorsRuntimeBoundsAtProductionEntry`.
An exact rerun with `-count=3` failed the persistent-503 polling case 3/3 and
the early-child-exit classification case 2/3. Including the full run, the
observed rates are 4/4 and 3/4 respectively.

This test failure is outside the instruction-cleanup delta, but the task's
explicit `Tests green` gate is not currently supported by attached evidence.
Required rework: rerun the full uncached suite on the exact reviewed source
revision after the baseline readiness regression is resolved, and attach the
complete log with revision identity. Do not present the earlier unsupported
passing claim as current evidence.

## Checks That Passed

- `agents-infra doctor global` exited 0.
- `agents-infra verify global` exited 0.
- No extra installed instruction basenames remain beyond the source set.
- Strict and flexible alias searches across `.agents/.instructions`,
  `.codex/AGENTS.md`, and `.claude/CLAUDE.md` found no
  x-platform-airdrop/Tap2Cash/Swipe2Cash/XPAirDrop/T2C material.
- The removed Tap2Cash BLE workflow rule is preserved verbatim in both
  `source-INSTRUCTIONS_WORKFLOW.before.md` and
  `global-installed-INSTRUCTIONS_WORKFLOW.before.md`.
- The installed workflow is structurally intact and contains one canonical
  pull-request section. The currently dirty source checkout contains unrelated
  concurrent workflow edits; those were not attributed to this task.

## Attack Coverage

This task changes instruction/runtime state rather than a code gate, so a code
mutant is not applicable. The review attacked bypass surfaces by searching the
source module, installed module tree, Codex render, and Claude render with both
exact and separator/case-flexible aliases; it attacked preservation by removing
the producer's summary claim as a proxy and checking for the actual files. The
installed cleanup passed; the preservation branch failed.

## Review Context

- Reviewer worktree HEAD: `cf21665`; it is 63 commits behind current `main` and
  carries no task-specific repository delta.
- The task is a stateful cleanup of global source/runtime material; acceptance
  therefore depends on current source/runtime and persisted artifact evidence,
  not a non-existent code patch.
- Reviewer supplied no `commit_ack`.
