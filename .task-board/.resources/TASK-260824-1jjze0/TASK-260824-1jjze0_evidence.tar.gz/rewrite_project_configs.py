#!/usr/bin/env python3
"""One-time, dry-run-first project-config rollout for TASK-260824-1jjze0."""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

import tomllib

TASK_ID = "TASK-260824-1jjze0"
CANONICAL_MODEL = "Qwen3.8-27B-MLX-8bit"
PROFILE = "qwen-3.8-27b-mlx-8bit"
EXCLUDED_DIRS = {
    ".git", ".temp", ".build", ".cache", ".dart_tool", ".gradle",
    ".pub-cache", ".swiftpm", ".venv", "Carthage", "DerivedData", "Pods",
    "__pycache__", "node_modules", "target", "vendor", "venv",
}
ENTRYPOINTS = ("openai-infra", "anthropic-infra", "qwen-infra")


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def read_json(path: Path) -> object:
    return json.loads(path.read_text(encoding="utf-8"))


def file_kind(path: Path) -> str:
    mode = path.lstat().st_mode
    if stat.S_ISREG(mode):
        return "regular"
    if stat.S_ISLNK(mode):
        return "symlink"
    return "other"


def inventory(root: Path) -> list[dict[str, object]]:
    root = root.resolve()
    found: list[dict[str, object]] = []
    for current, dirs, files in os.walk(root, topdown=True, followlinks=False):
        dirs[:] = sorted(d for d in dirs if d not in EXCLUDED_DIRS)
        if "project-config.toml" not in files:
            continue
        path = Path(current) / "project-config.toml"
        if len(path.parts) < 3 or path.parts[-3:] != (".agents", ".configs", "project-config.toml"):
            continue
        kind = file_kind(path)
        record: dict[str, object] = {
            "path": str(path),
            "relative_path": str(path.relative_to(root)),
            "kind": kind,
        }
        if kind == "regular":
            data = path.read_bytes()
            record.update({"size": len(data), "sha256": sha256(data), "mode": stat.S_IMODE(path.stat().st_mode)})
        found.append(record)
    return sorted(found, key=lambda item: str(item["path"]))


def table_header_path(line: bytes) -> tuple[str, ...] | None:
    stripped = line.strip()
    if not stripped.startswith(b"["):
        return None
    array = stripped.startswith(b"[[")
    close = b"]]" if array else b"]"
    end = stripped.find(close, 2 if array else 1)
    if end < 0:
        return None
    trailing = stripped[end + len(close):].strip()
    if trailing and not trailing.startswith(b"#"):
        return None
    inner = stripped[2:end] if array else stripped[1:end]
    try:
        parsed = tomllib.loads(inner.decode("utf-8") + " = 1")
    except (UnicodeDecodeError, tomllib.TOMLDecodeError):
        return None
    keys: list[str] = []
    node: object = parsed
    while isinstance(node, dict) and len(node) == 1:
        key, node = next(iter(node.items()))
        keys.append(key)
    return tuple(keys) if node == 1 else None


def blocks(data: bytes) -> list[tuple[tuple[str, ...] | None, bytes]]:
    lines = data.splitlines(keepends=True)
    starts: list[tuple[int, tuple[str, ...]]] = []
    for index, line in enumerate(lines):
        path = table_header_path(line)
        if path is not None:
            starts.append((index, path))
    result: list[tuple[tuple[str, ...] | None, bytes]] = []
    first = starts[0][0] if starts else len(lines)
    if first:
        result.append((None, b"".join(lines[:first])))
    for position, (start, path) in enumerate(starts):
        end = starts[position + 1][0] if position + 1 < len(starts) else len(lines)
        result.append((path, b"".join(lines[start:end])))
    return result


def mcp_blocks(data: bytes) -> list[bytes]:
    return [body for path, body in blocks(data) if path and "mcp" in path]


def find_mcp_values(node: object, path: tuple[str, ...] = ()) -> list[tuple[tuple[str, ...], object]]:
    values: list[tuple[tuple[str, ...], object]] = []
    if isinstance(node, dict):
        for key, value in node.items():
            child = path + (str(key),)
            if key == "mcp":
                values.append((child, value))
            values.extend(find_mcp_values(value, child))
    return values


def canonical_agents(mlx_server: Path, mlx_model_path: Path) -> bytes:
    server = json.dumps(str(mlx_server.resolve()))
    model_path = json.dumps(str(mlx_model_path.resolve()))
    text = f'''[agents.pi.primary_session]
profile = "{PROFILE}"
pi_compatibility = "github-release:earendil-works/pi@v0.84.2:darwin-arm64#sha256-c996e888b7f7dce44bcf24f69176ac646c44139d3916bd49a6b28e5a8c5e3a65"

[agents.pi.profiles."{PROFILE}"]
provider = "local-qwen"
model = "{CANONICAL_MODEL}"
base_url = "http://127.0.0.1:18011/v1"
api = "openai-completions"
reasoning = false
input = ["text"]
context_window = 131072
max_tokens = 16384
thinking = "off"
requested_capabilities = ["text", "tools"]

[agents.pi.profiles."{PROFILE}".compat]
supports_developer_role = false
supports_reasoning_effort = false
supports_usage_in_streaming = true
supports_finish_reason = true
max_tokens_field = "max_tokens"
thinking_format = "qwen-chat-template"

[agents.pi.profiles."{PROFILE}".runtime]
executable = {server}
argv = ["--model", {model_path}, "--host", "127.0.0.1", "--port", "18011"]
readiness_path = "/models"
startup_timeout_seconds = 120
shutdown_timeout_seconds = 10

[agents.targets."openai-sol-high"]
vendor = "openai"
environment = "codex"
model = "gpt-5.6-sol"
reasoning = "high"

[agents.targets."anthropic-opus-high"]
vendor = "anthropic"
environment = "claude-code"
model = "claude-opus-5"
reasoning = "high"

[agents.targets."qwen-mlx-8bit"]
vendor = "qwen"
environment = "pi"
model = "{CANONICAL_MODEL}"
reasoning = "off"
profile = "{PROFILE}"
profile_provider = "local-qwen"
endpoint = "http://127.0.0.1:18011/v1"

[agents.entrypoints]
openai-infra = "openai-sol-high"
anthropic-infra = "anthropic-opus-high"
qwen-infra = "qwen-mlx-8bit"
'''
    return text.encode("utf-8")


def rewrite(data: bytes, canonical: bytes) -> bytes:
    tomllib.loads(data.decode("utf-8"))
    retained = b"".join(body for path, body in blocks(data) if not path or path[0] != "agents")
    if retained and not retained.endswith(b"\n"):
        retained += b"\n"
    result = retained + canonical
    before = tomllib.loads(data.decode("utf-8"))
    after = tomllib.loads(result.decode("utf-8"))
    if mcp_blocks(data) != mcp_blocks(result):
        raise ValueError("raw MCP blocks changed")
    if find_mcp_values(before) != find_mcp_values(after):
        raise ValueError("MCP TOML semantics changed")
    return result


def run_validation(binary: Path, candidate: bytes, entrypoint: str) -> dict[str, object]:
    with tempfile.TemporaryDirectory(prefix=f"{TASK_ID}-validate-") as raw:
        project = Path(raw)
        config = project / ".agents/.configs/project-config.toml"
        config.parent.mkdir(parents=True)
        config.write_bytes(candidate)
        env = os.environ.copy()
        command = [str(binary), "compose", "--mode", "primary-session", "--entrypoint", entrypoint,
                   "--project", str(project), "--schema-version", "1", "--json"]
        run = subprocess.run(command, capture_output=True, text=True, env=env, check=False)
        return {
            "entrypoint": entrypoint,
            "command": command,
            "exit_code": run.returncode,
            "stdout": run.stdout,
            "stderr": run.stderr,
        }


def dirty_snapshot(paths: list[Path]) -> dict[str, object]:
    repos: dict[str, object] = {}
    for config in paths:
        project = config.parents[2]
        top = subprocess.run(["git", "-C", str(project), "rev-parse", "--show-toplevel"],
                             capture_output=True, text=True, check=False)
        if top.returncode != 0:
            continue
        root = top.stdout.strip()
        if root in repos:
            continue
        status_run = subprocess.run(["git", "-C", root, "status", "--porcelain=v1", "--untracked-files=all"],
                                    capture_output=True, text=True, check=False)
        repos[root] = {"exit_code": status_run.returncode, "status": status_run.stdout.splitlines()}
    return repos


def write_inventory(root: Path, output: Path) -> list[dict[str, object]]:
    records = inventory(root)
    write_json(output / "inventory.json", {
        "task": TASK_ID, "root": str(root.resolve()), "excluded_dirs": sorted(EXCLUDED_DIRS),
        "count": len(records), "records": records,
    })
    (output / "inventory.txt").write_text("".join(str(r["path"]) + "\n" for r in records), encoding="utf-8")
    return records


def perform_dry_run(args: argparse.Namespace) -> dict[str, object]:
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    records = write_inventory(args.root, output)
    failures: list[dict[str, object]] = []
    plans: list[dict[str, object]] = []
    candidates: list[tuple[dict[str, object], bytes]] = []
    canonical = canonical_agents(args.mlx_server, args.mlx_model_path)
    for record in records:
        if record["kind"] != "regular":
            failures.append({"path": record["path"], "error": f"unsupported file kind: {record['kind']}"})
            continue
        path = Path(str(record["path"]))
        try:
            before = path.read_bytes()
            after = rewrite(before, canonical)
            candidate_path = output / "candidates" / str(record["relative_path"])
            candidate_path.parent.mkdir(parents=True, exist_ok=True)
            candidate_path.write_bytes(after)
            candidates.append((record, after))
            plans.append({
                "path": str(path), "relative_path": record["relative_path"],
                "before_sha256": sha256(before), "after_sha256": sha256(after),
                "changed": before != after, "candidate": str(candidate_path),
                "mcp_raw_sha256": [sha256(block) for block in mcp_blocks(before)],
            })
        except (OSError, UnicodeError, ValueError, tomllib.TOMLDecodeError) as error:
            failures.append({"path": str(path), "error": str(error)})

    validations: list[dict[str, object]] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.validation_workers) as pool:
        future_map = {
            pool.submit(run_validation, args.agents_infra_bin.resolve(), body, entrypoint): (record, entrypoint)
            for record, body in candidates for entrypoint in ENTRYPOINTS
        }
        for future in concurrent.futures.as_completed(future_map):
            record, entrypoint = future_map[future]
            result = future.result()
            result["path"] = record["path"]
            validations.append(result)
            if result["exit_code"] != 0:
                failures.append({"path": record["path"], "entrypoint": entrypoint,
                                 "error": "production compose validation failed",
                                 "exit_code": result["exit_code"]})
    validations.sort(key=lambda value: (str(value["path"]), str(value["entrypoint"])))
    report = {
        "task": TASK_ID, "mode": "dry-run", "root": str(args.root.resolve()),
        "inventory_count": len(records), "candidate_count": len(candidates),
        "changed_count": sum(1 for plan in plans if plan["changed"]),
        "plans": plans, "validations": validations, "failures": failures,
        "status": "passed" if not failures else "failed",
        "dirty_worktrees_before": dirty_snapshot([Path(str(r["path"])) for r in records if r["kind"] == "regular"]),
    }
    write_json(output / "dry-run-report.json", report)
    return report


def probe_qwen(args: argparse.Namespace) -> dict[str, object]:
    log_path = args.output.resolve() / "mlx-selector-probe.log"
    command = [str(args.mlx_server.resolve()), "--model", str(args.mlx_model_path.resolve()),
               "--host", "127.0.0.1", "--port", str(args.probe_port)]
    started = time.time()
    found_ids: list[str] = []
    outcome = "failed"
    reason = "timeout"
    with log_path.open("wb") as log:
        proc = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                                start_new_session=True, cwd=str(args.mlx_model_path.parent))
        try:
            deadline = time.monotonic() + args.probe_timeout
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            while time.monotonic() < deadline:
                code = proc.poll()
                if code is not None:
                    reason = f"process exited before selector readiness: {code}"
                    break
                try:
                    with opener.open(f"http://127.0.0.1:{args.probe_port}/v1/models", timeout=1) as response:
                        payload = json.load(response)
                    found_ids = [str(item.get("id")) for item in payload.get("data", [])]
                    if CANONICAL_MODEL in found_ids:
                        outcome, reason = "passed", "exact canonical selector is served"
                        break
                except (OSError, TimeoutError, ValueError, json.JSONDecodeError, urllib.error.URLError):
                    reason = "exact canonical selector not yet served"
                time.sleep(0.2)
        finally:
            if proc.poll() is None:
                os.killpg(proc.pid, signal.SIGTERM)
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait(timeout=5)
    report = {
        "task": TASK_ID, "command": command, "status": outcome, "reason": reason,
        "required_model_id": CANONICAL_MODEL, "observed_model_ids": found_ids,
        "exit_code_after_cleanup": proc.returncode, "duration_seconds": round(time.time() - started, 3),
        "log": str(log_path), "log_sha256": sha256(log_path.read_bytes()),
    }
    write_json(args.output.resolve() / "mlx-selector-probe.json", report)
    return report


def atomic_write(path: Path, data: bytes, mode: int) -> None:
    fd, raw = tempfile.mkstemp(prefix=path.name + ".", dir=path.parent)
    temporary = Path(raw)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, mode)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def perform_apply(args: argparse.Namespace) -> int:
    dry = perform_dry_run(args)
    if dry["status"] != "passed":
        print("apply refused: dry-run failed", file=sys.stderr)
        return 2
    probe = probe_qwen(args)
    if probe["status"] != "passed":
        write_json(args.output.resolve() / "applied-rewrite-report.json", {
            "task": TASK_ID, "status": "refused-before-write", "reason": "mlx selector gate failed",
            "writes": [], "probe": probe,
        })
        print("apply refused before write: real mlx_lm.server did not serve the exact canonical model selector", file=sys.stderr)
        return 3
    plans = list(dry["plans"])
    for plan in plans:
        path = Path(str(plan["path"]))
        if sha256(path.read_bytes()) != plan["before_sha256"]:
            print(f"apply refused: source changed after dry-run: {path}", file=sys.stderr)
            return 4
    backups: list[dict[str, object]] = []
    backup_root = args.output.resolve() / "backups"
    for plan in plans:
        path = Path(str(plan["path"]))
        backup = backup_root / str(plan["relative_path"])
        backup.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, backup, follow_symlinks=False)
        backups.append({"path": str(path), "backup": str(backup), "before_sha256": plan["before_sha256"],
                        "after_sha256": plan["after_sha256"], "mode": stat.S_IMODE(path.stat().st_mode)})
    writes: list[str] = []
    try:
        for backup, plan in zip(backups, plans, strict=True):
            candidate = Path(str(plan["candidate"])).read_bytes()
            atomic_write(Path(str(plan["path"])), candidate, int(backup["mode"]))
            writes.append(str(plan["path"]))
    except (OSError, ValueError):
        for item in reversed(backups):
            if str(item["path"]) in writes:
                atomic_write(Path(str(item["path"])), Path(str(item["backup"])).read_bytes(), int(item["mode"]))
        raise
    report = {"task": TASK_ID, "status": "applied", "writes": writes, "backups": backups,
              "probe": probe, "dirty_worktrees_after": dirty_snapshot([Path(path) for path in writes])}
    write_json(args.output.resolve() / "applied-rewrite-report.json", report)
    return 0


def perform_rollback(args: argparse.Namespace) -> int:
    applied_path = args.output.resolve() / "applied-rewrite-report.json"
    applied = read_json(applied_path)
    if not isinstance(applied, dict) or applied.get("status") != "applied":
        write_json(args.output.resolve() / "rollback-report.json", {
            "task": TASK_ID, "status": "refused", "reason": "no successful applied rewrite exists",
            "restores": [],
        })
        print("rollback refused: no successful applied report", file=sys.stderr)
        return 2
    results: list[dict[str, object]] = []
    for item in reversed(list(applied["backups"])):
        path = Path(str(item["path"]))
        current = sha256(path.read_bytes())
        if current != item["after_sha256"]:
            results.append({"path": str(path), "status": "refused", "reason": "post-apply bytes changed", "sha256": current})
            continue
        backup = Path(str(item["backup"])).read_bytes()
        if sha256(backup) != item["before_sha256"]:
            results.append({"path": str(path), "status": "refused", "reason": "backup hash mismatch"})
            continue
        atomic_write(path, backup, int(item["mode"]))
        results.append({"path": str(path), "status": "restored", "sha256": sha256(path.read_bytes())})
    report = {"task": TASK_ID, "status": "passed" if all(r["status"] == "restored" for r in results) else "failed",
              "results": results}
    write_json(args.output.resolve() / "rollback-report.json", report)
    return 0 if report["status"] == "passed" else 3


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser()
    result.add_argument("command", choices=("inventory", "dry-run", "apply", "rollback"))
    result.add_argument("--root", type=Path, default=Path("/Users/alexis/src"))
    result.add_argument("--output", type=Path, required=True)
    result.add_argument("--agents-infra-bin", type=Path)
    result.add_argument("--mlx-server", type=Path, default=Path("/Users/alexis/.local/pipx/venvs/mlx-lm/bin/mlx_lm.server"))
    result.add_argument("--mlx-model-path", type=Path, default=Path("/Users/alexis/src/local-models/Qwen3.8-27B-Uncensored-MLX-8bit"))
    result.add_argument("--probe-port", type=int, default=18011)
    result.add_argument("--probe-timeout", type=float, default=120)
    result.add_argument("--validation-workers", type=int, default=8)
    return result


def main() -> int:
    args = parser().parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    if args.command == "inventory":
        records = write_inventory(args.root, args.output)
        print(f"inventory_count={len(records)}")
        return 0
    if args.command in {"dry-run", "apply"} and args.agents_infra_bin is None:
        print("--agents-infra-bin is required", file=sys.stderr)
        return 2
    if args.command == "dry-run":
        report = perform_dry_run(args)
        print(f"dry_run_status={report['status']} inventory={report['inventory_count']} candidates={report['candidate_count']}")
        return 0 if report["status"] == "passed" else 3
    if args.command == "apply":
        return perform_apply(args)
    return perform_rollback(args)


if __name__ == "__main__":
    raise SystemExit(main())
