#!/usr/bin/env python3

import importlib.util
import json
import stat
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

SCRIPT = Path(__file__).with_name("rewrite_project_configs.py")
SPEC = importlib.util.spec_from_file_location("rollout", SCRIPT)
rollout = importlib.util.module_from_spec(SPEC)
assert SPEC.loader
SPEC.loader.exec_module(rollout)


OLD = b'''# retained preamble
[mcp]
enabled_servers = ["figma"] # exact bytes

[other]
value = "preserved"

[agents.codex.primary_session]
model = "old"
reasoning_effort = "xhigh"
'''


class RolloutTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="rollout-test-")
        self.root = Path(self.temp.name) / "src"
        self.output = Path(self.temp.name) / "output"
        self.root.mkdir()
        self.config = self.root / "project/.agents/.configs/project-config.toml"
        self.config.parent.mkdir(parents=True)
        self.config.write_bytes(OLD)
        self.fake_agents = Path(self.temp.name) / "agents-infra"
        self.fake_agents.write_text("#!/bin/sh\nprintf '{\"ok\":true}\\n'\n", encoding="utf-8")
        self.fake_agents.chmod(0o755)
        self.model = Path(self.temp.name) / "model"
        self.model.mkdir()

    def tearDown(self):
        self.temp.cleanup()

    def command(self, verb, mlx=None, timeout="2"):
        command = [sys.executable, str(SCRIPT), verb, "--root", str(self.root), "--output", str(self.output),
                   "--agents-infra-bin", str(self.fake_agents), "--mlx-model-path", str(self.model),
                   "--probe-timeout", timeout]
        if mlx:
            command.extend(["--mlx-server", str(mlx)])
        return subprocess.run(command, capture_output=True, text=True, check=False)

    def test_inventory_includes_hidden_and_excludes_caches(self):
        hidden = self.root / ".hidden/.agents/.configs/project-config.toml"
        hidden.parent.mkdir(parents=True)
        hidden.write_bytes(b"")
        for excluded in (".git", ".temp", "node_modules"):
            path = self.root / excluded / ".agents/.configs/project-config.toml"
            path.parent.mkdir(parents=True)
            path.write_bytes(b"")
        records = rollout.inventory(self.root)
        self.assertEqual([Path(str(item["path"])) for item in records], [hidden.resolve(), self.config.resolve()])

    def test_dry_run_preserves_mcp_and_unrelated_bytes(self):
        run = self.command("dry-run")
        self.assertEqual(run.returncode, 0, run.stderr)
        candidate = self.output / "candidates/project/.agents/.configs/project-config.toml"
        body = candidate.read_bytes()
        self.assertIn(b'[mcp]\nenabled_servers = ["figma"] # exact bytes\n', body)
        self.assertIn(b'[other]\nvalue = "preserved"\n', body)
        self.assertNotIn(b"[agents.codex.primary_session]", body)
        self.assertIn(b'[agents.targets."openai-sol-high"]', body)
        self.assertEqual(rollout.mcp_blocks(OLD), rollout.mcp_blocks(body))

    def write_fake_mlx(self, model_id, exit_early=False):
        path = Path(self.temp.name) / ("mlx-" + model_id.replace("/", "_"))
        if exit_early:
            body = "#!/bin/sh\nexit 9\n"
        else:
            body = f'''#!/usr/bin/env python3
import argparse, json
from http.server import BaseHTTPRequestHandler, HTTPServer
p=argparse.ArgumentParser(); p.add_argument("--model"); p.add_argument("--host"); p.add_argument("--port", type=int); a=p.parse_args()
class H(BaseHTTPRequestHandler):
 def do_GET(self):
  body=json.dumps({{"object":"list","data":[{{"id":{model_id!r}}}]}}).encode(); self.send_response(200); self.end_headers(); self.wfile.write(body)
 def do_POST(self):
  body=json.dumps({{"choices":[{{"message":{{"content":"O"}},"finish_reason":"length"}}]}}).encode(); self.send_response(200); self.end_headers(); self.wfile.write(body)
 def log_message(self, *args): pass
HTTPServer((a.host,a.port),H).serve_forever()
'''
        path.write_text(body, encoding="utf-8")
        path.chmod(path.stat().st_mode | stat.S_IXUSR)
        return path

    def test_production_apply_refuses_wrong_model_narrowing_before_write(self):
        # Production call site: perform_apply -> probe_qwen. This fails if the
        # gate is narrowed from exact identity to any non-empty model list.
        mlx = self.write_fake_mlx("wrong-model")
        before = self.config.read_bytes()
        run = self.command("apply", mlx=mlx, timeout="0.8")
        self.assertEqual(run.returncode, 3, run.stderr)
        self.assertEqual(self.config.read_bytes(), before)
        report = json.loads((self.output / "applied-rewrite-report.json").read_text())
        self.assertEqual(report["status"], "refused-before-write")
        self.assertEqual(report["writes"], [])

    def test_apply_backup_hash_and_rollback_round_trip(self):
        mlx = self.write_fake_mlx(str(self.model.resolve()))
        before = self.config.read_bytes()
        applied = self.command("apply", mlx=mlx)
        self.assertEqual(applied.returncode, 0, applied.stderr)
        self.assertNotEqual(self.config.read_bytes(), before)
        report = json.loads((self.output / "applied-rewrite-report.json").read_text())
        self.assertEqual(report["status"], "applied")
        self.assertEqual(report["backups"][0]["before_sha256"], rollout.sha256(before))
        verified = self.command("verify")
        self.assertEqual(verified.returncode, 0, verified.stderr)
        verification = json.loads((self.output / "verification-report.json").read_text())
        self.assertTrue(verification["rollback_ready"])
        rolled_back = self.command("rollback")
        self.assertEqual(rolled_back.returncode, 0, rolled_back.stderr)
        self.assertEqual(self.config.read_bytes(), before)

    def test_verify_refuses_post_apply_config_drift(self):
        # Production call site: perform_verify. A current config whose bytes no
        # longer match the applied candidate must not be reported rollback-ready.
        mlx = self.write_fake_mlx(str(self.model.resolve()))
        applied = self.command("apply", mlx=mlx)
        self.assertEqual(applied.returncode, 0, applied.stderr)
        self.config.write_bytes(self.config.read_bytes() + b"# drift\n")
        verified = self.command("verify")
        self.assertEqual(verified.returncode, 3, verified.stderr)
        verification = json.loads((self.output / "verification-report.json").read_text())
        self.assertFalse(verification["rollback_ready"])


if __name__ == "__main__":
    unittest.main()
