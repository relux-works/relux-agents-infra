# TASK-260825-imfmgz — revision 8 evidence module

Self-contained. Closes review `RUN-260825-c71188` finding F2, which was that the
revision-7 sources were attached as loose files referencing a helper harness no
attached resource defined, so the reviewer's first rerun failed to compile.

```
tar -xzf TASK-260825-imfmgz_probe-rev8-module.tar.gz
cd probe
go test -count=1 ./...          # ~187s on darwin/arm64
```

No network and no module cache are required: `golang.org/x/sys` is vendored and
`GOFLAGS=-mod=vendor GOPROXY=off` is the mode the attached result log was
produced in.

## What is here

| File | What it is |
| --- | --- |
| `go.mod`, `go.sum`, `vendor/` | the module and its one dependency |
| `helper_main_test.go` | `TestMain` helper dispatcher — re-execs this test binary as the launcher |
| `identity.go` | `kern.proc.pid` / `kern.procargs2` process identity, and the exec-path poller's primitives |
| `p21_frame_field_closure_test.go` | the launcher entry point (`p21Launcher`), profile composition, the run harness |
| `frame_shape_test.go` | the decoder boundary — spec §6.2 B12 step 4 — and every mutant |
| `p22_frame_shape_closure_test.go` | P22, revisions 6 and 7: the clause rows, the near-miss classes, the reviewer reruns |
| `p23_frame_shape_oracle_test.go` | P23, revision 8: the oracle differential, the generated corpus, the mutant kill witnesses, the production-entry bypass rows |

## What P23 is

`p21DecodeFrame` is the decoder under test. `oracleVerdict` is an independent
decision procedure that reads the *generator's own member list* — never the
bytes, never the decoder — and applies the specified rule. `buildCorpus`
generates ~400 frames sweeping the decision's five degrees of freedom (name
identity, occurrence count, position, encoding, length) plus a seeded random
tail, and P23.A requires the decoder to agree with the oracle on accept/refuse,
on the refusal reason **and** on the named member, for every one of them.

No expected outcome is written next to a frame. That is the point: a narrowed
gate is caught because it disagrees with the oracle, not because someone
predicted the class it admits.

P23.B then requires every mutant to be killed *by the corpus* and reports which
generated frame killed it. A mutant no generated frame kills fails the test as a
coverage hole. Seven of the eighteen mutants are green on the entire revision-7
table and on both `RUN-260825-c71188` rows; the corpus kills them anyway.

P23.C drives the real `runtime-launch` entry point with the reviewer's two exact
bypass frames and one frame per revision-8 blind mutant, in both directions.
