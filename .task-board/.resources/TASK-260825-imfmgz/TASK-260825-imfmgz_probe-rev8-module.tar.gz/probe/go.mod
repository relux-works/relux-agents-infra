// Self-contained evidence module for TASK-260825-imfmgz revision 8.
//
// Review RUN-260825-c71188 finding F2: the revision-7 sources were attached as
// loose files that referenced a helper harness no attached resource defined, so
// the first reviewer rerun failed to compile and the harness had to be
// reconstructed by hand. This module carries everything: go.mod, go.sum, the
// vendored dependency, the TestMain helper dispatcher, the kernel identity
// helper, the launcher entry point, the decoder with every mutant, and all
// three probe suites.
//
//	go test -count=1 ./...
//
// Nothing else is required - no network, no module cache, no other resource.
module taskboard.local/imfmgz/rev8probe

go 1.21.0

require golang.org/x/sys v0.30.0
