package probe7

import (
	"os"
	"testing"
)

const helperEnv = "TASK_260825_IMFMGZ_PROBE_HELPER"

var helpers = map[string]func(){}

func TestMain(m *testing.M) {
	if name := os.Getenv(helperEnv); name != "" {
		helper, ok := helpers[name]
		if !ok {
			os.Exit(127)
		}
		helper()
		os.Exit(0)
	}
	os.Exit(m.Run())
}
