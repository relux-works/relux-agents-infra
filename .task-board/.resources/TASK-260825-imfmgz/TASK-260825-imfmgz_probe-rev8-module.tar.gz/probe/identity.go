package probe7

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"os"
	"testing"
	"time"

	"golang.org/x/sys/unix"
)

type ProcIdentity struct {
	Pid   int
	Uid   uint32
	Start unix.Timeval
	Exe   string
	Argv  []string
}

func Identify(pid int) (ProcIdentity, error) {
	id := ProcIdentity{Pid: pid}
	kp, err := unix.SysctlKinfoProc("kern.proc.pid", pid)
	if err != nil {
		return id, fmt.Errorf("kern.proc.pid: %w", err)
	}
	id.Uid = kp.Eproc.Ucred.Uid
	id.Start = kp.Proc.P_starttime
	raw, err := unix.SysctlRaw("kern.procargs2", pid)
	if err != nil {
		return id, fmt.Errorf("kern.procargs2: %w", err)
	}
	if len(raw) < 4 {
		return id, fmt.Errorf("kern.procargs2 short")
	}
	argc := int(binary.LittleEndian.Uint32(raw[:4]))
	rest := raw[4:]
	i := bytes.IndexByte(rest, 0)
	if i < 0 {
		return id, fmt.Errorf("kern.procargs2 no exec path")
	}
	id.Exe = string(rest[:i])
	rest = rest[i:]
	for len(rest) > 0 && rest[0] == 0 {
		rest = rest[1:]
	}
	for _, p := range bytes.Split(rest, []byte{0}) {
		if len(id.Argv) >= argc {
			break
		}
		id.Argv = append(id.Argv, string(p))
	}
	return id, nil
}

func shortTempDir(t *testing.T) string {
	t.Helper()
	d, err := os.MkdirTemp("/tmp", "p7-review")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = os.RemoveAll(d) })
	return d
}

func waitGone(pid int, d time.Duration) bool {
	deadline := time.Now().Add(d)
	for time.Now().Before(deadline) {
		kp, err := unix.SysctlKinfoProc("kern.proc.pid", pid)
		if err != nil || kp.Proc.P_stat == 5 {
			return true
		}
		time.Sleep(10 * time.Millisecond)
	}
	_, err := unix.SysctlKinfoProc("kern.proc.pid", pid)
	return err != nil
}
