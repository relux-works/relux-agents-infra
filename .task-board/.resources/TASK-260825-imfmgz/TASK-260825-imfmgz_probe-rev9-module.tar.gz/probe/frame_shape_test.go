package probe7

// Revision 6's decoder boundary: the authorization frame's field set is closed
// at the DECODER, not at the comparison. Revision 7 leaves that boundary exactly
// where revision 6 put it and changes only what the evidence is able to prove
// about it.
//
// Review RUN-260825-a8a4ef finding F1 showed why the decoder/comparison
// distinction is the whole point. Revision 5 stated a closed five-field set and
// enforced it with five equality comparisons over a Go struct. `json.Unmarshal`
// ignores unknown object members and keeps the last of duplicate keys, so a
// frame carrying a sixth member, or carrying `protocol_version` twice, satisfied
// all five comparisons while transporting a value the launcher never looked at.
// A comparison can only answer "is the value I decoded the one I expect"; it
// cannot answer "were these the only bytes in the frame". That second question
// is the decoder's.
//
// Review RUN-260825-9d5cff then found that the revision-6 PROOF did not bind the
// decoder to the rule it had just written down. Two narrowed gates satisfied
// every named revision-6 row while admitting frames the specification refuses:
//
//	(1) refuse a duplicate only when the two decoded values DIFFER. Both
//	    revision-6 duplicate rows carried 999 and 6, so both stayed green - yet
//	    `protocol_version` repeated twice with the same valid value was admitted,
//	    which is not "exactly once".
//	(2) refuse only the one unknown name the row happened to sample
//	    (`caller_chosen_field`). That row stayed green while any other unknown
//	    member, `future_extension` among them, was admitted.
//
// Neither is caught by a delete-only mutant: deleting a clause proves the clause
// exists, and says nothing about the class it covers. Revision 7 therefore
// carries FOUR narrowed mutants alongside the deletions, and the rows that
// redden them:
//
//	dup_only_if_values_differ         value-sensitive duplicate gate
//	dup_only_protocol_version         field-sampled duplicate gate
//	unknown_only_caller_chosen_field  name-sampled unknown gate
//	unknown_case_folded               case-insensitive allowlist
//	unknown_prefix_allowed            prefix-tolerant allowlist
//
// The duplicate dimension is proved EXHAUSTIVELY rather than by sample, because
// the allowed set is closed and finite: all five members are duplicated with
// their own valid value, one row each. The unknown-name dimension is infinite,
// so it is proved by named near-miss classes, each paired with a narrowed mutant
// that only that class reddens.

import (
	"bytes"
	"encoding/json"
	"io"
	"sort"
	"strings"
)

// frameFields is the closed set, in the order the refusal reports a missing
// member. An implementation may not add to it without a protocol version bump
// (spec section 9).
var frameFields = []string{
	"schema",
	"protocol_version",
	"runtime_key",
	"launcher_pid",
	"exec_plan_digest",
}

type shapeFault struct {
	reason string
	field  string
}

// frameMember is one top-level member as the decoder saw it: the name, and the
// raw bytes of its value. The value is retained for exactly one reason - the
// narrowed mutant `dup_only_if_values_differ` needs it in order to BE that
// mutant. The specified gate never consults it: a duplicate is a duplicate
// whatever it carries.
type frameMember struct {
	name string
	raw  json.RawMessage
	// wire is the member name exactly as it appeared in the bytes, quotes and
	// escape sequences included. The specified gate never consults it: the rule
	// is byte equality on the DECODED name, so `{"\u0073chema": ...}` is the
	// member `schema`. It is retained for the same reason `raw` is - two
	// revision-8 mutants need it in order to BE mutants, and both are defects a
	// real implementation reaches by scanning the frame text instead of decoding
	// it.
	wire string
}

// shapeEvidence is what the launcher records for the section 12.4 wiring proof:
// the key multiset the DECODER observed, alongside the fields the launcher
// compared. A green suite cannot establish either set by itself - revision 5's
// was green while the decoded multiset held six keys and the compared set held
// five.
type shapeEvidence struct {
	Keys     []string `json:"decoded_keys"`
	Compared []string `json:"compared_fields"`
}

// p21LastKeys is the decoded key multiset from the most recent frame, in stream
// order and with duplicates retained. Retaining duplicates is the point: a
// deduplicating record would report exactly the shape the attack forges.
var p21LastKeys []string

func p21ComparedFields() []string {
	out := append([]string{}, frameFields...)
	sort.Strings(out)
	return out
}

func memberNames(ms []frameMember) []string {
	out := make([]string, 0, len(ms))
	for _, m := range ms {
		out = append(out, m.name)
	}
	return out
}

// p21FrameKeys token-streams one top-level JSON object and returns its members
// in stream order, duplicates retained. It refuses anything that is not exactly
// one object, and anything following that object.
func p21FrameKeys(b []byte, mutant string) ([]frameMember, *shapeFault) {
	r := bytes.NewReader(b)
	dec := json.NewDecoder(r)
	tok, err := dec.Token()
	if err != nil {
		return nil, &shapeFault{reason: "frame_unparseable"}
	}
	if d, ok := tok.(json.Delim); !ok || d != '{' {
		return nil, &shapeFault{reason: "frame_not_single_object"}
	}
	var members []frameMember
	for {
		off0 := dec.InputOffset()
		t, err := dec.Token()
		if err != nil {
			return nil, &shapeFault{reason: "frame_unparseable"}
		}
		off1 := dec.InputOffset()
		if d, ok := t.(json.Delim); ok && d == '}' {
			break
		}
		k, ok := t.(string)
		if !ok {
			return nil, &shapeFault{reason: "frame_unparseable"}
		}
		// The name as it appeared in the bytes, for the two revision-8 mutants
		// that decide on the wire form instead of on the decoded name. The
		// specified gate does not look at it.
		wire := strings.TrimSpace(string(b[off0:off1]))
		wire = strings.TrimSpace(strings.TrimPrefix(wire, ","))
		// Decode consumes the whole value, nested or not, so the loop only ever
		// sees top-level member names.
		var raw json.RawMessage
		if err := dec.Decode(&raw); err != nil {
			return nil, &shapeFault{reason: "frame_unparseable"}
		}
		members = append(members, frameMember{name: k, raw: raw, wire: wire})
	}
	rest, err := io.ReadAll(io.MultiReader(dec.Buffered(), r))
	if err != nil {
		return nil, &shapeFault{reason: "frame_unparseable"}
	}
	if len(bytes.TrimSpace(rest)) > 0 && mutant != "trailing_ignored" {
		return nil, &shapeFault{reason: "frame_not_single_object"}
	}
	return members, nil
}

// isAllowedName answers whether a decoded member name is inside the closed five.
//
// The specified rule is BYTE EQUALITY against the five names, and revision 7
// says so here rather than leaving it implied, because "a member outside the
// closed five" is a class and the three mutants below are the three ways an
// implementation narrows it without noticing: sampling one name, folding case,
// and matching a prefix. Each is a plausible implementation, each keeps
// revision 6's single unknown row green, and each admits a member the frame may
// not carry.
func isAllowedName(k, mutant string) bool { return isAllowedMember(frameMember{name: k}, mutant) }

// isAllowedMember is the same predicate with the whole member in hand, because
// two revision-8 mutants decide on the wire form rather than on the decoded
// name.
func isAllowedMember(m frameMember, mutant string) bool {
	k := m.name
	switch mutant {
	case "reject_all_probe":
		// NOT A GATE MUTANT, and deliberately not in `shapeMutants`. This is the
		// defect review RUN-260825-86b7d5 found in revision 8's
		// `unknown_by_wire_form` - a membership predicate that refuses everything -
		// reproduced on purpose so P23.F can show that the harness's own three
		// rules redden on it. Without it, P23.B/D/E pass and nothing demonstrates
		// they would ever fail.
		return false
	case "unknown_only_caller_chosen_field":
		// MUTANT, NARROWED: refuse only the one name revision 6 sampled.
		return k != "caller_chosen_field"
	case "unknown_case_folded":
		// MUTANT, NARROWED: a case-insensitive allowlist admits `Schema`.
		for _, f := range frameFields {
			if strings.EqualFold(k, f) {
				return true
			}
		}
		return false
	case "unknown_prefix_allowed":
		// MUTANT, NARROWED: `strings.HasPrefix` instead of equality admits
		// `exec_plan_digest_v2`.
		for _, f := range frameFields {
			if strings.HasPrefix(k, f) {
				return true
			}
		}
		return false
	case "unknown_allow_over_32":
		// REVIEW RUN-260825-c71188 MUTANT, NARROWED: reject unknown names only
		// while their byte length is at most 32. Every revision-7 P22.H sample is
		// shorter, but a longer unknown member is admitted even though the
		// specified allowlist is byte equality against the closed five at every
		// length.
		if len(k) > 32 {
			return true
		}
	case "unknown_ascii_only":
		// REVISION 8 MUTANT, NARROWED, on a dimension no earlier row swept: apply
		// the allowlist only to names that are pure ASCII. Every name any review
		// or revision has ever minted is ASCII, so this is green on the entire
		// revision-7 table AND on both RUN-260825-c71188 rows, and it admits a
		// Cyrillic homoglyph of an allowed name.
		for _, r := range k {
			if r > 127 {
				return true
			}
		}
	case "unknown_nonempty_only":
		// REVISION 8 MUTANT, NARROWED: skip the allowlist for the empty name. A
		// `if name == "" { continue }` guard is an ordinary defensive reflex and
		// no sampled row has ever carried a zero-length member name.
		if k == "" {
			return true
		}
	case "unknown_by_wire_form":
		// REVISION 8 MUTANT, and the one that fails in the OTHER direction: match
		// the allowlist against the name as it appeared in the bytes instead of
		// against the decoded name. It refuses nothing it should admit-by-name,
		// but it REFUSES A VALID FRAME whose key is written `"\u0073chema"`. A
		// gate proved only by frames it must refuse would never see this.
		for _, f := range frameFields {
			if m.wire == `"`+f+`"` {
				return true
			}
		}
		return false
	}
	for _, f := range frameFields {
		if k == f {
			return true
		}
	}
	return false
}

// duplicateRefused answers whether the SECOND occurrence of an allowed member is
// refused. The specified rule ignores both the field and the values: the second
// occurrence is the violation. The two mutants are the two ways that rule gets
// narrowed into something that still passes a single sampled row.
func duplicateRefused(m frameMember, first json.RawMessage, mutant string) bool {
	switch mutant {
	case "dup_only_if_values_differ":
		// MUTANT, NARROWED: `protocol_version: 6` twice is admitted, because the
		// two decoded values agree. Every differing-value row stays green.
		return !bytes.Equal(bytes.TrimSpace(first), bytes.TrimSpace(m.raw))
	case "dup_only_protocol_version":
		// MUTANT, NARROWED: the duplicate rule is applied only to the field the
		// revision-6 rows happened to duplicate. `schema` twice is admitted.
		return m.name == "protocol_version"
	}
	return true
}

// p21CheckKeys applies the closed-set rule to a decoded member multiset. The
// order of the three verdicts is fixed so a test can state which one a given
// frame must produce: unknown members first in stream order, then duplicates in
// stream order, then missing members in frameFields order.
//
// The `mutant` argument disables or NARROWS exactly one clause each, so every
// clause has mutants that redden their own rows and leave the other rows green.
// A mutant that reddens every row would prove only that "some gate exists here".
func p21CheckKeys(members []frameMember, mutant string) *shapeFault {
	if mutant != "unknown_ignored" {
		for _, m := range members {
			// REVIEW RUN-260825-86b7d5 F1. This line used to call
			// `isAllowedName(m.name, mutant)`, which rebuilds a `frameMember` from
			// the decoded name alone and therefore CLEARS `wire` before the
			// predicate runs. Under `unknown_by_wire_form` the empty wire string
			// matched no allowed literal, so that mutant refused EVERY member of
			// EVERY frame: a reject-all fake, not the wire-form narrowing the
			// specification describes. It was still "killed by the corpus" - by 48
			// plain valid frames beginning `arity/schema/x1` - and P23.B counted the
			// kill without noticing that the witnesses were all ordinary accepted
			// frames.
			//
			// The whole member goes to the predicate now. Two things downstream
			// exist to keep it that way: P23.B requires every mutant to still admit
			// the plain valid frame, and P23.D requires each mutant's blindness to
			// be MEASURED against the named hand-written baselines rather than
			// declared in its table row.
			allowed := isAllowedMember(m, mutant)
			if mutant == "rev8_unknown_wiring" {
				// NOT A GATE MUTANT. This is revision 8's line verbatim, kept so
				// P23.F can MEASURE that the repair changed nothing about the
				// SPECIFIED decoder rather than asserting it in prose. No clause
				// consults `wire` unless a wire-form mutant is selected, so the two
				// wirings must agree on every frame under every non-wire-form
				// setting - and that agreement is why protocol_version does not move
				// for a fourth revision.
				allowed = isAllowedName(m.name, mutant)
			}
			if !allowed {
				return &shapeFault{reason: "frame_unknown_field", field: m.name}
			}
		}
	}
	switch mutant {
	case "dup_ignored", "dup_ignored_first_wins":
		// DELETED: no duplicate clause at all.
	case "dup_only_exactly_two_total":
		// REVIEW RUN-260825-c71188 MUTANT, NARROWED: validate after decoding the
		// multiset, but reject only a total count of exactly two. Every
		// revision-7 duplicate row has arity two, so it stays green; a third
		// occurrence is admitted.
		counts := map[string]int{}
		for _, m := range members {
			if isAllowedMember(m, mutant) {
				counts[m.name]++
			}
		}
		for _, m := range members {
			if counts[m.name] == 2 {
				return &shapeFault{reason: "frame_duplicate_field", field: m.name}
			}
		}
	case "dup_only_when_separated":
		// REVISION 8 MUTANT, NARROWED, on a dimension no earlier row swept:
		// refuse a repeat only when the two occurrences are NOT adjacent in
		// stream order. Every duplicate frame any review or revision has minted
		// appends the second occurrence at the end of an otherwise complete
		// object, so all of them are separated and all of them stay green - and
		// `{"schema":X,"schema":X, ...}` is admitted.
		for i, m := range members {
			if !isAllowedMember(m, mutant) {
				continue
			}
			for j := 0; j < i; j++ {
				if members[j].name == m.name && j != i-1 {
					return &shapeFault{reason: "frame_duplicate_field", field: m.name}
				}
			}
		}
	default:
		seen := map[string]json.RawMessage{}
		for _, m := range members {
			if !isAllowedMember(m, mutant) {
				continue
			}
			// dupKey is the identity a repeat is judged under. The specified gate
			// keys on the DECODED name, so `"schema"` and `"\u0073chema"` are the
			// same member. `dup_keyed_on_wire_form` keys on the bytes instead.
			key := m.name
			if mutant == "dup_keyed_on_wire_form" {
				key = m.wire
			}
			if first, dup := seen[key]; dup {
				if duplicateRefused(m, first, mutant) {
					return &shapeFault{reason: "frame_duplicate_field", field: m.name}
				}
				continue
			}
			seen[key] = m.raw
		}
	}
	if mutant != "missing_ignored" {
		present := map[string]bool{}
		for _, m := range members {
			present[m.name] = true
		}
		for _, f := range frameFields {
			if !present[f] {
				return &shapeFault{reason: "frame_missing_field", field: f}
			}
		}
	}
	return nil
}

// p21DecodeFrame is the launcher's whole decoder boundary.
//
// `shape_gate_deleted` is revision 5's launcher verbatim - a bare
// json.Unmarshal into the five-member struct - and is what the reviewer's two
// attack frames defeated.
func p21DecodeFrame(b []byte, mutant string) (p21Frame, *shapeFault) {
	var fr p21Frame
	if mutant == "shape_gate_deleted" {
		p21LastKeys = nil
		if json.Unmarshal(b, &fr) != nil {
			return fr, &shapeFault{reason: "frame_unparseable"}
		}
		return fr, nil
	}
	members, fault := p21FrameKeys(b, mutant)
	p21LastKeys = memberNames(members)
	if fault != nil {
		return fr, fault
	}
	if fault := p21CheckKeys(members, mutant); fault != nil {
		return fr, fault
	}
	// The shape is now known to be exactly the five allowed keys once each, so
	// the value decode can no longer discard anything - and, crucially, it no
	// longer matters WHICH duplicate-resolution rule the value decoder uses.
	//
	// That independence is the property `dup_ignored_first_wins` exists to prove.
	// Go's json.Unmarshal keeps the LAST of duplicate keys, so with the duplicate
	// clause deleted it admits `{"protocol_version":999, ...valid...}` and refuses
	// the reverse order. A first-wins decoder - an equally ordinary implementation
	// choice, and the one a hand-rolled streaming parser usually lands on - admits
	// exactly the reverse. Neither order is evidence on its own: each is refused
	// by whichever dedup rule the implementation did not choose, which is what
	// makes a single-order test look like a passing gate.
	if mutant == "dup_ignored_first_wins" {
		return p21FirstWins(b)
	}
	if mutant == "trailing_ignored" {
		// The natural shape of a decoder that does not check for trailing bytes:
		// decode the first value off the stream and never look at the rest.
		// json.Unmarshal would reject the extra object on its own, which would make
		// the mutant redden for the wrong reason.
		if json.NewDecoder(bytes.NewReader(b)).Decode(&fr) != nil {
			return fr, &shapeFault{reason: "frame_unparseable"}
		}
		return fr, nil
	}
	if json.Unmarshal(b, &fr) != nil {
		return fr, &shapeFault{reason: "frame_unparseable"}
	}
	return fr, nil
}

// p21FirstWins decodes retaining the FIRST occurrence of each duplicate key.
func p21FirstWins(b []byte) (p21Frame, *shapeFault) {
	var fr p21Frame
	r := bytes.NewReader(b)
	dec := json.NewDecoder(r)
	if _, err := dec.Token(); err != nil {
		return fr, &shapeFault{reason: "frame_unparseable"}
	}
	first := map[string]json.RawMessage{}
	for {
		t, err := dec.Token()
		if err != nil {
			return fr, &shapeFault{reason: "frame_unparseable"}
		}
		if d, ok := t.(json.Delim); ok && d == '}' {
			break
		}
		k, _ := t.(string)
		var raw json.RawMessage
		if err := dec.Decode(&raw); err != nil {
			return fr, &shapeFault{reason: "frame_unparseable"}
		}
		if _, seen := first[k]; !seen {
			first[k] = raw
		}
	}
	flat, err := json.Marshal(first)
	if err != nil {
		return fr, &shapeFault{reason: "frame_unparseable"}
	}
	if json.Unmarshal(flat, &fr) != nil {
		return fr, &shapeFault{reason: "frame_unparseable"}
	}
	return fr, nil
}
