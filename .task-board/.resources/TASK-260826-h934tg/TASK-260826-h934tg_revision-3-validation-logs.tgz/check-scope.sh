#!/bin/zsh
set -euo pipefail

task_dir=${0:A:h}
repo_root=${task_dir:h:h}
expected="$task_dir/expected-paths.txt"
actual="$task_dir/actual-paths.txt"
unexpected="$task_dir/unexpected-paths.txt"
missing="$task_dir/missing-paths.txt"

cd "$repo_root"
{
  git diff --name-only fd80bd8e0c1de3f372fd1a7527613a5135762de4..355a156276080b6994080f8e9a767e7416a5b357
  print -r -- LOGBOOK.md
  print -r -- tools/agents-infra/internal/infra/pi_standalone_shared_test.go
} | LC_ALL=C sort -u > "$expected"
git diff --name-only 7cfbbd938587b2054e112440678d6bb317d834b4 -- . ':(exclude).task-board/**' | LC_ALL=C sort -u > "$actual"
comm -13 "$expected" "$actual" > "$unexpected"
comm -23 "$expected" "$actual" > "$missing"

if [[ -s "$unexpected" || -s "$missing" ]]; then
  print -r -- "scope mismatch"
  print -r -- "unexpected:"
  sed -n '1,200p' "$unexpected"
  print -r -- "missing:"
  sed -n '1,200p' "$missing"
  exit 1
fi

print -r -- "scope exact: $(wc -l < "$actual" | tr -d ' ') paths"
