# TASK-260827-2q77g8 revision 5 — mutants

Every mutant was applied to pristine sources, built, run, and reverted; the
pristine tree was verified byte-for-byte by SHA-256 afterwards.

| Mutant | Edit | Contract suite | Production smoke |
| --- | --- | --- | --- |
| M1 | `weightsReleased` drops the ownership clause — the revision-4 shape | exit 1, 2 tests | exit 1, **12 failures, only phase 6f** |
| M2 | **Narrowing.** `activeBytes < footprint` relaxed to `<=` | exit 1, 2 tests | exit 1, **12 failures, only phase 6g** |
| M3 | `ModelLoader.load` no longer calls `owners.register(...)`; the registry type is untouched | **exit 0, all 197 green** | exit 1, 18 failures; phase 6a fails **closed** |
| M4 | `weightOwnersDeallocated` drops the `weightOwnerCount > 0` guard | exit 1 | not run |
| M5 | `minimumStableActiveSamples` relaxed from 3 to 1 | exit 1 | not run |
| M6 | `weightsReleased` drops the in-flight veto | exit 1 | not run |

M3 is the load-bearing one: a helper that is perfect and never called reads
exactly like a released model, and only driving the production entry point
catches it.

`attested-while-held.txt` carries the two events where a mutant attested a
completed rebuild with this model's weights demonstrably still held.
