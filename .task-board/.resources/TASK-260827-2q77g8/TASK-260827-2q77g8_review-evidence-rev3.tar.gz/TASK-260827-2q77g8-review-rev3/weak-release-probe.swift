import Foundation

final class State: @unchecked Sendable {
    private let lock = NSLock()
    private var values: [String] = []

    func record(_ value: String) {
        lock.lock()
        values.append(value)
        lock.unlock()
    }

    func snapshot() -> [String] {
        lock.lock()
        defer { lock.unlock() }
        return values
    }
}

final class Payload {
    let state: State

    init(state: State) { self.state = state }

    deinit {
        state.record("payload-deinit-start")
        Thread.sleep(forTimeInterval: 1.0)
        state.record("payload-deinit-finish")
    }
}

final class Container {
    let payload: Payload

    init(payload: Payload) { self.payload = payload }
}

let state = State()
var strong: Container? = Container(payload: Payload(state: state))
weak var observed = strong
let releaser = Thread {
    strong = nil
}
releaser.start()

let deadline = Date().addingTimeInterval(5)
while observed != nil && Date() < deadline {
    Thread.sleep(forTimeInterval: 0.001)
}
state.record(observed == nil ? "weak-nil" : "weak-still-live")
state.record("snapshot-at-weak-nil=" + state.snapshot().joined(separator: ","))
releaser.cancel()
while !state.snapshot().contains("payload-deinit-finish") && Date() < deadline {
    Thread.sleep(forTimeInterval: 0.001)
}
print(state.snapshot().joined(separator: "\n"))
