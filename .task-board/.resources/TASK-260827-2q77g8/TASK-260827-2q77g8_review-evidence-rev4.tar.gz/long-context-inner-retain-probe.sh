#!/usr/bin/env bash

set -euo pipefail

ROOT=${ROOT:?set ROOT to the story worktree}
OUT=${OUT:?set OUT to the probe output directory}
PORT=${PORT:-18033}
BINARY=${BINARY:-$ROOT/tools/mlx-swift-runtime-prototype/DerivedData/Build/Products/Release/mlx-swift-runtime-prototype}
MODEL=${MODEL:-/Users/alexis/.cache/huggingface/hub/models--mlx-community--Qwen1.5-0.5B-Chat-4bit/snapshots/659d8dafc39202a6688bb46242d60440702489b1}
BASE="http://127.0.0.1:$PORT"
INCIDENT='RuntimeError: [metal::malloc] Resource limit (499000) exceeded'

mkdir -p "$OUT"

if lsof -nP -iTCP:"$PORT" -sTCP:LISTEN >/dev/null 2>&1; then
    printf 'probe port %s is already occupied\n' "$PORT" >&2
    exit 2
fi

"$BINARY" serve \
    --model "$MODEL" \
    --host 127.0.0.1 \
    --port "$PORT" \
    --default-max-tokens 8 \
    --fault-inject-generation-error "$INCIDENT" \
    --fault-inject-generation-error-count 1 \
    --fault-inject-generation-error-after-tokens 1 \
    --fault-inject-teardown-retain-weights true \
    > "$OUT/runtime.log" 2>&1 &
runtime_pid=$!

cleanup() {
    kill -TERM "$runtime_pid" 2>/dev/null || true
    for _ in $(seq 1 40); do
        kill -0 "$runtime_pid" 2>/dev/null || break
        sleep 0.25
    done
    kill -KILL "$runtime_pid" 2>/dev/null || true
    wait "$runtime_pid" 2>/dev/null || true
}
trap cleanup EXIT

ready=0
for _ in $(seq 1 240); do
    code=$(curl -sS --max-time 3 -o /dev/null -w '%{http_code}' "$BASE/v1/models" 2>/dev/null || true)
    if [[ "$code" == 200 ]]; then
        ready=1
        break
    fi
    sleep 0.5
done
if [[ "$ready" != 1 ]]; then
    tail -40 "$OUT/runtime.log" >&2
    exit 3
fi

# About six thousand ordinary words forces a much larger prompt/KV allocation
# than the acceptance suite's short control prompt. If unrelated request state
# could inflate the process-global returned-byte comparison, this is the shape
# most likely to turn the retained-weight negative into a false positive.
chat_code=$(
    python3 - "$MODEL" <<'PY' |
import json
import sys

print(json.dumps({
    "model": sys.argv[1],
    "messages": [{"role": "user", "content": "hello " * 6000}],
    "max_tokens": 2,
    "seed": 20260827,
}))
PY
    curl -sS --max-time 240 -o "$OUT/chat.json" -w '%{http_code}' \
        -H 'Content-Type: application/json' \
        -X POST "$BASE/v1/chat/completions" \
        --data-binary @-
)

sleep 12
health_code=$(curl -sS --max-time 15 -o "$OUT/health.json" -w '%{http_code}' "$BASE/health")
curl -sS --max-time 15 "$BASE/debug/generation-state" > "$OUT/state.json"

python3 - "$chat_code" "$health_code" "$OUT/state.json" "$OUT/runtime.log" <<'PY'
import json
import sys

chat_code, health_code, state_path, log_path = sys.argv[1:]
state = json.load(open(state_path))
batch = state["batch"]
mlx = state["mlx"]
event = None
for line in open(log_path):
    try:
        row = json.loads(line)
    except ValueError:
        continue
    if row.get("event") in {
        "generation_shared_cache_rebuilt",
        "generation_shared_cache_rebuild_abandoned",
    }:
        event = row

assert event is not None, "missing teardown verdict event"
footprint = event["weight_footprint_bytes"]
returned = event["returned_bytes"]
summary = {
    "chat_http": int(chat_code),
    "health_http": int(health_code),
    "active_bytes": mlx["active_bytes"],
    "cache_bytes": mlx["cache_bytes"],
    "shared_cache_rebuilds": batch["shared_cache_rebuilds"],
    "shared_cache_rebuilds_abandoned": batch["shared_cache_rebuilds_abandoned"],
    "shared_cache_rebuild_pending": batch["shared_cache_rebuild_pending"],
    "teardown_event": event["event"],
    "container_deallocated": event["container_deallocated"],
    "weight_footprint_bytes": footprint,
    "baseline_active_bytes": event["baseline_active_bytes"],
    "returned_bytes": returned,
}
print(json.dumps(summary, sort_keys=True))

assert chat_code == "500", summary
assert health_code == "503", summary
assert event["container_deallocated"] is True, summary
assert footprint > 0, summary
assert mlx["active_bytes"] >= footprint, summary
assert event["event"] == "generation_shared_cache_rebuild_abandoned", (
    "MEASUREMENT GATE BYPASS: process-global returned bytes admitted a rebuild "
    "while the retained model weights remain active",
    summary,
)
assert returned < footprint, summary
assert batch["shared_cache_rebuilds"] == 0, summary
assert batch["shared_cache_rebuilds_abandoned"] == 1, summary
assert batch["shared_cache_rebuild_pending"] is True, summary
PY
