#!/bin/sh
echo "fake-runtime: starting on $*"
echo "fake-runtime: SECRETPROMPT-should-not-leak"
sleep 1
echo "RuntimeError: [metal::malloc] Resource limit (condemned worker)" >&2
sleep 30
