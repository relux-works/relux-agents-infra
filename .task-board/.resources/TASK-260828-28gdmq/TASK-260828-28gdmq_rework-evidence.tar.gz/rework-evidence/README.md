# TASK-260828-28gdmq rework evidence (rev2)

Rerun at the rev2 revision of
`.research/260828_model-io-observability-through-harness.md`.
Every command below was run as a standalone process; the exit code is the
shell's real status, not a piped one.

## Validation

| Command | Exit | Log |
| --- | ---: | --- |
| `gofmt -l .` | 0, no output | — |
| `go vet ./...` | 0 | — |
| `go build ./...` | 0 | — |
| `go test ./internal/modelharness/ -count=1` | 0 | `test-modelharness-package.log` |
| `go test ./internal/modelharness/ -count=1 -run '<4 observability tests>' -v` | 0 | `test-modelharness-narrow.log` |

Not rerun at rev2: full-repo `go test ./internal/...`. rev2 changes only
`.research/` prose and one `_test.go`; production code is untouched
(`git diff internal/modelharness/run.go` is empty).

## Mutation runs — all exit 1, all killed

Each mutant was applied to `internal/modelharness/run.go`, tested, then reverted.

| Log | Mutant | Test |
| --- | --- | --- |
| `mutant-M1_keep_head14.log` | match on `marker[:14]` (keep only head) | near-miss gate |
| `mutant-M2_drop_head14.log` | match on `marker[14:]` (drop head) | near-miss gate |
| `mutant-M3_drop_tail1.log` | match on `marker[:len(marker)-1]` (drop trailing `(`) | near-miss gate |
| `mutant-M4_drop_carry.log` | drop the carry in `fatalOutputWriter` | write-boundary gate |
| `mutant-M5_no_stdout.log` | child stdout to `io.Discard` | verbatim forwarding |
| `mutant-M6_capture_sink.log` | harness opens its own `os.CreateTemp` sink | no-sink characterisation |

## Why the gate test changed

Two history logs are kept deliberately, because they record a real gap in the
rev1 evidence:

- `mutant-history-single-nearmiss-marker14keep.log` — exit 1. With rev1's single
  near miss, `marker[:14]` was killed.
- `mutant-history-single-nearmiss-marker14drop-SURVIVED.log` — **exit 0**. With
  that same single near miss, `marker[14:]` — a genuine head truncation —
  survived. rev1's report claimed the gate was bounded against truncation "from
  either end"; that claim was not backed.

rev2 adds a second near miss (`FatalError: [metal::malloc] Resource limit
(499000)`) that shares the marker's tail including the `(` and diverges at the
head. M2 now fails, so the bound holds at both ends and the report's claim is
backed by a mutant that could have falsified it.
