## Brief — integrate llama-server into model-harness and the benchmark gate

Carry these findings forward rather than rediscovering them.

1. TASK-260828-28gdmq established that the harness observes the child's
   stdout/stderr only; prompt and completion bodies travel over HTTP and are
   not captured, and Pi-side and engine-side records cannot be joined. Its
   blocker B8 was specifically "llama-server is untested". Answer B8 here:
   record what llama-server does emit on stdout/stderr, whether its health and
   readiness semantics match the contract the other runtimes are held to, and
   whether the B4 shape (status logged at header-write time, so a mid-body
   death is reported as 200) also applies to it.

2. Do not relax any admission clause in `benchmark-compare` to accommodate a
   third runtime. If a clause does not fit llama.cpp, that is a finding about
   the clause or the runtime, not a reason to special-case. Prove no
   relaxation with a narrowing mutant.

3. TASK-260827-2v13w8 is reworking the gate's trust boundary right now: every
   provenance field currently lives in caller-authored JSON, so a fully
   populated forged record is accepted. Check the state of that work before
   building on the gate, and do not add a third runtime's records in a way
   that widens the same hole.

4. Lifecycle parity matters as much as serving: managed startup, readiness,
   SIGTERM group shutdown, port release. TASK-260828-28gdmq blocker B7 found
   that a directed SIGTERM to `model-harness run` can orphan the runtime
   silently — verify that path for llama-server too.

5. Do not change `profiles.qwen-local`. The new profile is additive.

## Sequencing and host constraint (added by the orchestrator)

TASK-260827-2v13w8 is mid-flight redesigning the comparison gate right now,
under a directive to put runtime launch, scenario driving and measurement,
record construction and judgement under ONE trusted production invocation.
The old shape — caller-authored records admitted on attestations — is being
removed because a reviewer forged an accepted pair through it in 7.2 seconds.

Therefore:

1. Do the model-harness profile work FIRST. Managed startup, readiness,
   health, SIGTERM group shutdown, port release, and the B8 observability
   answer for llama-server are all independent of the gate and are the
   durable part of this task.
2. For the gate side, read the current state of that work in
   `.temp/STORY-260827-m30k8z/worktree` before writing anything. Fit the
   llama.cpp candidate to the single-process target shape, not to the shape
   being removed. If that work has not landed far enough to build against,
   say so and deliver the profile half rather than guessing.
3. Do not add a third runtime in a way that reintroduces caller-authored
   records.

Host: TASK-260827-2v13w8 is benchmarking the 28 GB model. Before any load of
llama-server with the 28 GB GGUF, verify nothing listens on 18000-18999, no
mlx_lm / prototype / benchmark process is alive, and ~35 GiB is reclaimable.
Wait and re-check rather than loading anyway. Never signal another run's
processes. A small bounded prompt through llama-server is enough here; the
real measurement belongs to TASK-260828-2wcrph.
