// Reads the gate's own contextPolicy derivation against a llama-server launch.
import Foundation
let launches: [(String, [String])] = [
  ("python-mlx-lm (as configured today)", ["--model","/m","--host","127.0.0.1","--port","1","--prompt-cache-size","1","--prefill-step-size","2048","--chat-template-args","{\"reasoning_effort\": \"medium\"}"]),
  ("mlx-swift (as configured today)", ["serve","--model","/m","--host","127.0.0.1","--port","1","--reasoning-effort","medium","--default-max-tokens","2048","--model-factory","text-only","--prefill-step-size","2048"]),
  ("llama.cpp, flags llama-server accepts", ["--model","/m","--host","127.0.0.1","--port","1","--ctx-size","8192","--ubatch-size","2048","--batch-size","2048","--reasoning-effort","medium","--no-webui"]),
  ("llama.cpp, -ub short spelling", ["--model","/m","-c","8192","-ub","2048","-b","2048","--reasoning-effort","medium"]),
]
for (label, argv) in launches {
  let derived = RuntimeBenchmark.contextPolicy(derivedFrom: argv)
  let refused = RuntimeBenchmark.unpinnableConditions.filter { derived.contains($0) }
  print("\(label)\n  derived : \(derived)\n  admitted: \(refused.isEmpty ? "yes" : "NO -- refused on \(refused)")")
}
