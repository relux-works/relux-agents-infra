// The relaxation someone would reach for to admit llama.cpp, and what it costs.
//
// `unpinnableConditions` is the clause that refuses a launch which left the
// prefill chunk to a runtime default. Dropping `prefill-step=unpinned` from it
// is the smallest edit that admits a llama-server launch. This measures what
// else that edit admits.
import Foundation
let cases: [(String, [String])] = [
  ("llama.cpp launch (the one the relaxation is for)", ["--model","/m","-c","8192","-ub","2048","--reasoning-effort","medium"]),
  ("mlx-swift WITHOUT --prefill-step-size (defaults to 512)", ["serve","--model","/m","--reasoning-effort","medium","--model-factory","text-only"]),
  ("python-mlx-lm WITHOUT --prefill-step-size (defaults to 2048)", ["--model","/m","--chat-template-args","{\"reasoning_effort\": \"medium\"}"]),
]
print("clause as shipped: \(RuntimeBenchmark.unpinnableConditions)")
let relaxed = RuntimeBenchmark.unpinnableConditions.filter { $0 != "prefill-step=unpinned" }
print("clause relaxed to: \(relaxed)\n")
for (label, argv) in cases {
  let derived = RuntimeBenchmark.contextPolicy(derivedFrom: argv)
  let shipped = RuntimeBenchmark.unpinnableConditions.contains { derived.contains($0) }
  let after = relaxed.contains { derived.contains($0) }
  print("\(label)\n  derived: \(derived)\n  as shipped: \(shipped ? "REFUSED" : "admitted")   relaxed: \(after ? "REFUSED" : "admitted")")
}
print("\nA 512-token prefill chunk measured against a 2048-token one is the exact")
print("comparison the clause exists to prevent, and the relaxation admits it.")
