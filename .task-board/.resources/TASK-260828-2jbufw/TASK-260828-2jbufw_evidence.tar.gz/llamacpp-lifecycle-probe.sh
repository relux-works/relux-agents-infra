#!/bin/bash
# TASK-260828-2jbufw -- the managed lifecycle of llama-server under
# `model-harness run`, with the pre-fix harness as a live control.
#
# Blocker B7 of TASK-260828-28gdmq: a directed SIGTERM at a standalone
# `model-harness run` left the harness dead with zero bytes written while the
# runtime was reparented to pid 1 and kept holding its port. This runs the same
# stop against llama-server twice -- once with the harness as it was at HEAD,
# once with the process-group shutdown -- and records both outcomes.
set -u
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/lifecycle"; rm -rf "$OUT"; mkdir -p "$OUT"
CONFIG="$D/llamacpp-fixture.toml"
PROFILE="llamacpp-fixture"

probe() {
  local label="$1" binary="$2"
  local port pid runtime code
  port="$(python3 -c "import socket;s=socket.socket();s.bind(('127.0.0.1',0));print(s.getsockname()[1]);s.close()")"
  "$binary" run "$PROFILE" --config "$CONFIG" --host 127.0.0.1 --port "$port" \
    > "$OUT/$label-stdout.log" 2> "$OUT/$label-stderr.log" &
  pid=$!
  for _ in $(seq 1 120); do
    code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 2 "http://127.0.0.1:$port/v1/models" 2>/dev/null)
    [ "$code" = "200" ] && break
    sleep 0.5
  done
  runtime=$(pgrep -P "$pid" -f llama-server | head -1)
  {
    echo "== $label =="
    echo "binary        : $binary"
    echo "port          : $port"
    echo "harness pid   : $pid"
    echo "runtime pid   : $runtime"
    echo "readiness     : /v1/models -> $code"
    echo "health        : $(curl -s --max-time 5 "http://127.0.0.1:$port/health")"
    echo "pgid before   : $(ps -o pgid= -p "$runtime" 2>/dev/null | tr -d ' ')  (harness pgid $(ps -o pgid= -p "$pid" 2>/dev/null | tr -d ' '))"
  } >> "$OUT/report.txt"

  # The stop a service supervisor or a scripted stop sends.
  kill -TERM "$pid"
  local waited=0
  while kill -0 "$pid" 2>/dev/null && [ "$waited" -lt 40 ]; do sleep 0.5; waited=$((waited+1)); done
  wait "$pid" 2>/dev/null; local exit_code=$?
  sleep 2

  local runtime_state port_state
  if kill -0 "$runtime" 2>/dev/null; then
    runtime_state="ALIVE (ppid $(ps -o ppid= -p "$runtime" | tr -d ' '))"
  else
    runtime_state="gone"
  fi
  if python3 -c "
import socket,sys
s=socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
try:
    s.bind(('127.0.0.1', $port)); s.close(); sys.exit(0)
except OSError: sys.exit(1)
"; then port_state="free"; else port_state="STILL HELD"; fi
  {
    echo "-- after a directed SIGTERM at the harness --"
    echo "harness exit  : $exit_code"
    echo "runtime       : $runtime_state"
    echo "port $port : $port_state"
    echo "harness stderr bytes after the model-loading output:"
    grep -c '^model-harness:' "$OUT/$label-stderr.log" | sed 's/^/  lifecycle records: /'
    grep '^model-harness:' "$OUT/$label-stderr.log" | sed 's/^/  /'
    echo
  } >> "$OUT/report.txt"

  # Never leave a runtime of this task's own behind, whatever the outcome.
  if kill -0 "$runtime" 2>/dev/null; then
    echo "  (cleaning up the orphan this control produced: pid $runtime)" >> "$OUT/report.txt"
    kill -KILL "$runtime" 2>/dev/null
    sleep 1
  fi
}

probe "head-prefix" "$D/model-harness-head"
probe "with-group-shutdown" "$D/model-harness"
cat "$OUT/report.txt"
