#!/bin/bash
# TASK-260828-2jbufw -- answers blocker B8 of TASK-260828-28gdmq against a real
# llama-server under `model-harness run`, and verifies the managed lifecycle
# (readiness, health, directed-SIGTERM group shutdown, port release) for it.
#
# Repeats section 3 of .research/260828_model-io-observability-through-harness.md
# on the llama.cpp runtime: distinctive nonces are planted in a prompt body, a
# request header, a tool schema, a tool argument, a streamed request and a URL
# path, then both harness-captured streams are searched for each one.
#
# Runs on a 676 MB Qwen2.5-0.5B-Instruct Q8_0 fixture, not the 28 GB model:
# observability and lifecycle are properties of the harness path, not of model
# size, and another tracked run holds this host's memory.
set -u
set -o pipefail

D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/probe"
rm -rf "$OUT"; mkdir -p "$OUT"
HARNESS="$D/model-harness"
CONFIG="$D/llamacpp-fixture.toml"
PROFILE="llamacpp-fixture"

# An ephemeral port, deliberately outside 18000-18999: that range is scanned by
# a neighbouring run's host-contention guard and planting a listener in it would
# make that run refuse.
PORT="$(python3 -c "import socket;s=socket.socket();s.bind(('127.0.0.1',0));print(s.getsockname()[1]);s.close()")"
BASE="http://127.0.0.1:$PORT"
echo "port=$PORT" | tee "$OUT/port.txt"

"$HARNESS" run "$PROFILE" --config "$CONFIG" --host 127.0.0.1 --port "$PORT" \
  > "$OUT/harness-stdout.log" 2> "$OUT/harness-stderr.log" &
HARNESS_PID=$!
cleanup() {
  kill -TERM "$HARNESS_PID" 2>/dev/null
  sleep 2
  kill -KILL "$HARNESS_PID" 2>/dev/null
}
trap cleanup EXIT

# ---- readiness, on the same contract the other runtimes are held to ---------
# `model-harness stress` polls GET <endpoint>/models and the Pi profile declares
# readiness_path = "/models"; the endpoint is http://host:port/v1, so readiness
# is GET /v1/models answering 200 with a model id.
READY_START=$(python3 -c 'import time;print(time.time())')
READY=""
for _ in $(seq 1 600); do
  if ! kill -0 "$HARNESS_PID" 2>/dev/null; then echo "harness exited before readiness" >> "$OUT/readiness.txt"; break; fi
  CODE=$(curl -s -o "$OUT/models.json" -w '%{http_code}' --max-time 3 "$BASE/v1/models" 2>/dev/null)
  echo "$(date +%H:%M:%S) /v1/models -> $CODE" >> "$OUT/readiness.txt"
  if [ "$CODE" = "200" ]; then READY=yes; break; fi
  sleep 0.5
done
READY_END=$(python3 -c 'import time;print(time.time())')
python3 -c "print('readiness_seconds=%.2f' % ($READY_END - $READY_START))" | tee -a "$OUT/readiness.txt"
if [ -z "$READY" ]; then echo "NEVER READY" | tee -a "$OUT/readiness.txt"; exit 4; fi

RUNTIME_PID=$(pgrep -P "$HARNESS_PID" -f llama-server | head -1)
echo "harness_pid=$HARNESS_PID runtime_pid=$RUNTIME_PID" | tee "$OUT/pids.txt"
ps -o pid,ppid,pgid,command -p "$HARNESS_PID" -p "$RUNTIME_PID" >> "$OUT/pids.txt" 2>&1

# health and readiness surface, recorded rather than assumed
{
  echo "== GET /v1/models =="; cat "$OUT/models.json"; echo
  echo "== GET /health =="; curl -s -w '\nhttp=%{http_code}\n' --max-time 5 "$BASE/health"
  echo "== GET /props =="; curl -s --max-time 5 "$BASE/props" | head -c 2000; echo
} > "$OUT/health.txt" 2>&1

# ---- section 3 repeated: nonces planted on every channel --------------------
PROMPTNONCE="PROMPTNONCE-2jbufw-ALPHA"
REQIDNONCE="REQIDNONCE-2jbufw-11223344"
TOOLNONCE="TOOLNONCE2jbufw"
STREAMNONCE="STREAMNONCE-2jbufw-abc123"
REFUSEDNONCE="REFUSEDNONCE-2jbufw"

curl -s --max-time 120 -X POST "$BASE/v1/chat/completions" \
  -H 'Content-Type: application/json' -H "X-Request-Id: $REQIDNONCE" \
  -d "{\"model\":\"fixture\",\"max_tokens\":48,\"messages\":[{\"role\":\"user\",\"content\":\"Repeat this token once and stop: $PROMPTNONCE\"}],\"tools\":[{\"type\":\"function\",\"function\":{\"name\":\"get_weather_$TOOLNONCE\",\"description\":\"weather for $TOOLNONCE\",\"parameters\":{\"type\":\"object\",\"properties\":{\"city\":{\"type\":\"string\"}}}}}]}" \
  > "$OUT/completion.json" 2>&1
echo "buffered rc=$?" >> "$OUT/requests.txt"

curl -s --max-time 120 -N -X POST "$BASE/v1/chat/completions" \
  -H 'Content-Type: application/json' \
  -d "{\"model\":\"fixture\",\"stream\":true,\"max_tokens\":32,\"messages\":[{\"role\":\"user\",\"content\":\"Say: $STREAMNONCE\"}]}" \
  > "$OUT/stream.txt" 2>&1
echo "stream rc=$?" >> "$OUT/requests.txt"

curl -s -o "$OUT/refused.json" -w 'refused http=%{http_code}\n' --max-time 20 \
  -X POST "$BASE/v1/chat/completions-$REFUSEDNONCE" -H 'Content-Type: application/json' -d '{}' >> "$OUT/requests.txt" 2>&1

# The engine's own response id, and the completion text it produced.
RESPID=$(python3 -c "
import json,sys
try:
    d=json.load(open('$OUT/completion.json'))
    print(d.get('id',''))
except Exception: print('')
")
COMPLETION=$(python3 -c "
import json
try:
    d=json.load(open('$OUT/completion.json'))
    print(d['choices'][0]['message'].get('content') or '')
except Exception: print('')
" | tr -d '\n' | cut -c1-40)
echo "response_id=$RESPID" >> "$OUT/requests.txt"
echo "completion_head=$COMPLETION" >> "$OUT/requests.txt"

# ---- three concurrent completions: is any line attributable? ---------------
CONCURRENT_PIDS=""
for i in 1 2 3; do
  curl -s --max-time 120 -X POST "$BASE/v1/chat/completions" -H 'Content-Type: application/json' \
    -d "{\"model\":\"fixture\",\"max_tokens\":24,\"messages\":[{\"role\":\"user\",\"content\":\"CONCURRENT-2jbufw-$i say hello\"}]}" \
    > "$OUT/concurrent-$i.json" 2>&1 &
  CONCURRENT_PIDS="$CONCURRENT_PIDS $!"
done
# Named pids only: a bare `wait` also waits on the harness, which never exits.
wait $CONCURRENT_PIDS
python3 -c "
import json
for i in (1,2,3):
    try:
        d=json.load(open('$OUT/concurrent-%d.json'%i))
        print(i, d.get('id'))
    except Exception as e: print(i, 'ERR', e)
" > "$OUT/concurrent-ids.txt" 2>&1

sleep 1
# ---- grep both captured streams for every nonce ----------------------------
{
  printf '%-46s %8s %8s\n' 'nonce planted in' 'stdout' 'stderr'
  for pair in \
    "$PROMPTNONCE|user message body" \
    "$REQIDNONCE|X-Request-Id header" \
    "$TOOLNONCE|tool schema function name" \
    "$STREAMNONCE|streamed request body" \
    "$REFUSEDNONCE|URL path (404)" \
    "${RESPID:-__no_response_id__}|engine response id" \
    "${COMPLETION:-__no_completion__}|completion text" \
    "CONCURRENT-2jbufw|concurrent prompt bodies" \
  ; do
    n="${pair%%|*}"; label="${pair##*|}"
    o=$(grep -c -F -- "$n" "$OUT/harness-stdout.log" 2>/dev/null || echo 0)
    e=$(grep -c -F -- "$n" "$OUT/harness-stderr.log" 2>/dev/null || echo 0)
    printf '%-46s %8s %8s\n' "$label" "$o" "$e"
  done
} > "$OUT/nonce-grep.txt" 2>&1

wc -c "$OUT/harness-stdout.log" "$OUT/harness-stderr.log" > "$OUT/stream-sizes.txt"
grep -F "POST /v1/chat/completions" "$OUT/harness-stderr.log" | tail -12 > "$OUT/access-lines.txt" 2>&1
grep -F "POST /v1/chat/completions" "$OUT/harness-stdout.log" | tail -12 >> "$OUT/access-lines.txt" 2>&1

# ---- B4 shape: does a mid-body death get logged as 200? --------------------
# A long completion is started, then the runtime child is SIGKILLed while the
# body is still being produced, and the captured record for that request is read.
( curl -s --max-time 60 -o "$OUT/midbody-client.txt" -w 'client http=%{http_code}\n' \
    -X POST "$BASE/v1/chat/completions" -H 'Content-Type: application/json' \
    -d '{"model":"fixture","max_tokens":900,"messages":[{"role":"user","content":"MIDBODY-2jbufw write a very long story about a city"}]}' \
    > "$OUT/midbody-status.txt" 2>&1 ) &
CURL_JOB=$!
sleep 2
BEFORE_LINES=$(wc -l < "$OUT/harness-stderr.log")
kill -KILL "$RUNTIME_PID" 2>/dev/null
echo "killed runtime pid=$RUNTIME_PID rc=$?" > "$OUT/midbody.txt"
wait "$CURL_JOB"
cat "$OUT/midbody-status.txt" >> "$OUT/midbody.txt"
echo "--- captured stderr after the kill ---" >> "$OUT/midbody.txt"
tail -n +"$BEFORE_LINES" "$OUT/harness-stderr.log" >> "$OUT/midbody.txt"
echo "--- captured stdout tail ---" >> "$OUT/midbody.txt"
tail -5 "$OUT/harness-stdout.log" >> "$OUT/midbody.txt"

# The unsupervised harness follows the child out; record the exit it reports.
sleep 2
if kill -0 "$HARNESS_PID" 2>/dev/null; then
  echo "harness still alive after the runtime was killed" >> "$OUT/midbody.txt"
else
  echo "harness exited with the runtime" >> "$OUT/midbody.txt"
fi
wait "$HARNESS_PID" 2>/dev/null
echo "harness exit=$?" >> "$OUT/midbody.txt"
trap - EXIT
echo "PROBE COMPLETE"
