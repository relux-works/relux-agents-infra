#!/bin/bash
# Does llama-server put prompt or completion bodies on a channel the harness
# observes at ANY verbosity it offers? The default-verbosity answer is no; that
# is not the same claim as "it cannot", so the verbose setting is tested rather
# than assumed.
set -u
D="$(cd "$(dirname "$0")" && pwd)"
OUT="$D/verbosity"; rm -rf "$OUT"; mkdir -p "$OUT"
MODEL="$D/fixture/qwen2.5-0.5b-instruct-q8_0.gguf"
NONCE="VERBOSENONCE-2jbufw-ZULU"

for LEVEL in 3 5 10; do
  PORT="$(python3 -c "import socket;s=socket.socket();s.bind(('127.0.0.1',0));print(s.getsockname()[1]);s.close()")"
  /opt/homebrew/bin/llama-server --model "$MODEL" --host 127.0.0.1 --port "$PORT" \
    --ctx-size 8192 --ubatch-size 2048 --batch-size 2048 --no-webui -lv "$LEVEL" \
    > "$OUT/lv$LEVEL-stdout.log" 2> "$OUT/lv$LEVEL-stderr.log" &
  PID=$!
  for _ in $(seq 1 120); do
    [ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 2 "http://127.0.0.1:$PORT/v1/models")" = "200" ] && break
    sleep 0.5
  done
  curl -s -D "$OUT/lv$LEVEL-response-headers.txt" --max-time 60 -X POST "http://127.0.0.1:$PORT/v1/chat/completions" \
    -H 'Content-Type: application/json' -H "X-Request-Id: $NONCE-HEADER" \
    -d "{\"model\":\"m\",\"max_tokens\":24,\"messages\":[{\"role\":\"user\",\"content\":\"Reply with exactly: $NONCE\"}]}" \
    > "$OUT/lv$LEVEL-completion.json"
  sleep 1
  kill -TERM "$PID" 2>/dev/null; sleep 1; kill -KILL "$PID" 2>/dev/null; wait "$PID" 2>/dev/null
  COMPL=$(python3 -c "
import json
try: print((json.load(open('$OUT/lv$LEVEL-completion.json'))['choices'][0]['message']['content'] or '__EMPTY__').strip()[:32])
except Exception as e: print('__ERR__')
")
  {
    echo "verbosity=$LEVEL port=$PORT"
    echo "  stdout bytes: $(wc -c < "$OUT/lv$LEVEL-stdout.log")"
    echo "  stderr bytes: $(wc -c < "$OUT/lv$LEVEL-stderr.log")"
    echo "  completion  : $COMPL"
    for probe in "$NONCE|prompt body" "$NONCE-HEADER|X-Request-Id header" "POST /v1/chat/completions|HTTP request line"; do
      n="${probe%%|*}"; label="${probe##*|}"
      echo "  $label hits: stdout=$(grep -c -F -- "$n" "$OUT/lv$LEVEL-stdout.log") stderr=$(grep -c -F -- "$n" "$OUT/lv$LEVEL-stderr.log")"
    done
    if [ "$COMPL" != "__EMPTY__" ] && [ "$COMPL" != "__ERR__" ]; then
      echo "  completion text hits: stdout=$(grep -c -F -- "$COMPL" "$OUT/lv$LEVEL-stdout.log") stderr=$(grep -c -F -- "$COMPL" "$OUT/lv$LEVEL-stderr.log")"
    fi
    echo "  POSITIVE CONTROL 'listening on' hits: stderr=$(grep -c -F -- 'listening on' "$OUT/lv$LEVEL-stderr.log")"
    echo "  response headers:"; sed 's/^/    /' "$OUT/lv$LEVEL-response-headers.txt"
  } | tee -a "$OUT/summary.txt"
done
