import pathlib, sys
p = pathlib.Path(sys.argv[1]); s = p.read_text()
old, new = sys.argv[2], sys.argv[3]
assert old in s, "mutant target not found in " + sys.argv[1]
p.write_text(s.replace(old, new, 1))
