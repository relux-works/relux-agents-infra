//go:build !windows

// Review-only production-entry fixture for TASK-260828-2jbufw revision 2.
// It never becomes part of the repository candidate.
package main

import (
	"bytes"
	"errors"
	"fmt"
	"net"
	"os"
	"os/exec"
	"os/signal"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"time"
)

func main() {
	if len(os.Args) > 1 {
		switch os.Args[1] {
		case "holder":
			runHolder()
		case "sentinel":
			for {
				time.Sleep(time.Second)
			}
		}
	}
	if len(os.Args) != 3 {
		fatalf("usage: %s MODEL_HARNESS_BIN OUTPUT_DIR", os.Args[0])
	}
	modelHarness, err := filepath.Abs(os.Args[1])
	if err != nil {
		fatalf("resolve model-harness: %v", err)
	}
	outputDir, err := filepath.Abs(os.Args[2])
	if err != nil {
		fatalf("resolve output directory: %v", err)
	}
	if err := os.MkdirAll(outputDir, 0o700); err != nil {
		fatalf("create output directory: %v", err)
	}

	results := []string{
		runScenario(modelHarness, outputDir, "stubborn", true),
		runScenario(modelHarness, outputDir, "clean", false),
	}
	fmt.Println(strings.Join(results, "\n"))
}

func runHolder() {
	if len(os.Args) != 6 {
		fatalf("holder args")
	}
	port := os.Args[2]
	pidFile := os.Args[3]
	mode := os.Args[4]
	readyFile := os.Args[5]
	if mode == "stubborn" {
		signal.Ignore(syscall.SIGTERM, syscall.SIGINT, syscall.SIGHUP)
	}
	listener, err := net.Listen("tcp", net.JoinHostPort("127.0.0.1", port))
	if err != nil {
		fatalf("holder listen: %v", err)
	}
	if err := os.WriteFile(pidFile, []byte(strconv.Itoa(os.Getpid())), 0o600); err != nil {
		fatalf("holder pid: %v", err)
	}
	if err := os.WriteFile(readyFile, []byte("ready"), 0o600); err != nil {
		fatalf("holder ready: %v", err)
	}
	for {
		connection, acceptErr := listener.Accept()
		if acceptErr != nil {
			time.Sleep(10 * time.Millisecond)
			continue
		}
		_ = connection.Close()
	}
}

func runScenario(modelHarness, outputDir, name string, stubborn bool) string {
	scenarioDir := filepath.Join(outputDir, name)
	if err := os.MkdirAll(scenarioDir, 0o700); err != nil {
		fatalf("create scenario directory: %v", err)
	}
	port := reservePort()
	childPIDFile := filepath.Join(scenarioDir, "child.pid")
	holderPIDFile := filepath.Join(scenarioDir, "holder.pid")
	readyFile := filepath.Join(scenarioDir, "holder.ready")
	config := filepath.Join(scenarioDir, "config.toml")
	outputFile := filepath.Join(scenarioDir, "harness.log")
	mode := "clean"
	if stubborn {
		mode = "stubborn"
	}
	self, err := os.Executable()
	if err != nil {
		fatalf("resolve fixture executable: %v", err)
	}
	script := fmt.Sprintf(
		"%s holder %d %s %s %s </dev/null >/dev/null 2>&1 &\n"+
			"printf '%%s' \"$$\" > %s\n"+
			"trap 'exit 0' TERM INT HUP\n"+
			"while :; do sleep 0.2; done\n",
		shellQuote(self), port, shellQuote(holderPIDFile), shellQuote(mode), shellQuote(readyFile), shellQuote(childPIDFile),
	)
	configBody := "[profiles.review-fixture]\nmode = \"local\"\nexecutable = \"/bin/sh\"\nargv = [" +
		strings.Join([]string{
			tomlString("-c"), tomlString(script), tomlString("review-fixture"), tomlString("{host}"), tomlString("{port}"),
		}, ", ") + "]\n"
	if err := os.WriteFile(config, []byte(configBody), 0o600); err != nil {
		fatalf("write config: %v", err)
	}

	// A separately-created process group is the out-of-scope sentinel. Any
	// shutdown wider than the runtime's own group kills it and fails the review.
	sentinel := exec.Command(self, "sentinel")
	sentinel.SysProcAttr = &syscall.SysProcAttr{Setpgid: true}
	sentinel.Stdin = nil
	sentinel.Stdout = nil
	sentinel.Stderr = nil
	if err := sentinel.Start(); err != nil {
		fatalf("start sentinel: %v", err)
	}
	defer func() {
		_ = syscall.Kill(-sentinel.Process.Pid, syscall.SIGKILL)
		_, _ = sentinel.Process.Wait()
	}()

	harness := exec.Command(modelHarness, "run", "review-fixture", "--config", config, "--host", "127.0.0.1", "--port", strconv.Itoa(port))
	var output bytes.Buffer
	harness.Stdout = &output
	harness.Stderr = &output
	if err := harness.Start(); err != nil {
		fatalf("start harness (%s): %v", name, err)
	}
	var childPID, holderPID int
	defer func() {
		if childPID > 0 {
			_ = syscall.Kill(-childPID, syscall.SIGKILL)
		}
		if holderPID > 0 {
			_ = syscall.Kill(holderPID, syscall.SIGKILL)
		}
		if harness.Process != nil {
			_ = harness.Process.Kill()
		}
	}()
	childPID = waitPID(childPIDFile, 20*time.Second)
	holderPID = waitPID(holderPIDFile, 20*time.Second)
	waitFile(readyFile, 20*time.Second)
	waitListener(port, 20*time.Second)

	started := time.Now()
	if err := syscall.Kill(harness.Process.Pid, syscall.SIGTERM); err != nil {
		fatalf("signal harness (%s): %v", name, err)
	}
	waited := make(chan error, 1)
	go func() { waited <- harness.Wait() }()
	var waitErr error
	select {
	case waitErr = <-waited:
	case <-time.After(25 * time.Second):
		fatalf("%s shutdown hung beyond 25s; output=%q", name, output.String())
	}
	elapsed := time.Since(started)
	if err := os.WriteFile(outputFile, output.Bytes(), 0o600); err != nil {
		fatalf("write harness log: %v", err)
	}

	if waitErr != nil {
		fatalf("%s harness exit was not clean: %v; output=%q", name, waitErr, output.String())
	}
	// This is the bypass gate: an exit-0 claim is invalid until both the exact
	// managed PGID and the listener are gone. No retry is allowed after exit.
	if err := syscall.Kill(-childPID, 0); !errors.Is(err, syscall.ESRCH) {
		fatalf("%s harness returned 0 while process group %d remained: %v; output=%q", name, childPID, err, output.String())
	}
	if err := syscall.Kill(holderPID, 0); !errors.Is(err, syscall.ESRCH) {
		fatalf("%s harness returned 0 while holder pid %d remained: %v; output=%q", name, holderPID, err, output.String())
	}
	listener, bindErr := net.Listen("tcp", net.JoinHostPort("127.0.0.1", strconv.Itoa(port)))
	if bindErr != nil {
		fatalf("%s harness returned 0 while port %d remained held: %v; output=%q", name, port, bindErr, output.String())
	}
	_ = listener.Close()
	if err := syscall.Kill(sentinel.Process.Pid, 0); err != nil {
		fatalf("%s shutdown killed or obscured out-of-group sentinel %d: %v", name, sentinel.Process.Pid, err)
	}
	if !strings.Contains(output.String(), "stopped after terminated") {
		fatalf("%s clean exit lacked stopped-group record: %q", name, output.String())
	}
	if stubborn {
		if elapsed < 9*time.Second {
			fatalf("stubborn group obtained early success after %s; output=%q", elapsed, output.String())
		}
		for _, marker := range []string{"is not empty", "did not exit within", "killing it"} {
			if !strings.Contains(output.String(), marker) {
				fatalf("stubborn shutdown lacked %q evidence: %q", marker, output.String())
			}
		}
	} else {
		if elapsed > 3*time.Second {
			fatalf("ordinary clean shutdown took %s (>3s); output=%q", elapsed, output.String())
		}
		if strings.Contains(output.String(), "did not exit within") || strings.Contains(output.String(), "killing it") {
			fatalf("ordinary clean shutdown overshot into escalation: %q", output.String())
		}
	}
	return fmt.Sprintf("PASS scenario=%s elapsed=%s pgid_gone=true port_free=true sentinel_alive=true log=%s", name, elapsed.Round(time.Millisecond), outputFile)
}

func reservePort() int {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		fatalf("reserve port: %v", err)
	}
	port := listener.Addr().(*net.TCPAddr).Port
	_ = listener.Close()
	return port
}

func waitPID(name string, timeout time.Duration) int {
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		raw, err := os.ReadFile(name)
		if err == nil {
			pid, convErr := strconv.Atoi(strings.TrimSpace(string(raw)))
			if convErr == nil && pid > 0 {
				return pid
			}
		}
		time.Sleep(20 * time.Millisecond)
	}
	fatalf("no valid pid in %s", name)
	return 0
}

func waitFile(name string, timeout time.Duration) {
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		if _, err := os.Stat(name); err == nil {
			return
		}
		time.Sleep(20 * time.Millisecond)
	}
	fatalf("file did not appear: %s", name)
}

func waitListener(port int, timeout time.Duration) {
	address := net.JoinHostPort("127.0.0.1", strconv.Itoa(port))
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		connection, err := net.DialTimeout("tcp", address, 200*time.Millisecond)
		if err == nil {
			_ = connection.Close()
			return
		}
		time.Sleep(20 * time.Millisecond)
	}
	fatalf("listener did not start on %s", address)
}

func shellQuote(value string) string {
	return "'" + strings.ReplaceAll(value, "'", "'\\''") + "'"
}

func tomlString(value string) string {
	replaced := strings.NewReplacer(`\`, `\\`, `"`, `\"`, "\n", `\n`, "\t", `\t`).Replace(value)
	return `"` + replaced + `"`
}

func fatalf(format string, args ...any) {
	panic("FAIL " + fmt.Sprintf(format, args...))
}
