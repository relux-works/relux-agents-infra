import Darwin
import Foundation

// The gate's own memory reading, `proc_pid_rusage(...).ri_phys_footprint`,
// exposed for one pid so it can be sampled beside RSS on the SAME process at
// the SAME moment. `BenchmarkFootprintSampler.footprint(of:)` is this call.
func physFootprint(_ pid: Int32) -> UInt64? {
    var usage = rusage_info_v4()
    let ok = withUnsafeMutablePointer(to: &usage) { pointer -> Int32 in
        pointer.withMemoryRebound(to: rusage_info_t?.self, capacity: 1) {
            proc_pid_rusage(pid, RUSAGE_INFO_V4, $0)
        }
    }
    guard ok == 0 else { return nil }
    return usage.ri_phys_footprint
}

let pid = Int32(CommandLine.arguments[1])!
if let f = physFootprint(pid) {
    print("phys_footprint_bytes=\(f)")
} else {
    print("phys_footprint_bytes=unreadable")
    exit(1)
}
