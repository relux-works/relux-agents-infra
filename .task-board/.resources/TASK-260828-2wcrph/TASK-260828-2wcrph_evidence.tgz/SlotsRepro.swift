import Foundation

// Replicates BenchmarkPass.slots + RuntimeSpeculation.read exactly, against a
// live llama-server, to find where the gate's reading turns into `unread`.
let port = CommandLine.arguments[1]
let endpoint = URL(string: "http://127.0.0.1:\(port)/v1")!
let url = endpoint.deletingLastPathComponent().appendingPathComponent("slots")
print("url = \(url.absoluteString)")

let config = URLSessionConfiguration.ephemeral
let session = URLSession(configuration: config)
var request = URLRequest(url: url)
request.timeoutInterval = 30

let sem = DispatchSemaphore(value: 0)
session.dataTask(with: request) { data, response, error in
    let status = (response as? HTTPURLResponse)?.statusCode ?? 0
    let body = data ?? Data(String(describing: error).utf8)
    print("status = \(status)")
    print("body = \(String(data: body.prefix(400), encoding: .utf8) ?? "<binary>")")
    if let slots = try? JSONSerialization.jsonObject(with: body) as? [[String: Any]] {
        print("parsed \(slots.count) slot(s)")
        for slot in slots.prefix(1) {
            let parameters = (slot["params"] as? [String: Any]) ?? slot
            print("  params key present: \(slot["params"] != nil)")
            print("  speculative raw: \(String(describing: parameters["speculative"]))")
            print("  speculative as? Bool: \(String(describing: parameters["speculative"] as? Bool))")
        }
    } else {
        print("PARSE FAILED as [[String: Any]]")
        let any = try? JSONSerialization.jsonObject(with: body)
        print("  actual type: \(type(of: any))")
    }
    sem.signal()
}.resume()
sem.wait()
