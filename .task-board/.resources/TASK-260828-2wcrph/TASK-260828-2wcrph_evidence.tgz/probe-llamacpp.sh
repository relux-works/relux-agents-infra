#!/bin/bash
# Bounded probe: does the real 29 GB GGUF load, what n_ctx does the server
# report, what does /slots say about speculation, and what does it cost.
set -u
CTX="${CTX:-76800}"
PORT="${PORT:-29317}"
OUT="${OUT:-./probe-ctx$CTX}"
mkdir -p "$OUT"
GGUF=/Users/alexis/src/local-models/Qwen3.8-27B-Uncensored-GGUF-Q8_0/Qwen3.8-27B-Uncensored-OrcaRouter-Q8_0.gguf

/opt/homebrew/bin/llama-server \
  --model "$GGUF" --host 127.0.0.1 --port "$PORT" \
  --ctx-size "$CTX" --ubatch-size 2048 --reasoning-effort medium \
  --no-webui --spec-type none > "$OUT/server.log" 2>&1 &
PID=$!
echo "pid=$PID ctx=$CTX port=$PORT"
for i in $(seq 1 400); do
  if curl -s -m 2 "http://127.0.0.1:$PORT/v1/models" -o "$OUT/models.json" -w '%{http_code}' 2>/dev/null | grep -q 200; then
    echo "ready after ${i}s"; break
  fi
  if ! kill -0 $PID 2>/dev/null; then echo "SERVER DIED after ${i}s"; break; fi
  sleep 1
done
if kill -0 $PID 2>/dev/null; then
  curl -s -m 5 "http://127.0.0.1:$PORT/slots" -o "$OUT/slots.json"
  echo "--- footprint ---"
  /usr/bin/python3 - "$PID" > "$OUT/footprint.txt" <<'PY'
import subprocess,sys
pid=sys.argv[1]
print(subprocess.run(["footprint","-p",pid],capture_output=True,text=True).stdout[:2000])
PY
  ps -o pid,rss,vsz -p $PID
  kill $PID; wait $PID 2>/dev/null
fi
echo "=== models.json ==="; cat "$OUT/models.json" 2>/dev/null | head -c 2000; echo
echo "=== slots.json ==="; cat "$OUT/slots.json" 2>/dev/null | head -c 1500; echo
echo "=== server.log KV/mem lines ==="
grep -iE "n_ctx|KV self|kv cache|load time|model size|not supported|error|unknown|failed" "$OUT/server.log" | head -40
