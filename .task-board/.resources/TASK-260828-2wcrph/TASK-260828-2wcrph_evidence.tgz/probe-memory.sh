#!/bin/bash
# Is `ri_phys_footprint` -- the number every record in this session carries --
# a comparable measure of what these two runtimes cost the host?
#
# Samples phys_footprint, ps RSS and the mapped-file/anonymous split from
# `vmmap -summary` on the SAME pid at the SAME moment, once per runtime, after
# a real completion so the weights have actually been touched.
set -u
OUT=./probe-memory; mkdir -p "$OUT"
FP=./footprint-probe

sample() {
  local label="$1" pid="$2"
  {
    echo "=== $label (pid $pid) ==="
    "$FP" "$pid"
    echo "ps_rss_kb=$(ps -o rss= -p "$pid" | tr -d ' ')"
    echo "--- vmmap -summary ---"
    vmmap -summary "$pid" 2>/dev/null | sed -n '1,60p'
  } | tee "$OUT/$label.txt"
}

llamacpp() {
  local GGUF=/Users/alexis/src/local-models/Qwen3.8-27B-Uncensored-GGUF-Q8_0/Qwen3.8-27B-Uncensored-OrcaRouter-Q8_0.gguf
  /opt/homebrew/bin/llama-server --model "$GGUF" --host 127.0.0.1 --port 18051 \
    --ctx-size 8192 --ubatch-size 2048 --reasoning-effort medium --no-webui --spec-type none \
    > "$OUT/llamacpp.srv.log" 2>&1 &
  local pid=$!
  for i in $(seq 1 240); do
    [ "$(curl -s -m 2 -o /dev/null -w '%{http_code}' http://127.0.0.1:18051/health)" = "200" ] && break
    sleep 1
  done
  curl -s -m 300 http://127.0.0.1:18051/v1/chat/completions -H 'Content-Type: application/json' \
    -d "{\"model\":\"$GGUF\",\"messages\":[{\"role\":\"user\",\"content\":\"one sentence\"}],\"max_tokens\":16}" -o "$OUT/llamacpp.completion.json"
  sample llamacpp "$pid"
  kill "$pid" 2>/dev/null; wait "$pid" 2>/dev/null
  echo "llamacpp probe killed pid=$pid"
}

python_mlx() {
  local MLX=/Users/alexis/src/local-models/Qwen3.8-27B-Uncensored-MLX-8bit
  /Users/alexis/.local/bin/mlx_lm-relux.server --model "$MLX" --host 127.0.0.1 --port 18052 \
    --prompt-cache-size 1 --prompt-cache-bytes 8GB --prefill-step-size 2048 \
    --chat-template-args '{"reasoning_effort": "medium"}' > "$OUT/python.srv.log" 2>&1 &
  local pid=$!
  for i in $(seq 1 600); do
    curl -s -m 2 -o /dev/null http://127.0.0.1:18052/v1/models && break
    sleep 1
  done
  curl -s -m 600 http://127.0.0.1:18052/v1/chat/completions -H 'Content-Type: application/json' \
    -d "{\"model\":\"$MLX\",\"messages\":[{\"role\":\"user\",\"content\":\"one sentence\"}],\"max_tokens\":16}" -o "$OUT/python.completion.json"
  # mlx_lm.server forks/execs; the pid that holds the weights is the leaf.
  local leaf
  leaf=$(pgrep -P "$pid" | tail -1)
  [ -n "$leaf" ] && sample python-mlx-leaf "$leaf"
  sample python-mlx "$pid"
  kill "$pid" 2>/dev/null; wait "$pid" 2>/dev/null
  echo "python probe killed pid=$pid leaf=${leaf:-none}"
}

llamacpp
sleep 20
python_mlx

# The TTFT reading: which field does each runtime stream reasoning under?
# `BenchmarkHTTPDriver.streamed` sets timeToFirstTokenSeconds on the first frame
# carrying `delta.content` or `delta.reasoning`. If llama.cpp spells it
# `reasoning_content`, a response that spends its whole budget thinking has no
# first token this gate can see.
stream_shape() {
  local GGUF=/Users/alexis/src/local-models/Qwen3.8-27B-Uncensored-GGUF-Q8_0/Qwen3.8-27B-Uncensored-OrcaRouter-Q8_0.gguf
  /opt/homebrew/bin/llama-server --model "$GGUF" --host 127.0.0.1 --port 18053 \
    --ctx-size 8192 --ubatch-size 2048 --reasoning-effort medium --no-webui --spec-type none \
    > "$OUT/stream.srv.log" 2>&1 &
  local pid=$!
  for i in $(seq 1 240); do
    [ "$(curl -s -m 2 -o /dev/null -w '%{http_code}' http://127.0.0.1:18053/health)" = "200" ] && break
    sleep 1
  done
  curl -s -N -m 300 http://127.0.0.1:18053/v1/chat/completions \
    -H 'Content-Type: application/json' \
    -d "{\"model\":\"$GGUF\",\"stream\":true,\"max_tokens\":16,\"messages\":[{\"role\":\"system\",\"content\":\"You are a terse maintenance assistant. Answer in one short sentence.\"},{\"role\":\"user\",\"content\":\"List three routine checks a maintenance technician performs on a coolant loop.\"}]}" \
    > "$OUT/llamacpp.sse.txt"
  kill "$pid" 2>/dev/null; wait "$pid" 2>/dev/null
  echo "stream probe killed pid=$pid"
  echo "--- first 6 SSE frames ---"; head -c 1400 "$OUT/llamacpp.sse.txt"
  echo; echo "--- delta keys seen ---"
  python3 - <<'PY'
import json, re, pathlib
keys=set(); frames=0
for line in pathlib.Path("./probe-memory/llamacpp.sse.txt").read_text().splitlines():
    if not line.startswith("data: "): continue
    payload=line[6:].strip()
    if payload=="[DONE]": continue
    try: d=json.loads(payload)
    except Exception: continue
    frames+=1
    for ch in d.get("choices") or []:
        keys.update((ch.get("delta") or {}).keys())
print("frames:", frames)
print("delta keys:", sorted(keys))
print("gate reads: content, reasoning ->", "MEASURABLE" if ({"content","reasoning"} & keys) else "TTFT UNMEASURABLE")
PY
}
stream_shape
