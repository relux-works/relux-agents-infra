#!/bin/bash
# Does the top-level `speculative` field still track the launch on a slot that
# has already served a request? That is the reading the fix will depend on, and
# a reader added for a field whose value has not been shown to move with the
# launch is the `/props` mistake again.
set -u
FIX=/Users/alexis/src/relux-works/relux-agents-infra/.temp/TASK-260828-2jbufw/fixture/qwen2.5-0.5b-instruct-q8_0.gguf
OUT=./probe-slots; mkdir -p "$OUT"
one() {
  local label="$1" port="$2"; shift 2
  /opt/homebrew/bin/llama-server --model "$FIX" --host 127.0.0.1 --port "$port" \
    --ctx-size 8192 --ubatch-size 2048 --reasoning-effort medium --no-webui "$@" \
    > "$OUT/$label.srv.log" 2>&1 &
  local pid=$!
  for i in $(seq 1 90); do
    [ "$(curl -s -m 2 -o /dev/null -w '%{http_code}' http://127.0.0.1:$port/health)" = "200" ] && break
    sleep 1
  done
  # Drive every slot so none is left in the unused shape.
  for n in 1 2 3 4 5 6 7 8; do
    curl -s -m 60 "http://127.0.0.1:$port/v1/chat/completions" -H 'Content-Type: application/json' \
      -d "{\"model\":\"x\",\"messages\":[{\"role\":\"user\",\"content\":\"ticket $n\"}],\"max_tokens\":8}" -o /dev/null
  done
  curl -s -m 5 -o "$OUT/$label.used.slots.json" "http://127.0.0.1:$port/slots"
  kill "$pid" 2>/dev/null; wait "$pid" 2>/dev/null
  echo "killed $label pid=$pid"
}
one "used-none" 29811 --spec-type none
one "used-ngram" 29813 --spec-type ngram-mod
python3 - <<'PY'
import json
for label in ("used-none","used-ngram"):
    d=json.load(open(f"./probe-slots/{label}.used.slots.json"))
    print(f"--- {label}: {len(d)} slots")
    for s in d:
        p = s.get("params")
        nested = p.get("speculative") if isinstance(p, dict) else None
        print(f"   slot {s['id']}: params={isinstance(p,dict)} top-level speculative={s.get('speculative')!r} params.speculative={nested!r}")
    # the shipped reader
    named=False; spec=None
    for s in d:
        params = s.get("params") if isinstance(s.get("params"), dict) else s
        v = params.get("speculative")
        if isinstance(v, bool):
            named=True
            if v: spec=True
    print(f"   SHIPPED reader -> {'reported(True)' if spec else ('reported(False)' if named else 'UNREAD')}")
    # the additive reader
    named=False; spec=False
    for s in d:
        vals=[]
        if isinstance(s.get("speculative"), bool): vals.append(s["speculative"])
        p=s.get("params")
        if isinstance(p, dict) and isinstance(p.get("speculative"), bool): vals.append(p["speculative"])
        if vals:
            named=True
            if any(vals): spec=True
    print(f"   ADDITIVE reader -> {'reported(True)' if spec else ('reported(False)' if named else 'UNREAD')}")
PY
