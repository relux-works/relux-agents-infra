#!/bin/bash
# Does GET /slots on THIS build name `speculative`, and where, and does the
# field this gate reads track the launch? Same fixture and same question the
# earlier task answered; the answer is different on this build's response shape.
set -u
FIX=/Users/alexis/src/relux-works/relux-agents-infra/.temp/TASK-260828-2jbufw/fixture/qwen2.5-0.5b-instruct-q8_0.gguf
OUT=./probe-slots; mkdir -p "$OUT"
run() {
  local label="$1"; shift
  local port=$((29400 + RANDOM % 100))
  /opt/homebrew/bin/llama-server --model "$FIX" --host 127.0.0.1 --port "$port" \
    --ctx-size 8192 --ubatch-size 2048 --no-webui "$@" > "$OUT/$label.log" 2>&1 &
  local pid=$!
  for i in $(seq 1 60); do
    curl -s -m 2 "http://127.0.0.1:$port/v1/models" -o /dev/null && break
    kill -0 $pid 2>/dev/null || { echo "$label: DIED"; return; }
    sleep 1
  done
  echo "--- $label (args: $*) ---"
  echo -n "  /slots status: "; curl -s -m 5 -o "$OUT/$label.slots.json" -w '%{http_code}\n' "http://127.0.0.1:$port/slots"
  echo "  /slots body: $(head -c 900 "$OUT/$label.slots.json")"
  echo -n "  /props speculative.types: "
  curl -s -m 5 "http://127.0.0.1:$port/props" -o "$OUT/$label.props.json"
  python3 -c "
import json,sys
d=json.load(open('$OUT/$label.props.json'))
p=(d.get('default_generation_settings') or {}).get('params') or d.get('params') or {}
print(p.get('speculative.types'))
" 2>/dev/null || echo "(unreadable)"
  kill $pid 2>/dev/null; wait $pid 2>/dev/null
}
run "spec-none" --spec-type none
run "spec-ngram-mod" --spec-type ngram-mod
echo "=== field placement ==="
for f in "$OUT"/*.slots.json; do
  echo -n "$(basename $f): "
  python3 -c "
import json,sys
d=json.load(open('$f'))
s=d[0] if isinstance(d,list) and d else {}
print('top-level speculative =', s.get('speculative'), '| params present =', 'params' in s, '| params.speculative =', (s.get('params') or {}).get('speculative'))
"
done
