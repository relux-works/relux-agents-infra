#!/usr/bin/env python3
"""Timestamp every SSE frame of one long_prompt_8k completion, per runtime.

`BenchmarkHTTPDriver.streamed` starts its clock on the first frame carrying
`delta.content` or `delta.reasoning`. llama.cpp spells reasoning
`reasoning_content`, so on that runtime the clock starts at the first CONTENT
token -- after the whole think block. This script measures both instants so the
gate's number and the true one can be told apart.
"""
import json, sys, time, urllib.request

url, model, out = sys.argv[1], sys.argv[2], sys.argv[3]
suite = json.load(open("/Users/alexis/src/relux-works/relux-agents-infra/.temp/"
                       "STORY-260828-2faxgm/worktree/tools/mlx-swift-runtime-prototype/"
                       "examples/benchmark-prompts.json"))
prefix = suite["filler_paragraph"] * 215
content = prefix + "\n\n" + suite["scenarios"]["long_prompt_8k"]["prompt"]
body = json.dumps({
    "model": model, "stream": True, "max_tokens": 256,
    "temperature": 0.0, "top_p": 1.0,
    "messages": [{"role": "system", "content": suite["system_prompt"]},
                 {"role": "user", "content": content}],
}).encode()

req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"})
sent = time.time()
frames = []
with urllib.request.urlopen(req, timeout=1800) as resp:
    for raw in resp:
        line = raw.decode("utf-8", "replace").strip()
        if not line.startswith("data: "):
            continue
        payload = line[6:]
        if payload == "[DONE]":
            break
        try:
            d = json.loads(payload)
        except Exception:
            continue
        frames.append((time.time() - sent, d))

first_any = first_content = None
n_reason = n_content = 0
usage = {}
for t, d in frames:
    if d.get("usage"):
        usage = d["usage"]
    for ch in d.get("choices") or []:
        delta = ch.get("delta") or {}
        c = delta.get("content") if isinstance(delta.get("content"), str) else ""
        r = (delta.get("reasoning") if isinstance(delta.get("reasoning"), str) else "") or \
            (delta.get("reasoning_content") if isinstance(delta.get("reasoning_content"), str) else "")
        if r:
            n_reason += 1
            if first_any is None: first_any = t
        if c:
            n_content += 1
            if first_any is None: first_any = t
            if first_content is None: first_content = t
last = frames[-1][0] if frames else None
result = {
    "runtime": out, "frames": len(frames), "usage": usage,
    "reasoning_frames": n_reason, "content_frames": n_content,
    "first_any_text_s": first_any, "first_content_s": first_content, "last_frame_s": last,
}
pt = usage.get("prompt_tokens"); ct = usage.get("completion_tokens")
if pt and first_any: result["true_prefill_tok_s"] = pt / first_any
if pt and first_content: result["gate_prefill_tok_s"] = pt / first_content
if ct and ct > 1 and first_any and last and last > first_any:
    result["true_decode_tok_s"] = (ct - 1) / (last - first_any)
if ct and ct > 1 and first_content and last and last > first_content:
    result["gate_decode_tok_s"] = (ct - 1) / (last - first_content)
print(json.dumps(result, indent=2))
json.dump(result, open(f"probe-ttft-{out}.json", "w"), indent=2)
