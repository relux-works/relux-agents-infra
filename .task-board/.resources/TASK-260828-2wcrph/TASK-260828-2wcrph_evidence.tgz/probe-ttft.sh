#!/bin/bash
set -u
GGUF=/Users/alexis/src/local-models/Qwen3.8-27B-Uncensored-GGUF-Q8_0/Qwen3.8-27B-Uncensored-OrcaRouter-Q8_0.gguf
MLX=/Users/alexis/src/local-models/Qwen3.8-27B-Uncensored-MLX-8bit

/opt/homebrew/bin/llama-server --model "$GGUF" --host 127.0.0.1 --port 18061 \
  --ctx-size 8192 --ubatch-size 2048 --reasoning-effort medium --no-webui --spec-type none \
  > probe-ttft-llamacpp.srv.log 2>&1 &
LPID=$!
for i in $(seq 1 300); do
  [ "$(curl -s -m 2 -o /dev/null -w '%{http_code}' http://127.0.0.1:18061/health)" = "200" ] && break
  sleep 1
done
python3 probe-ttft.py http://127.0.0.1:18061/v1/chat/completions "$GGUF" llamacpp
kill $LPID; wait $LPID 2>/dev/null; echo "killed llamacpp pid=$LPID"
sleep 20

/Users/alexis/.local/bin/mlx_lm-relux.server --model "$MLX" --host 127.0.0.1 --port 18062 \
  --prompt-cache-size 1 --prompt-cache-bytes 8GB --prefill-step-size 2048 \
  --chat-template-args '{"reasoning_effort": "medium"}' > probe-ttft-python.srv.log 2>&1 &
PPID_=$!
for i in $(seq 1 600); do
  curl -s -m 2 -o /dev/null http://127.0.0.1:18062/v1/models && break
  sleep 1
done
python3 probe-ttft.py http://127.0.0.1:18062/v1/chat/completions "$MLX" python-mlx-lm
kill $PPID_; wait $PPID_ 2>/dev/null; echo "killed python pid=$PPID_"
