#!/usr/bin/env python3
"""Render one benchmark-run session's two records as a comparison table.

Reads only what the gate wrote. Reports prompt-token skew per scenario BEFORE
any latency number, because a latency comparison across two different prompts
is not a runtime comparison.
"""
import json, sys, os

GIB = 1024 ** 3

def load(session):
    recs = {}
    d = os.path.join(session, "records")
    for name in sorted(os.listdir(d)):
        if name.endswith(".json"):
            recs[name[:-5]] = json.load(open(os.path.join(d, name)))
    return recs

def fmt(v, unit="", nd=2):
    if v is None:
        return "unmeasured"
    if unit == "GiB":
        return f"{v / GIB:.2f} GiB"
    if unit == "s":
        return f"{v:.2f}s"
    if unit == "tok/s":
        return f"{v:.2f}"
    if unit == "int":
        return f"{v:,}"
    return f"{v:.{nd}f}"

def main(session):
    recs = load(session)
    base = recs.get("python-mlx-lm")
    cand = recs.get("llamacpp")
    print(f"# session: {session}")
    for role, r in (("baseline", base), ("candidate", cand)):
        if r is None:
            print(f"{role}: NO RECORD")
            continue
        print(f"\n## {role}: {r['runtime']}")
        print(f"  profile          : {r['provenance']['profile']}")
        print(f"  argv             : {' '.join(r['provenance']['launchArgv'])}")
        print(f"  contextPolicy    : {r['pins']['contextPolicy']}")
        print(f"  speculation      : {r['pins']['speculation']}")
        print(f"  modelOfRecord    : {r['pins']['modelOfRecord']}")
        print(f"  quantization     : {r['pins']['quantization']}")
        print(f"  pass peak footpr.: {fmt(r.get('peakPhysicalFootprintBytes'), 'GiB')}")
        print(f"  window           : {r['startedAtUnixSeconds']:.1f} .. {r['finishedAtUnixSeconds']:.1f} "
              f"({r['finishedAtUnixSeconds'] - r['startedAtUnixSeconds']:.1f}s)")
        print(f"  declaredAsymmetries:")
        for a in r.get("declaredAsymmetries", []):
            print(f"    - {a}")

    if not (base and cand):
        return 0

    b = {s["name"]: s for s in base["scenarios"]}
    c = {s["name"]: s for s in cand["scenarios"]}
    names = [n for n in b if n in c] + [n for n in c if n not in b]

    print("\n## prompt-token parity (checked before any latency number)")
    print(f"{'scenario':26} {'baseline':>12} {'candidate':>12} {'skew':>8}  verdict")
    for n in names:
        pb, pc = b.get(n, {}).get("promptTokens"), c.get(n, {}).get("promptTokens")
        if pb and pc:
            skew = max(pb, pc) / min(pb, pc)
            v = "comparable" if skew <= 1.1 else "SKEWED — latency not comparable"
            print(f"{n:26} {pb:>12,} {pc:>12,} {skew:>8.4f}  {v}")
        else:
            print(f"{n:26} {str(pb):>12} {str(pc):>12} {'-':>8}  unmeasured on at least one side")

    print("\n## per-scenario measurements")
    cols = [
        ("succeeded", lambda s: str(s.get("succeeded")), ""),
        ("failureMode", lambda s: s.get("failureMode") or "-", ""),
        ("promptTokens", lambda s: fmt(s.get("promptTokens"), "int"), ""),
        ("completionTokens", lambda s: fmt(s.get("completionTokens"), "int"), ""),
        ("TTFT", lambda s: fmt(s.get("timeToFirstTokenSeconds"), "s"), ""),
        ("prefill tok/s", lambda s: fmt(s.get("prefillTokensPerSecond"), "tok/s"), ""),
        ("decode tok/s", lambda s: fmt(s.get("decodeTokensPerSecond"), "tok/s"), ""),
        ("wallClock", lambda s: fmt(s.get("wallClockSeconds"), "s"), ""),
        ("peak footprint", lambda s: fmt(s.get("peakPhysicalFootprintBytes"), "GiB"), ""),
        ("process peak", lambda s: fmt(s.get("processPeakSoFarBytes"), "GiB"), ""),
        ("host load max", lambda s: fmt(s.get("hostLoadAverageMax")), ""),
    ]
    for n in names:
        print(f"\n### {n}")
        print(f"{'metric':20} {'python-mlx-lm':>22} {'llamacpp':>22}")
        for label, get, _ in cols:
            sb = b.get(n)
            sc = c.get(n)
            print(f"{label:20} {(get(sb) if sb else 'absent'):>22} {(get(sc) if sc else 'absent'):>22}")

    dec = os.path.join(session, "decision.json")
    print("\n## gate decision")
    if os.path.exists(dec):
        print(open(dec).read())
    else:
        print("no decision.json — the gate refused the pair before it could score them")
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
