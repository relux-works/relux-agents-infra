#!/usr/bin/env python3
"""Probe streamed TTFT/prefill/decode without treating SSE frames as tokens."""

from __future__ import annotations

import argparse
import json
import time
import urllib.request
from pathlib import Path
from typing import Any


def is_token_count(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value >= 0


def authoritative_usage(frames: list[dict[str, Any]]) -> tuple[dict[str, int] | None, str | None]:
    readings: list[dict[str, Any]] = []
    for frame in frames:
        usage = frame["data"].get("usage")
        if isinstance(usage, dict) and usage:
            readings.append(usage)
    if not readings:
        return None, "stream carried no non-empty usage object"

    normalized: list[dict[str, int]] = []
    for usage in readings:
        prompt = usage.get("prompt_tokens")
        completion = usage.get("completion_tokens")
        if not is_token_count(prompt) or not is_token_count(completion):
            return None, "streamed usage omitted a valid prompt_tokens or completion_tokens count"
        current = {"prompt_tokens": prompt, "completion_tokens": completion}
        total = usage.get("total_tokens")
        if total is not None:
            if not is_token_count(total) or total != prompt + completion:
                return None, "streamed usage total_tokens was invalid or inconsistent"
            current["total_tokens"] = total
        normalized.append(current)

    first = normalized[0]
    if any(value != first for value in normalized[1:]):
        return None, "stream carried conflicting usage counts"
    return first, None


def summarize(runtime: str, frames: list[dict[str, Any]], done_elapsed_s: float | None) -> dict[str, Any]:
    first_text_s: float | None = None
    first_content_s: float | None = None
    last_text_s: float | None = None
    reasoning_frames = 0
    content_frames = 0

    for frame in frames:
        elapsed = frame["elapsed_s"]
        for choice in frame["data"].get("choices") or []:
            delta = choice.get("delta") or {}
            content = delta.get("content") if isinstance(delta.get("content"), str) else ""
            reasoning = delta.get("reasoning") if isinstance(delta.get("reasoning"), str) else ""
            reasoning_content = (
                delta.get("reasoning_content")
                if isinstance(delta.get("reasoning_content"), str)
                else ""
            )
            if reasoning or reasoning_content:
                reasoning_frames += 1
            if content:
                content_frames += 1
                if first_content_s is None:
                    first_content_s = elapsed
            if reasoning or reasoning_content or content:
                if first_text_s is None:
                    first_text_s = elapsed
                last_text_s = elapsed

    usage, usage_error = authoritative_usage(frames)
    decode_rate: float | None = None
    decode_error = usage_error
    if usage is not None:
        completion_tokens = usage["completion_tokens"]
        if completion_tokens <= 1:
            decode_error = "completion_tokens must exceed one to measure decode"
        elif first_text_s is None or last_text_s is None or last_text_s <= first_text_s:
            decode_error = "stream did not expose a positive first-to-last text interval"
        else:
            decode_rate = (completion_tokens - 1) / (last_text_s - first_text_s)
            decode_error = None

    prefill_rate: float | None = None
    if usage is not None and first_text_s is not None and first_text_s > 0:
        prefill_rate = usage["prompt_tokens"] / first_text_s

    return {
        "runtime": runtime,
        "stream_options_requested": {"include_usage": True},
        "usage_arrived_and_verified": usage is not None,
        "usage": usage,
        "usage_error": usage_error,
        "ttft_seconds": first_text_s,
        "prefill_tokens_per_second": prefill_rate,
        "decode_tokens_per_second": decode_rate,
        "decode_status": "measured" if decode_rate is not None else "unknown",
        "decode_unknown_reason": decode_error,
        "last_text_seconds": last_text_s,
        "first_content_seconds": first_content_s,
        "done_seconds": done_elapsed_s,
        "diagnostic_sse_frame_count": len(frames),
        "diagnostic_reasoning_frame_count": reasoning_frames,
        "diagnostic_content_frame_count": content_frames,
        "sse_frame_counts_used_as_token_counts": False,
    }


def build_request(suite_path: Path, model: str) -> dict[str, Any]:
    suite = json.loads(suite_path.read_text())
    prefix = suite["filler_paragraph"] * 215
    content = prefix + "\n\n" + suite["scenarios"]["long_prompt_8k"]["prompt"]
    return {
        "model": model,
        "stream": True,
        "stream_options": {"include_usage": True},
        "max_tokens": 256,
        "temperature": 0.0,
        "top_p": 1.0,
        "messages": [
            {"role": "system", "content": suite["system_prompt"]},
            {"role": "user", "content": content},
        ],
    }


def run_probe(args: argparse.Namespace) -> dict[str, Any]:
    request_body = build_request(args.suite, args.model)
    encoded = json.dumps(request_body).encode()
    request = urllib.request.Request(
        args.url,
        data=encoded,
        headers={"Content-Type": "application/json"},
    )
    started = time.monotonic()
    frames: list[dict[str, Any]] = []
    done_elapsed_s: float | None = None
    with urllib.request.urlopen(request, timeout=args.timeout) as response:
        for raw in response:
            elapsed = time.monotonic() - started
            line = raw.decode("utf-8", "replace").strip()
            if not line.startswith("data: "):
                continue
            payload = line[6:]
            if payload == "[DONE]":
                done_elapsed_s = elapsed
                break
            try:
                data = json.loads(payload)
            except json.JSONDecodeError:
                data = {"_unparsed_payload": payload}
            frames.append({"elapsed_s": elapsed, "data": data})

    summary = summarize(args.runtime, frames, done_elapsed_s)
    raw_evidence = {
        "runtime": args.runtime,
        "url": args.url,
        "request": request_body,
        "frames": frames,
        "done_elapsed_s": done_elapsed_s,
        "summary": summary,
    }
    args.raw_out.write_text(json.dumps(raw_evidence, indent=2) + "\n")
    args.summary_out.write_text(json.dumps(summary, indent=2) + "\n")
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--runtime", required=True)
    parser.add_argument("--suite", required=True, type=Path)
    parser.add_argument("--raw-out", required=True, type=Path)
    parser.add_argument("--summary-out", required=True, type=Path)
    parser.add_argument("--timeout", type=int, default=1800)
    args = parser.parse_args()
    summary = run_probe(args)
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
