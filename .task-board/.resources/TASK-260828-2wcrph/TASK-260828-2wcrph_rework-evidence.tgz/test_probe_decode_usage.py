#!/usr/bin/env python3

import unittest

from probe_decode_usage import summarize


def frame(elapsed_s, data):
    return {"elapsed_s": elapsed_s, "data": data}


class ProbeDecodeUsageTests(unittest.TestCase):
    def test_authoritative_usage_drives_decode_rate_not_frame_count(self):
        frames = [
            frame(2.0, {"choices": [{"delta": {"reasoning_content": "a"}}]}),
            frame(2.1, {"choices": [{"delta": {"reasoning_content": "many tokens"}}]}),
            frame(5.0, {"choices": [{"delta": {"content": "z"}}]}),
            frame(
                5.1,
                {
                    "choices": [],
                    "usage": {
                        "prompt_tokens": 100,
                        "completion_tokens": 4,
                        "total_tokens": 104,
                    },
                },
            ),
        ]

        result = summarize("runtime", frames, 5.2)

        self.assertEqual(result["decode_status"], "measured")
        self.assertAlmostEqual(result["decode_tokens_per_second"], 1.0)
        self.assertEqual(result["diagnostic_sse_frame_count"], 4)
        self.assertFalse(result["sse_frame_counts_used_as_token_counts"])

    def test_missing_usage_reports_unknown_despite_multiple_text_frames(self):
        frames = [
            frame(2.0, {"choices": [{"delta": {"reasoning": "a"}}]}),
            frame(3.0, {"choices": [{"delta": {"content": "b"}}]}),
            frame(4.0, {"choices": [{"delta": {"content": "c"}}]}),
        ]

        result = summarize("runtime", frames, 4.1)

        self.assertEqual(result["decode_status"], "unknown")
        self.assertIsNone(result["decode_tokens_per_second"])
        self.assertIn("no non-empty usage", result["decode_unknown_reason"])

    def test_malformed_usage_reports_unknown(self):
        frames = [
            frame(2.0, {"choices": [{"delta": {"reasoning": "a"}}]}),
            frame(3.0, {"choices": [{"delta": {"content": "b"}}]}),
            frame(3.1, {"choices": [], "usage": {"completion_tokens": 2}}),
        ]

        result = summarize("runtime", frames, 3.2)

        self.assertEqual(result["decode_status"], "unknown")
        self.assertIsNone(result["decode_tokens_per_second"])
        self.assertIn("omitted a valid", result["decode_unknown_reason"])

    def test_inconsistent_total_reports_unknown(self):
        frames = [
            frame(2.0, {"choices": [{"delta": {"reasoning": "a"}}]}),
            frame(3.0, {"choices": [{"delta": {"content": "b"}}]}),
            frame(
                3.1,
                {
                    "choices": [],
                    "usage": {
                        "prompt_tokens": 100,
                        "completion_tokens": 2,
                        "total_tokens": 999,
                    },
                },
            ),
        ]

        result = summarize("runtime", frames, 3.2)

        self.assertEqual(result["decode_status"], "unknown")
        self.assertIn("inconsistent", result["decode_unknown_reason"])


if __name__ == "__main__":
    unittest.main()
