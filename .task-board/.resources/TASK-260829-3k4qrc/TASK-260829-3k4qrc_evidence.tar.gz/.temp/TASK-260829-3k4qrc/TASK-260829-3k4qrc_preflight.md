# TASK-260829-3k4qrc Preflight

- Spawn/run start: `2026-08-29T15:18:16Z`.
- Host gate accepted: `2026-08-29T15:21:50Z`; wait from spawn: 3m34s.
- Platform: macOS on Apple silicon; the project benchmark target is macOS arm64.
- Tool readiness: `task-board 0.24.3-167-g42c7d2b7`, `model-harness v1.6.1-44-gd91d6fc`, `llama-server 0.3.0 b10621-c1d0e7a00`, Swift 6.3.3, Xcode 26.6, `git 2.53.0`, and `rg 15.2.0` all executed and produced identifying output.
- Accepted instrumentation commit under test: `f47ffe01bb9f758fd7007aae012bfe76004c278e` (`TASK-260829-3cwcb6`). Evidence was gathered at this Story worktree commit. The worktree is 24 commits behind local `main`; per assignment, no switch/rebase/merge was attempted because integration belongs to the orchestrator.
- Ports: no listener on TCP `18000-18999`; selected task port `18331`.
- Model processes: no `mlx_lm`, `llama-server`, or prototype runtime alive. The `pgrep` self-match was the inspection shell itself, not a model process.
- Ollama: `127.0.0.1:11434` listener present, `ollama serve` RSS 14,544 KiB; no Ollama model process was resident. It was left untouched.
- Memory: `hw.memsize=68,719,476,736` bytes. `memory_pressure -Q` reported 84% system-wide free pressure headroom; `top` separately reported 7,511 MiB immediately unused, 3,826 MiB compressor, and 5,829 MiB wired. No process was signalled to make room.
- Host load at gate: 9.11 / 10.77 / 12.91; the host was not idle, and this remains diagnostic rather than silently omitted.
- Comparison protocol: one `benchmark-run` process launches the Python baseline first and llama.cpp second, sequentially, with a 20-second settle. MTP is explicitly requested off by `--spec-type none` and must additionally be observed off by the gate.
- Expected refusal: the Python baseline reports `kv=unbounded`, while the full llama.cpp capacity profile reports `kv=76800`; production admission must retain both records and refuse scoring the non-comparable `contextPolicy` dimension with exit 4.
