#!/usr/bin/env python3
"""Render one `benchmark-run` session as the number set of record.

Reads only what the gate wrote. Units are stated on every row: decode is tokens
per second and higher is better; memory is a conservative resident upper bound
in bytes; TTFT and wall clock are seconds and lower is better.

Prompt-token parity is printed before any latency number, because a latency
comparison across two different prompts is not a runtime comparison. Every
dimension the gate refused is printed as refused; nothing is omitted for being
inconvenient.
"""
import json
import os
import sys

GIB = 1024 ** 3


def load(session):
    recs = {}
    d = os.path.join(session, "records")
    for name in sorted(os.listdir(d)):
        if name.endswith(".json"):
            recs[name[:-5]] = json.load(open(os.path.join(d, name)))
    return recs


def gib(v):
    return "unmeasured" if v is None else f"{v:,} B ({v / GIB:.2f} GiB)"


def num(v, unit="", nd=3):
    if v is None:
        return "unmeasured"
    if unit == "int":
        return f"{v:,}"
    return f"{v:.{nd}f}{unit}"


def memory_line(block):
    if not block:
        return "absent"
    status = block.get("status")
    scored = block.get("scoredBytes")
    peak = block.get("peakSample") or {}
    issues = block.get("issues") or []
    bits = [
        f"status={status}",
        f"scored={gib(scored)}",
        f"mach={gib(peak.get('machPhysicalFootprintBytes'))}",
        f"mapped<={gib(peak.get('residentMappedFileBytesUpperBound'))}"
        + f" raw={peak.get('vmmapResidentMappedFileRaw')!r}",
        f"samples ok/failed/malformed="
        f"{block.get('successfulSampleCount')}/{block.get('readFailureCount')}"
        f"/{block.get('malformedSampleCount')}",
    ]
    if block.get("mappedFileObservationLimitSeconds") is not None:
        bits.append(f"mappedLimit={block['mappedFileObservationLimitSeconds']}s")
    if issues:
        bits.append(f"issues={issues}")
    return "\n      ".join(bits)


def main(session):
    recs = load(session)
    base = recs.get("python-mlx-lm")
    cand = recs.get("llamacpp")
    print(f"# session: {session}")

    print("\n## sealed pass intervals (non-overlap is an admission condition)")
    for role, r in (("baseline", base), ("candidate", cand)):
        if r is None:
            print(f"  {role}: NO RECORD")
            continue
        print(
            f"  {role:9} {r['runtime']:14} "
            f"{r['startedAtUnixSeconds']:.6f} .. {r['finishedAtUnixSeconds']:.6f}"
            f"  ({r['finishedAtUnixSeconds'] - r['startedAtUnixSeconds']:.3f}s)"
        )
    if base and cand:
        overlap = min(base["finishedAtUnixSeconds"], cand["finishedAtUnixSeconds"]) - max(
            base["startedAtUnixSeconds"], cand["startedAtUnixSeconds"]
        )
        print(f"  overlap seconds: {overlap:.3f} (positive would be refused)")

    for role, r in (("baseline", base), ("candidate", cand)):
        if r is None:
            continue
        print(f"\n## {role}: {r['runtime']}")
        print(f"  profile        : {r['provenance']['profile']}")
        print(f"  launch argv    : {' '.join(r['provenance']['launchArgv'])}")
        for k in (
            "contextPolicy",
            "speculation",
            "modelOfRecord",
            "modelDigest",
            "quantization",
            "promptSuiteDigest",
            "maxOutputTokens",
            "temperature",
            "topP",
            "seed",
            "hostIdentity",
        ):
            print(f"  {k:15}: {r['pins'][k]}")
        print(f"  revisions      : {json.dumps(r.get('revisions', {}))[:400]}")
        print(f"  process peak   : {memory_line(r.get('peakResidentMemory'))}")
        print(f"  legacy footprint (NOT scored): {gib(r.get('peakPhysicalFootprintBytes'))}")

    if not (base and cand):
        return 0

    b = {s["name"]: s for s in base["scenarios"]}
    c = {s["name"]: s for s in cand["scenarios"]}
    names = [s["name"] for s in base["scenarios"]] + [
        s["name"] for s in cand["scenarios"] if s["name"] not in b
    ]

    print("\n## prompt-token parity, before any latency number")
    print(f"{'scenario':26} {'baseline':>10} {'candidate':>10} {'skew':>8}  verdict")
    for n in names:
        pb, pc = b.get(n, {}).get("promptTokens"), c.get(n, {}).get("promptTokens")
        if pb and pc:
            skew = max(pb, pc) / min(pb, pc)
            v = "comparable" if skew <= 1.1 else "SKEWED - latency not comparable"
            print(f"{n:26} {pb:>10,} {pc:>10,} {skew:>8.4f}  {v}")
        else:
            print(f"{n:26} {str(pb):>10} {str(pc):>10} {'-':>8}  unmeasured on a side")

    print("\n## sealed cached-token telemetry (one-sided hit = non-comparable)")
    for n in names:
        print(f"  {n:26} baseline={json.dumps(b.get(n, {}).get('cacheReuse'))!s:60}"
              f" candidate={json.dumps(c.get(n, {}).get('cacheReuse'))!s}")

    print("\n## per-scenario measurements")
    rows = [
        ("succeeded", lambda s: str(s.get("succeeded"))),
        ("failureMode", lambda s: s.get("failureMode") or "-"),
        ("promptTokens", lambda s: num(s.get("promptTokens"), "int")),
        ("completionTokens", lambda s: num(s.get("completionTokens"), "int")),
        ("TTFT seconds (lower better)", lambda s: num(s.get("timeToFirstTokenSeconds"), "s")),
        ("prefill tok/s (higher better)", lambda s: num(s.get("prefillTokensPerSecond"))),
        ("decode tok/s (higher better)", lambda s: num(s.get("decodeTokensPerSecond"))),
        ("wall clock seconds", lambda s: num(s.get("wallClockSeconds"), "s")),
        ("host load max", lambda s: num(s.get("hostLoadAverageMax"))),
    ]
    for n in names:
        print(f"\n### {n}")
        sb, sc = b.get(n), c.get(n)
        print(f"{'metric':32} {'python-mlx-lm':>26} {'llamacpp':>26}")
        for label, get in rows:
            print(
                f"{label:32} {(get(sb) if sb else 'absent'):>26} "
                f"{(get(sc) if sc else 'absent'):>26}"
            )
        for label, key in (
            ("scenario memory", "peakResidentMemory"),
            ("process-so-far memory", "processResidentMemoryPeakSoFar"),
        ):
            print(f"  {label} baseline:\n      {memory_line((sb or {}).get(key))}")
            print(f"  {label} candidate:\n      {memory_line((sc or {}).get(key))}")

    print("\n## declared asymmetries carried by both records")
    for a in base.get("declaredAsymmetries", []):
        print(f"  - {a}")

    print("\n## gate decision")
    dec = os.path.join(session, "decision.json")
    if not os.path.exists(dec):
        print("  NO decision.json - the gate refused the pair before scoring it.")
        return 0
    d = json.load(open(dec))
    print(f"  accepted: {d['accepted']}")
    print(f"  blockers ({len(d['blockers'])}):")
    for x in d["blockers"]:
        print(f"    - {x}")
    print(f"{'scenario':26} {'metric':42} {'verdict':16} {'ratio':>10}  bound")
    for delta in d["deltas"]:
        print(
            f"{delta['scenario']:26} {delta['metric']:42} {delta['verdict']:16} "
            f"{(f'{delta['ratio']:.6f}' if delta.get('ratio') is not None else '-'):>10}"
            f"  {delta.get('admissibleRatio')}"
        )
    print("\n## raw scored values behind those ratios")
    for delta in d["deltas"]:
        print(
            f"  {delta['scenario']:26} {delta['metric']:42} "
            f"baseline={delta.get('baseline')} candidate={delta.get('candidate')}"
        )
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
