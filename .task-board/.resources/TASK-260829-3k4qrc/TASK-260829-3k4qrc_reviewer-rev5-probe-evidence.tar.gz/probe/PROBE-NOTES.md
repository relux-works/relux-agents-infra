# TASK-260829-3k4qrc rev5 reviewer probe — llama-server live surface

Independent re-probe of item 1. Not the producer's probe; my own launch.

- binary: `/opt/homebrew/bin/llama-server`, `version: 0.3.0 (build 10621, commit c1d0e7a00)`
- model: the same pinned GGUF the pair used
- launch: `-c 4096 -np 1 --ubatch-size 2048 --batch-size 2048 --reasoning-effort medium --reasoning on --metrics --slots --no-webui`
  (the producer's probe did NOT pass `--metrics`; I added it so `/metrics` was reachable)
- endpoints reached: `/props` 200, `/slots` 200, `/metrics` 200, `/v1/models` 200,
  `/models` 200, `/health` 200; `/v1/props` 404, `/api/show` 404
- teardown: own PID only, `pgrep -fl llama-server` empty afterwards

Result: no `n_batch` / `n_ubatch` / prefill-chunk field on any 200 endpoint.
Only `reason`-shaped keys anywhere in any payload:

    "reasoning_format":"none"          <- read "none" under --reasoning-effort medium
    "reasoning_in_content":false
    "supports_preserve_reasoning":true <- chat_template_caps, a template capability
    "supports_reasoning_effort":true   <- chat_template_caps, a template capability

`/metrics` is runtime counters only (`prompt_tokens_total`, `n_decode_total`, ...),
no configuration. The default-verbosity startup log prints no `n_batch`/`n_ubatch`
either.

`chat_template_caps.supports_reasoning_effort` is the closest false friend: it is a
boolean capability of the chat template, not the effective effort in force.

Conclusion: the `contextPolicy` prefill-step/reasoning refusal is irreducible on this
build's live surface. The producer's finding stands, reproduced independently.
