#!/bin/bash
set -u
OUT="$(cd "$(dirname "$0")" && pwd)"
GGUF=/Users/alexis/src/local-models/Qwen3.8-27B-Uncensored-GGUF-Q8_0/Qwen3.8-27B-Uncensored-OrcaRouter-Q8_0.gguf
PORT=18431
llama-server -m "$GGUF" --port "$PORT" --host 127.0.0.1 \
  -c 4096 -np 1 --ubatch-size 2048 --batch-size 2048 \
  --reasoning-effort medium --reasoning on \
  --metrics --slots --no-webui \
  > "$OUT/server.log" 2>&1 &
PID=$!
echo "pid=$PID" > "$OUT/server.pid"
for i in $(seq 1 240); do
  if curl -sf "http://127.0.0.1:$PORT/health" -o "$OUT/health.json" 2>/dev/null; then
    grep -q '"status"' "$OUT/health.json" && break
  fi
  sleep 1
done
echo "--- health ---"; cat "$OUT/health.json" 2>/dev/null; echo
for ep in props slots metrics v1/models models health "v1/props" "api/show"; do
  code=$(curl -s -o "$OUT/ep-$(echo "$ep" | tr '/' '_').out" -w '%{http_code}' "http://127.0.0.1:$PORT/$ep")
  echo "GET /$ep -> $code ($(wc -c < "$OUT/ep-$(echo "$ep" | tr '/' '_').out") bytes)"
done
kill "$PID" 2>/dev/null
wait "$PID" 2>/dev/null
echo "server stopped"
