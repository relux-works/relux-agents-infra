#!/bin/zsh
set -euo pipefail

story_id="STORY-260830-ec4xfi"
story_branch="refs/heads/task-board/story/STORY-260830-ec4xfi"
status_json=".temp/TASK-260830-r1uh4v/worktree-status-pre-edit-01.json"

git fetch origin main
task-board worktree status "$story_id" --json > "$status_json"

fetched_oid="$(git rev-parse FETCH_HEAD)"
remote_oid="$(git rev-parse refs/remotes/origin/main)"
local_base_oid="$(git rev-parse refs/heads/main)"
story_branch_oid="$(git rev-parse "$story_branch")"
workspace_head_oid="$(git rev-parse HEAD)"
selected_base_oid="$(jq -er '.workspaces[0].status.workspace.selected_base_oid' "$status_json")"
initial_base_oid="$(jq -er '.workspaces[0].status.workspace.initial_base_oid' "$status_json")"
current_base_oid="$(jq -er '.workspaces[0].status.workspace.current_base_oid' "$status_json")"
checkpoint_oid="$(jq -er '.workspaces[0].status.workspace.checkpoint_oid' "$status_json")"

print "FETCH_HEAD=$fetched_oid"
print "origin/main=$remote_oid"
print "main=$local_base_oid"
print "selected_base_oid=$selected_base_oid"
print "initial_base_oid=$initial_base_oid"
print "current_base_oid=$current_base_oid"
print "checkpoint_oid=$checkpoint_oid"
print "story_branch_HEAD=$story_branch_oid"
print "workspace_HEAD=$workspace_head_oid"

for observed in \
  "$remote_oid" \
  "$local_base_oid" \
  "$selected_base_oid" \
  "$initial_base_oid" \
  "$current_base_oid" \
  "$checkpoint_oid" \
  "$story_branch_oid" \
  "$workspace_head_oid"
do
  [[ "$observed" == "$fetched_oid" ]]
done

[[ -z "$(git status --short --untracked-files=all)" ]]
print "base_equality=verified"
