#!/bin/zsh
set -euo pipefail

story_id="STORY-260830-ec4xfi"
story_branch="refs/heads/task-board/story/STORY-260830-ec4xfi"
status_json=".temp/TASK-260830-r1uh4v/worktree-status-final-01.json"

git fetch origin main
task-board worktree status "$story_id" --json > "$status_json"

fetched_oid="$(git rev-parse FETCH_HEAD)"
remote_oid="$(git rev-parse refs/remotes/origin/main)"
local_base_oid="$(git rev-parse refs/heads/main)"
story_branch_oid="$(git rev-parse "$story_branch")"
workspace_head_oid="$(git rev-parse HEAD)"
selected_base_oid="$(jq -er '.workspaces[0].status.workspace.selected_base_oid' "$status_json")"
initial_base_oid="$(jq -er '.workspaces[0].status.workspace.initial_base_oid' "$status_json")"
current_base_oid="$(jq -er '.workspaces[0].status.workspace.current_base_oid' "$status_json")"
checkpoint_oid="$(jq -er '.workspaces[0].status.workspace.checkpoint_oid' "$status_json")"

print "FETCH_HEAD=$fetched_oid"
print "origin/main=$remote_oid"
print "main=$local_base_oid"
print "selected_base_oid=$selected_base_oid"
print "initial_base_oid=$initial_base_oid"
print "current_base_oid=$current_base_oid"
print "checkpoint_oid=$checkpoint_oid"
print "story_branch_HEAD=$story_branch_oid"
print "workspace_HEAD=$workspace_head_oid"

for observed in \
  "$remote_oid" \
  "$local_base_oid" \
  "$selected_base_oid" \
  "$initial_base_oid" \
  "$current_base_oid" \
  "$checkpoint_oid" \
  "$story_branch_oid" \
  "$workspace_head_oid"
do
  [[ "$observed" == "$fetched_oid" ]]
done

typeset -A expected_paths
expected_paths[.instructions/INSTRUCTIONS_WORKFLOW.md]=1
expected_paths[LOGBOOK.md]=1
expected_paths[README.md]=1
expected_paths[tools/agents-infra/internal/infra/infra_test.go]=1

changed_count=0
while IFS= read -r changed_path
do
  [[ -n "$changed_path" ]]
  [[ -n "${expected_paths[$changed_path]-}" ]]
  print "changed_path=$changed_path"
  (( changed_count += 1 ))
done < <(git diff --name-only)

[[ "$changed_count" -eq 4 ]]
[[ -z "$(git diff -- task-board.config.json)" ]]
grep -Fq -- '"fast_mode": true' task-board.config.json
git diff --check

print "candidate_scope=four_audited_paths"
print "codex_fast_mode_preserved=verified"
print "final_base_equality=verified"
