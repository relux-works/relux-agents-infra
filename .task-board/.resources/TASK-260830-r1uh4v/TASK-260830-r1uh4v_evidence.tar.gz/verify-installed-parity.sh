#!/bin/zsh
set -euo pipefail

source_root="$PWD"
installed_agents="/Users/alexis/.agents"
installed_claude="/Users/alexis/.claude"
installed_codex="/Users/alexis/.codex"

cmp "$source_root/.instructions/INSTRUCTIONS_WORKFLOW.md" "$installed_agents/.instructions/INSTRUCTIONS_WORKFLOW.md"
cmp "$source_root/.instructions/INSTRUCTIONS_WORKFLOW.md" "$installed_claude/instructions/INSTRUCTIONS_WORKFLOW.md"
cmp "$source_root/.instructions/INSTRUCTIONS.md" "$installed_agents/.instructions/INSTRUCTIONS.md"
cmp "$source_root/.instructions/INSTRUCTIONS.md" "$installed_claude/instructions/INSTRUCTIONS.md"
cmp "$source_root/.instructions/AGENTS.md" "$installed_agents/.instructions/AGENTS.md"

clauses=(
  "Use a local mirror only when hosted CI cannot execute repository steps for a verified external cause that the agent cannot repair."
  "exact, clean checkout of the PR-head commit"
  "same toolchain versions, environment variables and non-secret configuration, dependent services, and target platform"
  "PR-head SHA, hosted job name, external failure cause, local platform and target, tool versions"
  "Repository-caused code, test, build, configuration, or integration failures remain blocking"
  "Never forge, synthesize, edit, or otherwise misrepresent a hosted check or commit status"
  "remote review, merge queues, or branch protection"
  "hosting platform's real review record and protection rules remain authoritative"
)

for clause in "${clauses[@]}"
do
  grep -Fq -- "$clause" "$installed_codex/AGENTS.md"
done

grep -Fq -- '@~/.agents/.instructions/INSTRUCTIONS_WORKFLOW.md' "$installed_claude/instructions/INSTRUCTIONS.md"
grep -Fq -- '@~/.agents/.instructions/INSTRUCTIONS_WORKFLOW.md' "$installed_agents/.instructions/AGENTS.md"
grep -Fq -- '"fast_mode": true' "$source_root/task-board.config.json"

shasum -a 256 \
  "$source_root/.instructions/INSTRUCTIONS_WORKFLOW.md" \
  "$installed_agents/.instructions/INSTRUCTIONS_WORKFLOW.md" \
  "$installed_claude/instructions/INSTRUCTIONS_WORKFLOW.md"
print "installed_agents_parity=verified"
print "installed_claude_parity=verified"
print "installed_codex_composition=verified"
print "codex_fast_mode_preserved=verified"
