# TASK-260830-rddvxd Tool Readiness

- `task-board --version`: exit 0; `0.24.3-170-g727aa32c`.
- `git --version`: exit 0; `2.53.0`.
- `go version`: exit 0; `go1.25.5 darwin/arm64`.
- `rg --version`: exit 0; `15.2.0`.
- Note: `task-board version` is unsupported; the readiness probe corrected to the supported `task-board --version` form before project work.
- Fresh-base proof after `git fetch origin main`: `HEAD == origin/main == FETCH_HEAD == 3295c7da7151de128f176cf7560a57d54c8f6c0d`; ahead/behind `0/0`.
