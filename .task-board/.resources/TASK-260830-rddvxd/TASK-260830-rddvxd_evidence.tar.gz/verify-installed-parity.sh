#!/bin/zsh
set -euo pipefail

task_repo_root=${0:A:h:h:h}
source_workflow="$task_repo_root/.instructions/INSTRUCTIONS_WORKFLOW.md"
source_claude_index="$task_repo_root/.instructions/INSTRUCTIONS.md"
installed_agents_workflow="${HOME}/.agents/.instructions/INSTRUCTIONS_WORKFLOW.md"
installed_claude_index="${HOME}/.claude/instructions/INSTRUCTIONS.md"
installed_codex="${HOME}/.codex/AGENTS.md"

cmp -s "$source_workflow" "$installed_agents_workflow"
cmp -s "$source_workflow" "${HOME}/.claude/instructions/INSTRUCTIONS_WORKFLOW.md"
cmp -s "$source_claude_index" "$installed_claude_index"

expected_claude_entrypoint=$'# Claude Instructions\n\nLoad all instructions from the Claude runtime instructions directory:\n\n@instructions/INSTRUCTIONS.md\n'
actual_claude_entrypoint=$(<"${HOME}/.claude/CLAUDE.md")
[[ "$actual_claude_entrypoint" == "${expected_claude_entrypoint%$'\n'}" ]]
[[ "$(readlink "${HOME}/.claude/instructions")" == "${HOME}/.agents/.instructions" ]]
rg -q -F '@~/.agents/.instructions/INSTRUCTIONS_WORKFLOW.md' "$installed_claude_index"

while IFS= read -r clause; do
  rg -q -F "$clause" "$installed_codex"
done <<'CLAUSES'
Use a local mirror only when hosted CI cannot execute repository steps for a verified external cause that the agent cannot repair.
exact, clean checkout of the PR-head commit
same toolchain versions, environment variables and non-secret configuration, dependent services, and target platform
PR-head SHA, hosted job name, external failure cause, local platform and target, tool versions
Repository-caused code, test, build, configuration, or integration failures remain blocking
Never forge, synthesize, edit, or otherwise misrepresent a hosted check or commit status
remote review, merge queues, or branch protection
hosting platform's real review record and protection rules remain authoritative
CLAUSES

print -- "installed parity verified for source, Agents, Claude entrypoint/include chain, and rendered Codex clauses"
