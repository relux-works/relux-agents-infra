#!/bin/zsh
set -euo pipefail

repo_root=/Users/alexis/src/relux-works/relux-agents-infra/.temp/STORY-260830-884cmp/worktree
evidence_path="$repo_root/.temp/TASK-260830-rddvxd/worktree-status-final.json"
cd "$repo_root"

workspace_head=$(git rev-parse HEAD)
origin_main=$(git rev-parse origin/main)
local_main=$(git rev-parse main)
fetched_head=$(git rev-parse FETCH_HEAD)

test "$workspace_head" = "$origin_main"
test "$workspace_head" = "$local_main"
test "$workspace_head" = "$fetched_head"

task-board --json worktree status STORY-260830-884cmp > "$evidence_path"
rg -Fq "\"initial_base_oid\": \"$workspace_head\"" "$evidence_path"
rg -Fq "\"current_base_oid\": \"$workspace_head\"" "$evidence_path"
rg -Fq "\"checkpoint_oid\": \"$workspace_head\"" "$evidence_path"
rg -Fq "\"selected_base_oid\": \"$workspace_head\"" "$evidence_path"

print -r -- "FETCH_HEAD=$fetched_head"
print -r -- "origin/main=$origin_main"
print -r -- "main=$local_main"
print -r -- "workspace_HEAD=$workspace_head"
