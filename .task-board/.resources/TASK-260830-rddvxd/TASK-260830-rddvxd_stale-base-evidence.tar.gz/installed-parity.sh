#!/bin/zsh
set -euo pipefail

repo_root=/Users/alexis/src/relux-works/relux-agents-infra/.temp/STORY-260830-884cmp/worktree
installed_agents=/Users/alexis/.agents
installed_claude=/Users/alexis/.claude
installed_codex=/Users/alexis/.codex

cmp "$repo_root/.instructions/INSTRUCTIONS_WORKFLOW.md" "$installed_agents/.instructions/INSTRUCTIONS_WORKFLOW.md"
cmp "$repo_root/.instructions/INSTRUCTIONS.md" "$installed_agents/.instructions/INSTRUCTIONS.md"
test -L "$installed_claude/instructions"
test "$(realpath "$installed_claude/instructions")" = "$installed_agents/.instructions"
cmp "$repo_root/.instructions/INSTRUCTIONS.md" "$installed_claude/instructions/INSTRUCTIONS.md"
cmp "$repo_root/.instructions/INSTRUCTIONS_WORKFLOW.md" "$installed_claude/instructions/INSTRUCTIONS_WORKFLOW.md"
rg -Fq '@~/.agents/.instructions/INSTRUCTIONS_WORKFLOW.md' "$installed_claude/instructions/INSTRUCTIONS.md"
rg -Fq '@instructions/INSTRUCTIONS.md' "$installed_claude/CLAUDE.md"
rg -Fq 'Use a local mirror only when hosted CI cannot execute repository steps for a verified external cause that the agent cannot repair.' "$installed_codex/AGENTS.md"
rg -Fq 'exact, clean checkout of the PR-head commit' "$installed_codex/AGENTS.md"
rg -Fq 'same toolchain versions, environment variables and non-secret configuration, dependent services, and target platform' "$installed_codex/AGENTS.md"
rg -Fq 'PR-head SHA, hosted job name, external failure cause, local platform and target, tool versions' "$installed_codex/AGENTS.md"
rg -Fq 'Repository-caused code, test, build, configuration, or integration failures remain blocking' "$installed_codex/AGENTS.md"
rg -Fq 'Never forge, synthesize, edit, or otherwise misrepresent a hosted check or commit status' "$installed_codex/AGENTS.md"
rg -Fq 'remote review, merge queues, or branch protection' "$installed_codex/AGENTS.md"
rg -Fq "hosting platform's real review record and protection rules remain authoritative" "$installed_codex/AGENTS.md"
