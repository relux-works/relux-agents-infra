set -u
T="$1"; S="$2"; BASE="$T/0d"; R="$BASE/case-cen"; rm -rf "$R"; mkdir -p "$R"
export RECOVERY_ROOT="$R" STUB_STATE="$R" PATH="$BASE/bin:$PATH"
printf '#!/usr/bin/env bash\nexit 2\n' > "$BASE/bin/pgrep"; chmod +x "$BASE/bin/pgrep"
out="$(bash "$S" 2>&1)"; rc=$?; printf '%s\nrc=%s\n' "$out" "$rc"
