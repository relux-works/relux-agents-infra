set -u
T="$1"; BASE="$T/0d"; R="$BASE/case-mut"; rm -rf "$R"; mkdir -p "$R"
export RECOVERY_ROOT="$R" STUB_STATE="$R" PATH="$BASE/bin:$PATH"
cat > "$BASE/bin/pgrep" <<'PG'
#!/usr/bin/env bash
echo "111 tb-sessiond --board-dir /b1"; exit 0
PG
chmod +x "$BASE/bin/pgrep"
cat > "$BASE/bin/task-board" <<'TB'
#!/usr/bin/env bash
sub=""; while [ $# -gt 0 ]; do case "$1" in session) sub="$2"; shift 2;; *) shift;; esac; done
if [ "$sub" = list ]; then echo '{"sessions":[{"attached_clients":2}]}'; exit 0; fi
echo '{"running": true, "pid": 111, "board_fingerprint":"fp", "session_count": 3}'
TB
chmod +x "$BASE/bin/task-board"
out="$(bash "$2" 2>&1)"; rc=$?
printf '%s\nrc=%s\n' "$out" "$rc"
if printf '%s' "$out" | grep -q 'attached client'; then echo "MUTANT-STILL-REFUSES (gate not load-bearing)"; else echo "MUTANT-ADMITTED-ATTACHED-CLIENTS (gate is load-bearing)"; fi
