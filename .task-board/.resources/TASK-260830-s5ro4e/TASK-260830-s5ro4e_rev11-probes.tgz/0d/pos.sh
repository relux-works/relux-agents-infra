set -u
T="$1"; BASE="$T/0d"; SCRIPT="${2:-$T/r1-0d.sh}"
R="$BASE/case-positive"; rm -rf "$R"; mkdir -p "$R"
export RECOVERY_ROOT="$R" STUB_STATE="$R" PATH="$BASE/bin:$PATH"
"$BASE/bin/tb-sessiond" 120 & P=$!
cat > "$BASE/bin/pgrep" <<PG
#!/usr/bin/env bash
echo "$P tb-sessiond --board-dir /b1"; exit 0
PG
chmod +x "$BASE/bin/pgrep"
# status: calls 1-2 report running (pre-kill reads), call 3+ report stopped
cat > "$BASE/bin/task-board" <<TB
#!/usr/bin/env bash
sub=""; while [ \$# -gt 0 ]; do case "\$1" in session) sub="\$2"; shift 2;; *) shift;; esac; done
if [ "\$sub" = list ]; then echo '{"sessions":[{"attached_clients":0}]}'; exit 0; fi
n=0; [ -f "$R/n" ] && n=\$(cat "$R/n"); n=\$((n+1)); echo \$n > "$R/n"
if [ \$n -le 2 ]; then echo '{"running": true, "pid": $P, "board_fingerprint":"fp", "session_count": 4}'
else echo '{"running": false}'; fi
TB
chmod +x "$BASE/bin/task-board"
out="$(bash "$SCRIPT" 2>&1)"; rc=$?
echo "$out"; echo "rc=$rc"
if ps -p "$P" >/dev/null 2>&1; then echo "DAEMON-STILL-ALIVE"; kill -9 "$P" 2>/dev/null; else echo "DAEMON-TERMINATED"; fi
echo "--- recorded ---"; cat "$R/r1-daemons-stopped.txt" 2>/dev/null || echo "(none)"
