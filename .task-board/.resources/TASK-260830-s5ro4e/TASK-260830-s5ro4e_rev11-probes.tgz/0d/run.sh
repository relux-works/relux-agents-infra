set -u
T="$1"; BASE="$T/0d"; PASS=0; FAIL=0
# rewrite the file-reading stub: pos.sh and mut.sh replace it with their own.
cat > "$BASE/bin/task-board" <<'TBSTUB'
#!/usr/bin/env bash
board=""; sub=""
while [ $# -gt 0 ]; do
  case "$1" in --board-dir) board="$2"; shift 2;; session) sub="$2"; shift 2;; *) shift;; esac
done
key="$STUB_STATE/$(printf '%s' "$board" | tr / _).$sub"
cat "$key"
TBSTUB
chmod +x "$BASE/bin/task-board"
run_case() { # name  expected_rc  expected_pattern  setup_fn
  name="$1"; exp_rc="$2"; pat="$3"; setup="$4"
  R="$BASE/case-$name"; rm -rf "$R"; mkdir -p "$R"
  export RECOVERY_ROOT="$R" STUB_STATE="$R" PATH="$BASE/bin:$PATH"
  "$setup"
  out="$(bash "$T/r1-0d.sh" 2>&1)"; rc=$?
  if [ "$rc" = "$exp_rc" ] && printf '%s' "$out" | grep -q "$pat"; then
    printf 'PASS %-28s rc=%s matched %s\n' "$name" "$rc" "$pat"; PASS=$((PASS+1))
  else
    printf 'FAIL %-28s rc=%s (want %s) out=%s\n' "$name" "$rc" "$exp_rc" "$out"; FAIL=$((FAIL+1))
  fi
}
# pgrep is shadowed per-case by a stub on PATH
mkpgrep() { cat > "$BASE/bin/pgrep" <<PG
#!/usr/bin/env bash
$1
PG
chmod +x "$BASE/bin/pgrep"; }

c_census_fail() { mkpgrep 'exit 2'; }
c_no_daemon()   { mkpgrep 'exit 1'; }
c_remote()      { mkpgrep 'echo "111 tb-sessiond --remote-origin https://x --board-dir /b1"; exit 0'; }
c_notrunning()  { mkpgrep 'echo "111 tb-sessiond --board-dir /b1"; exit 0'
                  echo '{"running": false}' > "$R/_b1.status"; echo '{"sessions":[]}' > "$R/_b1.list"; }
c_unreadable()  { mkpgrep 'echo "111 tb-sessiond --board-dir /b1"; exit 0'
                  echo '{"nope": 1}' > "$R/_b1.status"; echo '{"sessions":[]}' > "$R/_b1.list"; }
c_attached()    { mkpgrep 'echo "111 tb-sessiond --board-dir /b1"; exit 0'
                  echo '{"running": true, "pid": 111, "board_fingerprint":"fp", "session_count": 3}' > "$R/_b1.status"
                  echo '{"sessions":[{"attached_clients":2},{"attached_clients":0}]}' > "$R/_b1.list"; }
c_notsessiond() { sleep 60 & p=$!; echo "$p" > "$R/pid"
                  mkpgrep "echo \"$p tb-sessiond --board-dir /b1\"; exit 0"
                  echo "{\"running\": true, \"pid\": $p, \"board_fingerprint\":\"fp\", \"session_count\": 0}" > "$R/_b1.status"
                  echo '{"sessions":[]}' > "$R/_b1.list"; }
run_case census-failed-rc2      1 'DAEMON-CENSUS-FAILED'      c_census_fail
run_case no-live-daemon         0 '0D-COMPLETED'              c_no_daemon
run_case remote-board-refused   1 'STOP remote-board daemon'  c_remote
run_case board-not-running      0 '0D-COMPLETED'              c_notrunning
run_case unreadable-running     1 'STOP unreadable running'   c_unreadable
run_case attached-clients       1 'attached client'           c_attached
run_case pid-not-tb-sessiond    1 'is not a tb-sessiond'      c_notsessiond
kill %1 2>/dev/null
printf 'PASS=%s FAIL=%s\n' "$PASS" "$FAIL"; [ "$FAIL" = 0 ]
