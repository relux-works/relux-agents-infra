# probe2 wrapped the code in `eval`, whose own non-zero status triggers errexit --
# that measured the wrapper, not the shape. Inline the shapes instead.
echo "-- A: [ -e missing ] && mv, last statement of a loop body"
( set -euo pipefail
  for r in a b; do [ -e "/nonexistent/$r" ] && mv "/nonexistent/$r" /tmp/x; done
  echo A-REACHED-END ); echo "A rc=$?"
echo "-- B: [ -e missing ] || [ -L missing ] && mv"
( set -euo pipefail
  [ -e /nonexistent ] || [ -L /nonexistent ] && mv /nonexistent /tmp/x
  echo B-REACHED-END ); echo "B rc=$?"
echo "-- C: pipeline && { exit 1; } with no match"
( set -euo pipefail
  printf "" | grep -q . && { echo FOUND; exit 1; }
  echo C-REACHED-END ); echo "C rc=$?"
echo "-- D: control, bare failing command must abort"
( set -euo pipefail; false; echo D-REACHED-END ); echo "D rc=$?"
echo "-- E: control, the shape DOES fire when the test is true"
( set -euo pipefail
  printf "x\n" | grep -q . && { echo E-FIRED; exit 7; }
  echo E-REACHED-END ); echo "E rc=$?"
