set -euo pipefail
# --- 0d. Stop every daemon this rollback would otherwise strand, BEFORE any executable is
#         replaced, while the INSTALLED CLI still matches the daemons the release started.
#         Nothing here escalates to SIGKILL: a daemon that does not exit is a STOP.
rc=0; pgrep -fl tb-sessiond > "$RECOVERY_ROOT/daemons-before-r1.txt" || rc=$?
case "$rc" in
  0) : ;;
  1) printf 'NO-LIVE-DAEMON\n' > "$RECOVERY_ROOT/daemons-before-r1.txt" ;;
  *) printf 'DAEMON-CENSUS-FAILED rc=%s\n' "$rc" >&2; exit 1 ;;
esac
sed -nE 's/.*--board-dir[ =]([^ ]+).*/\1/p' "$RECOVERY_ROOT/daemons-before-r1.txt" \
  | sort -u > "$RECOVERY_ROOT/daemon-boards-before-r1.txt"
# A remote-board daemon carries no --board-dir and is not modelled by this plan.
grep -q -- '--remote-origin' "$RECOVERY_ROOT/daemons-before-r1.txt" && {
  printf 'STOP remote-board daemon present; disposition it by hand before R1\n' >&2; exit 1; }
while IFS= read -r board; do
  test -n "$board" || continue
  tag="$(printf '%s' "$board" | tr / _)"
  st="$RECOVERY_ROOT/r1-status-$tag.json"; lst="$RECOVERY_ROOT/r1-list-$tag.json"
  task-board --board-dir "$board" --json session status > "$st"   # Dial-based: starts nothing,
  task-board --board-dir "$board" --json session list   > "$lst"  # restarts nothing
  running="$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1])).get("running"))' "$st")"
  case "$running" in
    False|false) continue ;;                     # nothing holds this board
    True|true)   : ;;
    *) printf 'STOP unreadable running flag for %s\n' "$board" >&2; exit 1 ;;
  esac
  pid="$(python3  -c 'import json,sys;print(json.load(open(sys.argv[1]))["pid"])' "$st")"
  fp="$(python3   -c 'import json,sys;print(json.load(open(sys.argv[1]))["board_fingerprint"])' "$st")"
  sess="$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["session_count"])' "$st")"
  att="$(python3 -c 'import json,sys
d=json.load(open(sys.argv[1])); rows=d if isinstance(d,list) else d.get("sessions") or []
print(sum(int(r.get("attached_clients") or 0) for r in rows))' "$lst")"
  # An attached client is somebody`s running agent, and stopping the daemon closes the proxy
  # listener it talks through -- its owner`s decision, never a rollback side effect.
  [ "$att" = "0" ] || { printf 'STOP %s has %s attached client(s)\n' "$board" "$att" >&2; exit 1; }
  ep="$(task-board --board-dir "$board" --json session status \
        | python3 -c 'import json,sys;print(json.load(sys.stdin)["pid"])')"
  test "$ep" = "$pid" || { printf 'STOP pid moved for %s\n' "$board" >&2; exit 1; }
  ps -p "$pid" -o command= | grep -q tb-sessiond \
    || { printf 'STOP pid %s is not a tb-sessiond\n' "$pid" >&2; exit 1; }
  kill -TERM "$pid"
  stopped=no; i=0
  while [ "$i" -lt 30 ]; do
    ps -p "$pid" > /dev/null 2>&1 || { stopped=yes; break; }
    sleep 1; i=$((i+1))
  done
  test "$stopped" = yes || { printf 'STOP daemon %s on %s did not exit in 30s; do NOT SIGKILL, escalate\n' \
    "$pid" "$board" >&2; exit 1; }
  # Deferred cleanup removes socket, endpoint and token, so the next ConnectOrStart sees
  # ErrManagerNotRunning and launches rather than taking over.
  after="$(task-board --board-dir "$board" --json session status \
           | python3 -c 'import json,sys;print(json.load(sys.stdin).get("running"))')"
  case "$after" in False|false) : ;;
    *) printf 'STOP %s still reports a running daemon after stop\n' "$board" >&2; exit 1 ;; esac
  # Recorded only after the stop is CONFIRMED: step 5 asserts against this file.
  printf 'r1-0d board=%s pid=%s fingerprint=%s sessions=%s attached=%s\n' \
    "$board" "$pid" "$fp" "$sess" "$att" >> "$RECOVERY_ROOT/r1-daemons-stopped.txt"
done < "$RECOVERY_ROOT/daemon-boards-before-r1.txt"
echo 0D-COMPLETED
