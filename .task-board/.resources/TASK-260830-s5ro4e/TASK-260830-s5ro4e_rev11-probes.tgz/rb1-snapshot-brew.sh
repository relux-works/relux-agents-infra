set -euo pipefail
out="$1"; test ! -e "$out"                  # never overwrite an earlier good snapshot
rm -f "$out.partial"; trap 'rm -f "$out.partial"' EXIT
{ brew --prefix; brew list --formula; brew list --versions llvm; brew --prefix llvm; } > "$out.partial"
prefix="$(brew --prefix)"; llvm_prefix="$(brew --prefix llvm)"
for t in "$prefix/bin/lldb-mcp" "$prefix/bin/lldb-mcp.agents-infra.bak" \
         "$llvm_prefix/bin/lldb-mcp" "$llvm_prefix/bin/lldb"; do
  if [ -e "$t" ] || [ -L "$t" ]; then stat -f '%N|%HT|%z|%m|%Sp' "$t"; shasum -a 256 "$t"
  else printf 'ABSENT|%s\n' "$t"; fi
done >> "$out.partial"
mv -f "$out.partial" "$out"
