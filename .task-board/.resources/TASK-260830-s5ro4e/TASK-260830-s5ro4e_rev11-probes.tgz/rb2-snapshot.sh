set -euo pipefail
PM_STATE="$HOME/.config/task-board/install.json"
AI_STATE="$HOME/Library/Application Support/agents-infra/install.json"   # Darwin; else
# "${XDG_CONFIG_HOME:-$HOME/.config}/agents-infra/install.json" per agents-infra setup.sh:64-73.
j() { python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))[sys.argv[2]])' "$1" "$2"; }
PM_REPO="$(j "$PM_STATE" repoPath)"; AI_REPO="$(j "$AI_STATE" repoPath)"
test "$(j "$PM_STATE" binDir)" = "$(j "$AI_STATE" binDir)"; BIN_DIR="$(j "$PM_STATE" binDir)"
test -d "$PM_REPO" && test -d "$AI_REPO"
RECOVERY_ROOT="$HOME/.local/state/TASK-260830-s5ro4e/current-pair"
MANIFEST="$RECOVERY_ROOT/manifest"; test ! -e "$RECOVERY_ROOT"
mkdir -p "$RECOVERY_ROOT/bin" "$MANIFEST" "$RECOVERY_ROOT/pm/roles" "$RECOVERY_ROOT/pm/skills" \
  "$RECOVERY_ROOT/pm/claude-skills" "$RECOVERY_ROOT/pm/codex-skills" "$RECOVERY_ROOT/ai" \
  "$RECOVERY_ROOT/sources"
printf '%s\n' "$BIN_DIR"  > "$MANIFEST/bin-dir.txt"
printf '%s\n' "$PM_STATE" > "$MANIFEST/pm-state-path.txt"
printf '%s\n' "$AI_STATE" > "$MANIFEST/ai-state-path.txt"
# Same filesystem, so every restore is an atomic rename, not a copy that can fail halfway.
device="$(stat -f %d "$RECOVERY_ROOT")"
for t in "$BIN_DIR" "$HOME/.agents/skills" "$HOME/.roles" "$HOME/.claude/skills" \
         "$HOME/.codex/skills" "$(dirname "$PM_STATE")" "$(dirname "$AI_STATE")"; do
  test -d "$t"; test "$(stat -f %d "$t")" = "$device"
done
{ sed -nE 's/^[[:space:]]*install_binary "([^"]+)".*/\1/p' "$PM_REPO/scripts/setup.sh"
  sed -nE 's/^(BINARY_NAME|MODEL_HARNESS_BINARY_NAME)="([^"]+)".*/\2/p' "$AI_REPO/scripts/setup.sh"
} > "$MANIFEST/binaries.txt"; test -s "$MANIFEST/binaries.txt"
while IFS= read -r n; do test -n "$n" || continue
  test -f "$BIN_DIR/$n" && test ! -L "$BIN_DIR/$n"
  cp -p "$BIN_DIR/$n" "$RECOVERY_ROOT/bin/$n"; cmp -s "$BIN_DIR/$n" "$RECOVERY_ROOT/bin/$n"
done < "$MANIFEST/binaries.txt"
ls -1A "$BIN_DIR" > "$MANIFEST/bin-inventory.txt"
shasum -a 256 "$RECOVERY_ROOT/bin"/* > "$RECOVERY_ROOT/bin.sha256"
# Recovery sources at the commit each saved executable itself reports: this makes the recovery
# baseline and the recovery binary the same pair by construction, with no revision written here.
TB_V="$("$RECOVERY_ROOT/bin/task-board" --version)"
SD_V="$("$RECOVERY_ROOT/bin/tb-sessiond" --version)"
AI_V="$("$RECOVERY_ROOT/bin/agents-infra" version)"
printf '%s\n%s\n%s\n' "$TB_V" "$SD_V" "$AI_V" > "$RECOVERY_ROOT/versions.txt"
commit_of() { printf '%s\n' "$1" | sed -nE \
  -e 's/.*\(commit ([0-9a-f]{7,40}),.*/\1/p' -e 's/.* commit=([0-9a-f]{7,40})( .*)?$/\1/p'; }
TB_C="$(commit_of "$TB_V")"; SD_C="$(commit_of "$SD_V")"; AI_C="$(commit_of "$AI_V")"
test -n "$TB_C" && test -n "$SD_C" && test -n "$AI_C"
test "$TB_C" = "$SD_C"       # one repo ships both; a divergence is an incoherent install
TB_SOURCE="$RECOVERY_ROOT/sources/skill-project-management"
AI_SOURCE="$RECOVERY_ROOT/sources/relux-agents-infra"
# Absolute destinations: `git -C repo worktree add` resolves a relative path against the
# repository, not the caller, and still exits zero.
git -C "$PM_REPO" worktree add --detach "$TB_SOURCE" "$(git -C "$PM_REPO" rev-parse --verify "${TB_C}^{commit}")"
git -C "$AI_REPO" worktree add --detach "$AI_SOURCE" "$(git -C "$AI_REPO" rev-parse --verify "${AI_C}^{commit}")"
test -z "$(git -C "$TB_SOURCE" status --porcelain)"; test -z "$(git -C "$AI_SOURCE" status --porcelain)"
git -C "$TB_SOURCE" rev-parse HEAD > "$MANIFEST/pm-source-commit.txt"
git -C "$AI_SOURCE" rev-parse HEAD > "$MANIFEST/ai-source-commit.txt"
# Re-read the artifact set from those exact sources: if a repo HEAD moved and changed it, the
# copy above is not the installed release's artifact set.
{ sed -nE 's/^[[:space:]]*install_binary "([^"]+)".*/\1/p' "$TB_SOURCE/scripts/setup.sh"
  sed -nE 's/^(BINARY_NAME|MODEL_HARNESS_BINARY_NAME)="([^"]+)".*/\2/p' "$AI_SOURCE/scripts/setup.sh"
} > "$MANIFEST/binaries-from-source.txt"
diff "$MANIFEST/binaries.txt" "$MANIFEST/binaries-from-source.txt"
ls -1A "$HOME/.roles" > "$MANIFEST/roles.txt"
while IFS= read -r r; do test -n "$r" || continue
  test -d "$HOME/.roles/$r"; rsync -a --delete "$HOME/.roles/$r/" "$RECOVERY_ROOT/pm/roles/$r/"
done < "$MANIFEST/roles.txt"
# Skills: the registered skill plus every SKILL_REPOS dependency, in all three trees. Every
# recorded kind gets a staged operand, or R1 aborts mid-restore.
{ sed -nE 's/^[[:space:]]*local skill_name="([^"]+)".*/\1/p' "$TB_SOURCE/scripts/setup.sh"
  sed -n '/^SKILL_REPOS=(/,/^)/p' "$TB_SOURCE/scripts/setup.sh" \
    | sed -nE 's/^[[:space:]]+([A-Za-z0-9._-]+)[[:space:]]+".*/\1/p'
} > "$MANIFEST/skills.txt"; test -s "$MANIFEST/skills.txt"
: > "$MANIFEST/skill-state.txt"
while IFS= read -r s; do
  test -n "$s" || continue; case "$s" in *"|"*) exit 76 ;; esac
  a="$HOME/.agents/skills/$s"
  if   [ -L "$a" ]; then line="$s|symlink|$(readlink "$a")"
  elif [ -d "$a" ]; then line="$s|directory|"; rsync -a --delete "$a/" "$RECOVERY_ROOT/pm/skills/$s/"
  elif [ -e "$a" ]; then exit 77
  else                   line="$s|absent|"; fi
  for spec in "$HOME/.claude/skills|claude-skills" "$HOME/.codex/skills|codex-skills"; do
    root="${spec%%|*}"; stage="${spec##*|}"
    if   [ -L "$root/$s" ]; then line="$line|symlink|$(readlink "$root/$s")"
    elif [ -d "$root/$s" ]; then line="$line|directory|"
         rsync -a --delete "$root/$s/" "$RECOVERY_ROOT/pm/$stage/$s/"
    elif [ -e "$root/$s" ]; then exit 77
    else                         line="$line|absent|"; fi
  done
  printf '%s\n' "$line" >> "$MANIFEST/skill-state.txt"
done < "$MANIFEST/skills.txt"
# Restorability, asserted at the door rather than during R1. R1 step 0 runs this same function
# against the artifact it consumes; neither may rely on the other having run.
snapshot_restorable() {   # $1 label  $2 kind  $3 recorded link  $4 staged tree
  case "$2" in
    symlink)   test -n "$3" || { printf 'UNRESTORABLE %s symlink with no target\n' "$1" >&2; return 1; } ;;
    directory) test -d "$4" || { printf 'UNRESTORABLE %s directory with no staged tree\n' "$1" >&2; return 1; } ;;
    absent)    : ;;
    *)         printf 'UNRESTORABLE %s unrecognised kind %s\n' "$1" "$2" >&2; return 1 ;;
  esac
}
while IFS='|' read -r s ak al ck cl xk xl; do test -n "$s" || continue
  snapshot_restorable "$s:.agents" "$ak" "$al" "$RECOVERY_ROOT/pm/skills/$s"
  snapshot_restorable "$s:.claude" "$ck" "$cl" "$RECOVERY_ROOT/pm/claude-skills/$s"
  snapshot_restorable "$s:.codex"  "$xk" "$xl" "$RECOVERY_ROOT/pm/codex-skills/$s"
done < "$MANIFEST/skill-state.txt"
# Both machine-scoped install states. The agents-infra one records repoPath, which the installed
# binary uses to resolve its own source tree.
install -m 0644 "$PM_STATE" "$RECOVERY_ROOT/pm/install.json"
install -m 0644 "$AI_STATE" "$RECOVERY_ROOT/ai/install.json"
