set -euo pipefail
MANIFEST="$RECOVERY_ROOT/manifest"; BIN_DIR="$(cat "$MANIFEST/bin-dir.txt")"
# --- 0. Admissibility, BEFORE anything is mutated: a snapshot R1 cannot fully restore produces
#        no partial run at all. snapshot_restorable() is the snapshot's, verbatim.
while IFS='|' read -r s ak al ck cl xk xl; do test -n "$s" || continue
  snapshot_restorable "$s:.agents" "$ak" "$al" "$RECOVERY_ROOT/pm/skills/$s"
  snapshot_restorable "$s:.claude" "$ck" "$cl" "$RECOVERY_ROOT/pm/claude-skills/$s"
  snapshot_restorable "$s:.codex"  "$xk" "$xl" "$RECOVERY_ROOT/pm/codex-skills/$s"
done < "$MANIFEST/skill-state.txt"
while IFS= read -r n; do test -n "$n" || continue
  test -f "$RECOVERY_ROOT/bin/$n" || { printf 'UNRESTORABLE bin/%s missing\n' "$n" >&2; exit 1; }
done < "$MANIFEST/binaries.txt"
while IFS= read -r r; do test -n "$r" || continue
  test -d "$RECOVERY_ROOT/pm/roles/$r" || { printf 'UNRESTORABLE roles/%s missing\n' "$r" >&2; exit 1; }
done < "$MANIFEST/roles.txt"
test -f "$RECOVERY_ROOT/pm/install.json"

# --- 0d. Stop every daemon this rollback would otherwise strand, BEFORE any executable is
#         replaced, while the INSTALLED CLI still matches the daemons the release started.
#         Nothing here escalates to SIGKILL: a daemon that does not exit is a STOP.
rc=0; pgrep -fl tb-sessiond > "$RECOVERY_ROOT/daemons-before-r1.txt" || rc=$?
case "$rc" in
  0) : ;;
  1) printf 'NO-LIVE-DAEMON\n' > "$RECOVERY_ROOT/daemons-before-r1.txt" ;;
  *) printf 'DAEMON-CENSUS-FAILED rc=%s\n' "$rc" >&2; exit 1 ;;
esac
sed -nE 's/.*--board-dir[ =]([^ ]+).*/\1/p' "$RECOVERY_ROOT/daemons-before-r1.txt" \
  | sort -u > "$RECOVERY_ROOT/daemon-boards-before-r1.txt"
# A remote-board daemon carries no --board-dir and is not modelled by this plan.
grep -q -- '--remote-origin' "$RECOVERY_ROOT/daemons-before-r1.txt" && {
  printf 'STOP remote-board daemon present; disposition it by hand before R1\n' >&2; exit 1; }
while IFS= read -r board; do
  test -n "$board" || continue
  tag="$(printf '%s' "$board" | tr / _)"
  st="$RECOVERY_ROOT/r1-status-$tag.json"; lst="$RECOVERY_ROOT/r1-list-$tag.json"
  task-board --board-dir "$board" --json session status > "$st"   # Dial-based: starts nothing,
  task-board --board-dir "$board" --json session list   > "$lst"  # restarts nothing
  running="$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1])).get("running"))' "$st")"
  case "$running" in
    False|false) continue ;;                     # nothing holds this board
    True|true)   : ;;
    *) printf 'STOP unreadable running flag for %s\n' "$board" >&2; exit 1 ;;
  esac
  pid="$(python3  -c 'import json,sys;print(json.load(open(sys.argv[1]))["pid"])' "$st")"
  fp="$(python3   -c 'import json,sys;print(json.load(open(sys.argv[1]))["board_fingerprint"])' "$st")"
  sess="$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1]))["session_count"])' "$st")"
  att="$(python3 -c 'import json,sys
d=json.load(open(sys.argv[1])); rows=d if isinstance(d,list) else d.get("sessions") or []
print(sum(int(r.get("attached_clients") or 0) for r in rows))' "$lst")"
  # An attached client is somebody`s running agent, and stopping the daemon closes the proxy
  # listener it talks through -- its owner`s decision, never a rollback side effect.
  [ "$att" = "0" ] || { printf 'STOP %s has %s attached client(s)\n' "$board" "$att" >&2; exit 1; }
  ep="$(task-board --board-dir "$board" --json session status \
        | python3 -c 'import json,sys;print(json.load(sys.stdin)["pid"])')"
  test "$ep" = "$pid" || { printf 'STOP pid moved for %s\n' "$board" >&2; exit 1; }
  ps -p "$pid" -o command= | grep -q tb-sessiond \
    || { printf 'STOP pid %s is not a tb-sessiond\n' "$pid" >&2; exit 1; }
  kill -TERM "$pid"
  stopped=no; i=0
  while [ "$i" -lt 30 ]; do
    ps -p "$pid" > /dev/null 2>&1 || { stopped=yes; break; }
    sleep 1; i=$((i+1))
  done
  test "$stopped" = yes || { printf 'STOP daemon %s on %s did not exit in 30s; do NOT SIGKILL, escalate\n' \
    "$pid" "$board" >&2; exit 1; }
  # Deferred cleanup removes socket, endpoint and token, so the next ConnectOrStart sees
  # ErrManagerNotRunning and launches rather than taking over.
  after="$(task-board --board-dir "$board" --json session status \
           | python3 -c 'import json,sys;print(json.load(sys.stdin).get("running"))')"
  case "$after" in False|false) : ;;
    *) printf 'STOP %s still reports a running daemon after stop\n' "$board" >&2; exit 1 ;; esac
  # Recorded only after the stop is CONFIRMED: step 5 asserts against this file.
  printf 'r1-0d board=%s pid=%s fingerprint=%s sessions=%s attached=%s\n' \
    "$board" "$pid" "$fp" "$sess" "$att" >> "$RECOVERY_ROOT/r1-daemons-stopped.txt"
done < "$RECOVERY_ROOT/daemon-boards-before-r1.txt"

# --- 1. Executables: restore what the snapshot holds, quarantine what the release added.
#        Anything else in BIN_DIR is reported, not removed: this plan owns the release's
#        artifacts, not the operator's PATH.
sed -nE 's/^[[:space:]]*install_binary "([^"]+)".*/\1/p' "$PM_RELEASE/scripts/setup.sh" \
  | sort -u > /tmp/r1-release-bins.$$
sort -u "$MANIFEST/binaries.txt" > /tmp/r1-snapshot-bins.$$
while IFS= read -r n; do test -n "$n" || continue
  if grep -qxF "$n" /tmp/r1-snapshot-bins.$$; then
    install -m 0755 "$RECOVERY_ROOT/bin/$n" "$BIN_DIR/.$n.rollback.$$"
    mv -f "$BIN_DIR/.$n.rollback.$$" "$BIN_DIR/$n"
  elif [ -e "$BIN_DIR/$n" ]; then mv -f "$BIN_DIR/$n" "$BIN_DIR/.$n.superseded.$$"; fi
done < /tmp/r1-release-bins.$$
ls -1A "$BIN_DIR" | grep -vxF -f "$MANIFEST/bin-inventory.txt" \
  > "$RECOVERY_ROOT/unexpected-bin-entries.txt" || true

# --- 2. Skills to their exact recorded kind in all three trees, then removal of any skill this
#        release's SKILL_REPOS added.
restore_entry() {   # $1 path  $2 kind  $3 link target  $4 staged tree
  d="$(dirname "$1")"; b="$(basename "$1")"
  case "$2" in
    symlink)   test -n "$3"; rm -rf "$1"; ln -sfn "$3" "$1" ;;
    directory) test -d "$4"; rsync -a --delete "$4/" "$d/.$b.rollback.$$/"
               [ -e "$1" ] || [ -L "$1" ] && mv "$1" "$d/.$b.failed.$$"
               mv "$d/.$b.rollback.$$" "$1" ;;
    absent)    if [ -e "$1" ] || [ -L "$1" ]; then mv "$1" "$d/.$b.superseded.$$"; fi ;;
    *)         printf 'UNKNOWN-KIND %s %s\n' "$1" "$2" >&2; return 1 ;;
  esac
}
while IFS='|' read -r s ak al ck cl xk xl; do test -n "$s" || continue
  restore_entry "$HOME/.agents/skills/$s" "$ak" "$al" "$RECOVERY_ROOT/pm/skills/$s"
  restore_entry "$HOME/.claude/skills/$s" "$ck" "$cl" "$RECOVERY_ROOT/pm/claude-skills/$s"
  restore_entry "$HOME/.codex/skills/$s"  "$xk" "$xl" "$RECOVERY_ROOT/pm/codex-skills/$s"
done < "$MANIFEST/skill-state.txt"
{ sed -nE 's/^[[:space:]]*local skill_name="([^"]+)".*/\1/p' "$PM_RELEASE/scripts/setup.sh"
  sed -n '/^SKILL_REPOS=(/,/^)/p' "$PM_RELEASE/scripts/setup.sh" \
    | sed -nE 's/^[[:space:]]+([A-Za-z0-9._-]+)[[:space:]]+".*/\1/p'
} | sort -u > /tmp/r1-release-skills.$$
comm -23 /tmp/r1-release-skills.$$ <(sort -u "$MANIFEST/skills.txt") > /tmp/r1-added-skills.$$
while IFS= read -r s; do test -n "$s" || continue
  restore_entry "$HOME/.agents/skills/$s" absent "" ""
  restore_entry "$HOME/.claude/skills/$s" absent "" ""
  restore_entry "$HOME/.codex/skills/$s"  absent "" ""
done < /tmp/r1-added-skills.$$

# --- 3. Roles: restore every snapshot role, quarantine every role the release added.
while IFS= read -r r; do test -n "$r" || continue
  rsync -a --delete "$RECOVERY_ROOT/pm/roles/$r/" "$HOME/.roles/.$r.rollback.$$/"
  [ -e "$HOME/.roles/$r" ] && mv "$HOME/.roles/$r" "$HOME/.roles/.$r.failed.$$"
  mv "$HOME/.roles/.$r.rollback.$$" "$HOME/.roles/$r"
done < "$MANIFEST/roles.txt"
comm -23 <(ls -1A "$PM_RELEASE/.roles" | sort -u) <(sort -u "$MANIFEST/roles.txt") \
  > /tmp/r1-added-roles.$$
while IFS= read -r r; do test -n "$r" || continue
  [ -e "$HOME/.roles/$r" ] && mv "$HOME/.roles/$r" "$HOME/.roles/.$r.superseded.$$"
done < /tmp/r1-added-roles.$$

# --- 4. Install state last.
pmdir="$(dirname "$(cat "$MANIFEST/pm-state-path.txt")")"
install -m 0644 "$RECOVERY_ROOT/pm/install.json" "$pmdir/.install.json.rollback.$$"
mv -f "$pmdir/.install.json.rollback.$$" "$(cat "$MANIFEST/pm-state-path.txt")"

# --- 5. Assert the state 0d removed is still gone: an assumption that a state was removed is
#        worth nothing next to a read that it is gone. A daemon that reappears here was started
#        DURING R1 -- by an agent, a cron or a human.
rc=0; pgrep -fl tb-sessiond > "$RECOVERY_ROOT/daemons-after-r1.txt" || rc=$?
case "$rc" in
  0) : ;;
  1) printf 'NO-LIVE-DAEMON\n' > "$RECOVERY_ROOT/daemons-after-r1.txt" ;;
  *) printf 'DAEMON-CENSUS-FAILED rc=%s\n' "$rc" >&2; exit 1 ;;
esac
sed -nE 's/.*--board-dir[ =]([^ ]+).*/\1/p' "$RECOVERY_ROOT/daemons-after-r1.txt" \
  | sort -u > "$RECOVERY_ROOT/daemon-boards-after-r1.txt"
if [ -f "$RECOVERY_ROOT/r1-daemons-stopped.txt" ]; then
  awk '{sub(/^board=/,"",$2); print $2}' "$RECOVERY_ROOT/r1-daemons-stopped.txt" \
    | sort -u > "$RECOVERY_ROOT/r1-stopped-boards.txt"
  comm -12 "$RECOVERY_ROOT/r1-stopped-boards.txt" "$RECOVERY_ROOT/daemon-boards-after-r1.txt" \
    | grep -q . && { printf 'STOP a board stopped by step 0d has a daemon again\n' >&2; exit 1; }
fi
rm -f /tmp/r1-*.$$
