set -euo pipefail
MANIFEST="$RECOVERY_ROOT/manifest"; BIN_DIR="$(cat "$MANIFEST/bin-dir.txt")"
sed -nE 's/^(BINARY_NAME|MODEL_HARNESS_BINARY_NAME)="([^"]+)".*/\2/p' \
  "$AI_RELEASE/scripts/setup.sh" | sort -u > /tmp/r2-release-bins.$$
while IFS= read -r n; do test -n "$n" || continue
  if grep -qxF "$n" "$MANIFEST/binaries.txt"; then
    install -m 0755 "$RECOVERY_ROOT/bin/$n" "$BIN_DIR/.$n.rollback.$$"
    mv -f "$BIN_DIR/.$n.rollback.$$" "$BIN_DIR/$n"
  elif [ -e "$BIN_DIR/$n" ]; then mv -f "$BIN_DIR/$n" "$BIN_DIR/.$n.superseded.$$"; fi
done < /tmp/r2-release-bins.$$
# Re-mint from the exact saved source. AGENTS_INFRA_SOURCE_DIR must not be set: it would
# override --source-dir's resolution order.
env -u AGENTS_INFRA_SOURCE_DIR -u AGENTS_INFRA_CONFIG_DIR \
  "$RECOVERY_ROOT/bin/agents-infra" setup global \
  --source-dir "$RECOVERY_ROOT/sources/relux-agents-infra"
env -u AGENTS_INFRA_SOURCE_DIR "$RECOVERY_ROOT/bin/agents-infra" verify global
env -u AGENTS_INFRA_SOURCE_DIR "$RECOVERY_ROOT/bin/agents-infra" doctor global
# Install state last: the installed binary resolves its own source tree through it.
aidir="$(dirname "$(cat "$MANIFEST/ai-state-path.txt")")"
install -m 0644 "$RECOVERY_ROOT/ai/install.json" "$aidir/.install.json.rollback.$$"
mv -f "$aidir/.install.json.rollback.$$" "$(cat "$MANIFEST/ai-state-path.txt")"
rm -f /tmp/r2-release-bins.$$
