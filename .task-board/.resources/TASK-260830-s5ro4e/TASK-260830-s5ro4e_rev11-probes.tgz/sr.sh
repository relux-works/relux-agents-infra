snapshot_restorable() {   # $1 label  $2 kind  $3 recorded link  $4 staged tree
  case "$2" in
    symlink)   test -n "$3" || { printf 'UNRESTORABLE %s symlink with no target\n' "$1" >&2; return 1; } ;;
    directory) test -d "$4" || { printf 'UNRESTORABLE %s directory with no staged tree\n' "$1" >&2; return 1; } ;;
    absent)    : ;;
    *)         printf 'UNRESTORABLE %s unrecognised kind %s\n' "$1" "$2" >&2; return 1 ;;
  esac
}
mkdir -p /tmp/sr-staged
t() { snapshot_restorable "$1" "$2" "$3" "$4"; echo "  -> $1 kind=$2 rc=$?"; }
set +e
t ok-symlink   symlink   /some/target ""
t bad-symlink  symlink   ""           ""
t ok-directory directory ""           /tmp/sr-staged
t bad-directory directory ""          /tmp/sr-absent-tree
t ok-absent    absent    ""           ""
t bad-kind     weird     ""           ""
