#!/bin/bash
# F2 probe: drive the SHIPPED r1.sh step-0d block against a live fake daemon.
set -u
W=$(cd "$(dirname "$0")" && pwd)
BIN="$W/fakebin"; rm -rf "$BIN"; mkdir -p "$BIN"

# fake daemon: a real process whose `ps -o command=` contains the sentinel
cat > "$BIN/tb-sessiond" <<'D'
#!/bin/bash
trap 'exit 0' TERM
while :; do sleep 0.2; done
D
chmod +x "$BIN/tb-sessiond"

# fake task-board: emits the fixture files
cat > "$BIN/task-board" <<'T'
#!/bin/bash
for a in "$@"; do :; done
case "$*" in
  *"session status"*) cat "$FIX_STATUS" ;;
  *"session list"*)   cat "$FIX_LIST" ;;
esac
T
chmod +x "$BIN/task-board"

BOARD=/tmp/s5ro4e-fakeboard
run_case() { # run_case <label> <status-json> <list-json> <expect>
  local label="$1" st="$2" ls="$3" expect="$4"
  R="$W/r1run"; rm -rf "$R"; mkdir -p "$R"
  printf '%s' "$st" > "$R/fix-status.json"; printf '%s' "$ls" > "$R/fix-list.json"
  "$BIN/tb-sessiond" --board-dir "$BOARD" & dpid=$!
  sleep 0.3
  # the block reads pid from status; splice the real pid in
  python3 - "$R/fix-status.json" "$dpid" <<'PY'
import json,sys
p=sys.argv[1]; d=json.load(open(p)); d["pid"]=int(sys.argv[2]); json.dump(d,open(p,'w'))
PY
  out=$(PATH="$BIN:$PATH" RECOVERY_ROOT="$R" \
        FIX_STATUS="$R/fix-status.json" FIX_LIST="$R/fix-list.json" \
        bash "$W/r1-0d.sh" 2>&1); rc=$?
  if kill -0 "$dpid" 2>/dev/null; then fate="ALIVE"; kill -9 "$dpid" 2>/dev/null; else fate="TERMINATED"; fi
  wait "$dpid" 2>/dev/null
  rec=$(cat "$R/r1-daemons-stopped.txt" 2>/dev/null | tr -d '\n')
  printf '%-38s exit=%-2s daemon=%-10s expect=%-10s %s\n' "$label" "$rc" "$fate" "$expect" \
    "$([ "$fate" = "$expect" ] && echo OK || echo '*** MISMATCH ***')"
  printf '    msg : %s\n' "$(printf '%s' "$out" | tail -2 | tr '\n' ' ')"
  printf '    rec : %s\n' "${rec:-<none>}"
}

S1='{"running":true,"pid":0,"board_fingerprint":"fp","session_count":1,"quarantined_count":0}'
S2='{"running":true,"pid":0,"board_fingerprint":"fp","session_count":1,"quarantined_count":1}'
Snoq='{"running":true,"pid":0,"board_fingerprint":"fp","session_count":1}'

echo "--- controls"
run_case "1 explicit 0, 1 row"            "$S1" '{"sessions":[{"attached_clients":0}]}' TERMINATED
run_case "2 explicit 2 attached"          "$S1" '{"sessions":[{"attached_clients":2}]}' ALIVE
echo "--- F2 shapes reported in rev11"
run_case "3 key ABSENT"                   "$S1" '{"sessions":[{"session_id":"s1"}]}' ALIVE
run_case "4 no sessions key ({items})"    "$S1" '{"items":[{"attached_clients":9}]}' ALIVE
run_case "5 sessions null"                "$S1" '{"sessions":null}' ALIVE
echo "--- cross-check shapes"
run_case "6 empty rows vs count 1"        "$S1" '{"sessions":[]}' ALIVE
run_case "7 2 rows vs count 1"            "$S1" '{"sessions":[{"attached_clients":0},{"attached_clients":0}]}' ALIVE
run_case "8 quarantined row counted"      "$S2" '{"sessions":[{"attached_clients":0},{"attached_clients":0}]}' TERMINATED
run_case "9 status lacks quarantined_cnt" "$Snoq" '{"sessions":[{"attached_clients":0}]}' ALIVE
run_case "10 attached_clients is a string" "$S1" '{"sessions":[{"attached_clients":"0"}]}' TERMINATED
run_case "11 attached_clients null"       "$S1" '{"sessions":[{"attached_clients":null}]}' ALIVE
