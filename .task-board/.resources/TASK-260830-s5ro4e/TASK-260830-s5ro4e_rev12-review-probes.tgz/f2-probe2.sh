#!/bin/bash
# F2 probe, isolated: synthetic daemon census (no real board is ever enumerated),
# and a fake task-board whose post-stop status reflects the real fate of the pid.
set -u
W=$(cd "$(dirname "$0")" && pwd)
BIN="$W/fakebin2"; rm -rf "$BIN"; mkdir -p "$BIN"
BOARD=/tmp/s5ro4e-fakeboard

cat > "$BIN/tb-sessiond" <<'D'
#!/bin/bash
trap 'exit 0' TERM
while :; do sleep 0.2; done
D
cat > "$BIN/pgrep" <<'P'
#!/bin/bash
# synthetic census: exactly one local-board daemon, the probe's own fake
printf '%s /fake/tb-sessiond --board-dir %s\n' "$FAKE_PID" "$FAKE_BOARD"
P
cat > "$BIN/task-board" <<'T'
#!/bin/bash
case "$*" in
  *"session status"*)
    if kill -0 "$FAKE_PID" 2>/dev/null; then cat "$FIX_STATUS"
    else python3 -c 'import json,sys;d=json.load(open(sys.argv[1]));d["running"]=False;print(json.dumps(d))' "$FIX_STATUS"; fi ;;
  *"session list"*) cat "$FIX_LIST" ;;
esac
T
chmod +x "$BIN"/*

run_case() {
  local label="$1" st="$2" ls="$3" expect="$4"
  R="$W/r1run2"; rm -rf "$R"; mkdir -p "$R"
  printf '%s' "$st" > "$R/fix-status.json"; printf '%s' "$ls" > "$R/fix-list.json"
  "$BIN/tb-sessiond" --board-dir "$BOARD" & dpid=$!
  sleep 0.3
  python3 -c 'import json,sys;p=sys.argv[1];d=json.load(open(p));d["pid"]=int(sys.argv[2]);json.dump(d,open(p,"w"))' "$R/fix-status.json" "$dpid"
  out=$(PATH="$BIN:$PATH" RECOVERY_ROOT="$R" FAKE_PID="$dpid" FAKE_BOARD="$BOARD" \
        FIX_STATUS="$R/fix-status.json" FIX_LIST="$R/fix-list.json" \
        bash "$W/r1-0d.sh" 2>&1); rc=$?
  if kill -0 "$dpid" 2>/dev/null; then fate="ALIVE"; kill -9 "$dpid" 2>/dev/null; else fate="TERMINATED"; fi
  wait "$dpid" 2>/dev/null
  rec=$(sed "s#$BOARD#<board>#;s#pid=[0-9]*#pid=<pid>#" "$R/r1-daemons-stopped.txt" 2>/dev/null | tr -d '\n')
  printf '%-34s exit=%-2s daemon=%-10s expect=%-10s %s\n' "$label" "$rc" "$fate" "$expect" \
    "$([ "$fate" = "$expect" ] && echo OK || echo '*** MISMATCH ***')"
  printf '    msg: %s\n' "$(printf '%s' "$out" | grep -E '^(STOP|UNRESTORABLE|DAEMON)' | tr '\n' ' ')"
  printf '    rec: %s\n' "${rec:-<no record written>}"
}
S1='{"running":true,"pid":0,"board_fingerprint":"fp","session_count":1,"quarantined_count":0}'
run_case "A control explicit 0"     "$S1" '{"sessions":[{"attached_clients":0}]}' TERMINATED
run_case "B explicit 2 attached"    "$S1" '{"sessions":[{"attached_clients":2}]}' ALIVE
run_case "C key ABSENT"             "$S1" '{"sessions":[{"session_id":"s1"}]}' ALIVE
run_case "D {items} not {sessions}" "$S1" '{"items":[{"attached_clients":9}]}' ALIVE
run_case "E sessions null"          "$S1" '{"sessions":null}' ALIVE

echo "=== MUTANT 1 (delete strictness: restore rev11 lenient read) ==="
sed 's/^d=json.load(open(sys.argv\[1\])); rows=d\["sessions"\]$/d=json.load(open(sys.argv[1])); rows=d if isinstance(d,list) else d.get("sessions") or []/;
     /^if not isinstance(rows,list): raise SystemExit/d;
     /^if len(rows)!=int(sys.argv\[2\]): raise SystemExit/d;
     s/int(r\["attached_clients"\])/int(r.get("attached_clients") or 0)/' "$W/r1-0d.sh" > "$W/r1-0d.mut1.sh"
cmp -s "$W/r1-0d.sh" "$W/r1-0d.mut1.sh" && { echo "MUTANT 1 DID NOT APPLY"; exit 9; }
cp "$W/r1-0d.sh" "$W/r1-0d.orig.sh"; cp "$W/r1-0d.mut1.sh" "$W/r1-0d.sh"
run_case "M1 key ABSENT"            "$S1" '{"sessions":[{"session_id":"s1"}]}' TERMINATED
run_case "M1 {items}"               "$S1" '{"items":[{"attached_clients":9}]}' TERMINATED
run_case "M1 sessions null"         "$S1" '{"sessions":null}' TERMINATED

echo "=== MUTANT 2 (NARROW: keep strict index, drop only the row-count cross-check) ==="
sed '/^if len(rows)!=int(sys.argv\[2\]): raise SystemExit/d' "$W/r1-0d.orig.sh" > "$W/r1-0d.mut2.sh"
cmp -s "$W/r1-0d.orig.sh" "$W/r1-0d.mut2.sh" && { echo "MUTANT 2 DID NOT APPLY"; exit 9; }
cp "$W/r1-0d.mut2.sh" "$W/r1-0d.sh"
run_case "M2 key ABSENT (still caught)" "$S1" '{"sessions":[{"session_id":"s1"}]}' ALIVE
run_case "M2 4 rows vs count 1"     "$S1" '{"sessions":[{"attached_clients":0},{"attached_clients":0},{"attached_clients":0},{"attached_clients":0}]}' TERMINATED
cp "$W/r1-0d.orig.sh" "$W/r1-0d.sh"
echo "=== restored shipped text: $(cmp -s "$W/r1-0d.orig.sh" "$W/r1-0d.sh" && echo yes) ==="
