#!/bin/sh
# F1 probe: drive the SHIPPED P2 text (rev12) per-branch, both shells, against the real installers.
set -u
W=$(cd "$(dirname "$0")" && pwd)
PLAN=/Users/alexis/src/relux-works/relux-agents-infra/.temp/STORY-260830-37bq03/worktree/.research/260830_agents-management-lockstep-release-and-rollback.md
AI=/Users/alexis/src/relux-works/relux-agents-infra
PM=/Users/alexis/src/relux-works/skill-project-management

python3 - "$PLAN" "$W" <<'PY'
import re,sys
t=open(sys.argv[1]).read()
seg=t[t.index('## P2 —'):t.index('## P3 —')]
body=re.search(r'```bash\n(.*?)```',seg,re.S).group(1)
pre, rest = body.split('# Steps 2 and 5',1)
tb, ai = rest.split('# Steps 3 and 6',1)
open(sys.argv[2]+'/p2-tb.frag','w').write(pre+'# Steps 2 and 5'+tb)
open(sys.argv[2]+'/p2-ai.frag','w').write(pre+'# Steps 3 and 6'+ai)
PY

mk() { # mk <dest> <srcrepo>
  rm -rf "$1"; mkdir -p "$1/scripts"; cp "$2/scripts/setup.sh" "$1/scripts/setup.sh"
  if [ -f "$2/scripts/lib/agents-infra-compose.zsh" ]; then
    mkdir -p "$1/scripts/lib"; cp "$2/scripts/lib/agents-infra-compose.zsh" "$1/scripts/lib/"
  fi
}
inject() { printf '\nNEW_UNDECIDED_INPUT="${SOME_BRAND_NEW_OVERRIDE:-x}"\n' >> "$1"; }

run() { # run <label> <frag> <saved> <release>
  for sh in bash zsh; do
    R="$W/rr"; rm -rf "$R"; mkdir -p "$R"
    out=$(RECOVERY_ROOT="$R" SAVED_SOURCE="$3" RELEASE="$4" $sh "$2" 2>&1); rc=$?
    sig=$(printf '%s' "$out" | grep -c 'P2-SET-OK')
    printf '== %-34s shell=%-4s exit=%s sigil=%s\n' "$1" "$sh" "$rc" "$sig"
    printf '%s\n' "$out" | sed 's/^/   | /' | head -8
    if [ "$sig" -gt 0 ]; then printf '   -> VERDICT: PASSES\n'; else printf '   -> VERDICT: STOPS\n'; fi
  done
}

echo "### A. agents-infra, identical (control: must PASS)"
mk "$W/ai-saved" "$AI"; mk "$W/ai-rel" "$AI"
run "ai identical" "$W/p2-ai.frag" "$W/ai-saved" "$W/ai-rel"

echo "### B. agents-infra, release has ONE injected undecided override (must STOP)"
mk "$W/ai-rel2" "$AI"; inject "$W/ai-rel2/scripts/setup.sh"
run "ai injected override" "$W/p2-ai.frag" "$W/ai-saved" "$W/ai-rel2"

echo "### C. task-board, identical (control: must PASS)"
mk "$W/pm-saved" "$PM"; mk "$W/pm-rel" "$PM"
run "tb identical" "$W/p2-tb.frag" "$W/pm-saved" "$W/pm-rel"

echo "### D. task-board, injected override in the SOURCED lib file (must STOP)"
mk "$W/pm-rel2" "$PM"; inject "$W/pm-rel2/scripts/lib/agents-infra-compose.zsh"
run "tb injected in lib" "$W/p2-tb.frag" "$W/pm-saved" "$W/pm-rel2"

echo "### E. task-board, release lib file UNREADABLE (must STOP, not silently pass)"
mk "$W/pm-rel3" "$PM"; rm -f "$W/pm-rel3/scripts/lib/agents-infra-compose.zsh"
run "tb unreadable operand" "$W/p2-tb.frag" "$W/pm-saved" "$W/pm-rel3"
