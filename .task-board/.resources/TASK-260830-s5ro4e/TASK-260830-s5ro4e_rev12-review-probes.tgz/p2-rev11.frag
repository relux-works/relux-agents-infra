set_of() { grep -ohE '\$\{?[A-Z][A-Z0-9_]*' "$@" | sed -E 's/^\$\{?//' | sort -u; }
diff <(set_of "$SAVED_SOURCE/scripts/setup.sh" "$SAVED_SOURCE/scripts/lib/"*.zsh) \
     <(set_of "$RELEASE/scripts/setup.sh"      "$RELEASE/scripts/lib/"*.zsh)
grep -nE 'printenv|(^|[^_[:alnum:]])eval([^_[:alnum:]]|$)|\$\{\(P\)|\$\{!|\[\[ -v ' \
  "$RELEASE/scripts/setup.sh" "$RELEASE/scripts/lib/"*.zsh
