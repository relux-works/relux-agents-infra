set_of() {   # an unread set is not an empty set
  for f in "$@"; do test -r "$f" || { echo "STOP P2 unreadable operand $f" >&2; return 2; }; done
  grep -ohE '\$\{?[A-Z][A-Z0-9_]*' "$@" | sed -E 's/^\$\{?//' | sort -u
}
o="$RECOVERY_ROOT/p2-old.txt"; n="$RECOVERY_ROOT/p2-new.txt"
L=scripts/lib/agents-infra-compose.zsh    # task-board only; agents-infra has no scripts/lib

# Steps 2 and 5, task-board -- setup.sh plus the one file it sources, both named:
set_of "$SAVED_SOURCE/scripts/setup.sh" "$SAVED_SOURCE/$L" > "$o" &&
set_of "$RELEASE/scripts/setup.sh"      "$RELEASE/$L"      > "$n" &&
diff "$o" "$n" && test -s "$n" && echo P2-SET-OK $(wc -l < "$n")
grep -nE 'printenv|(^|[^_[:alnum:]])eval([^_[:alnum:]]|$)|\$\{\(P\)|\$\{!|\[\[ -v ' \
  "$RELEASE/scripts/setup.sh" "$RELEASE/$L"

