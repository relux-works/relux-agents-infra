set -u
W=$(cd "$(dirname "$0")" && pwd)
PM=/Users/alexis/src/relux-works/skill-project-management
AI=/Users/alexis/src/relux-works/relux-agents-infra
setup() { R="$W/p5r"; rm -rf "$R"; mkdir -p "$R/manifest" "$R/sources"
  mkdir -p "$R/sources/skill-project-management/scripts"; cp "$PM/scripts/setup.sh" "$R/sources/skill-project-management/scripts/"; cp -R "$PM/.roles" "$R/sources/skill-project-management/.roles"
  mkdir -p "$R/sources/relux-agents-infra/scripts"; cp "$AI/scripts/setup.sh" "$R/sources/relux-agents-infra/scripts/"
  # build a "correct" manifest from the same sources so the control passes
  { sed -nE 's/^[[:space:]]*install_binary "([^"]+)".*/\1/p' "$R/sources/skill-project-management/scripts/setup.sh"
    sed -nE 's/^(BINARY_NAME|MODEL_HARNESS_BINARY_NAME)="([^"]+)".*/\2/p' "$R/sources/relux-agents-infra/scripts/setup.sh"
  } | sort -u > "$R/manifest/binaries.txt"
  ls -1A "$R/sources/skill-project-management/.roles" | sort -u > "$R/manifest/roles.txt"
}
go() { for sh in bash zsh; do
    out=$(RECOVERY_ROOT="$W/p5r" $sh "$W/p5.frag" 2>&1); rc=$?
    printf '  %-5s exit=%-2s out=%s\n' "$sh" "$rc" "$(printf '%s' "$out" | tr '\n' ' ' | cut -c1-110)"
  done; }
echo "A control (manifest matches sources)"; setup; go
echo "B release added a binary"; setup; printf '\n  install_binary "tb-brandnew"\n' >> "$W/p5r/sources/skill-project-management/scripts/setup.sh"; go
echo "C release dropped a role"; setup; rm -rf "$W/p5r/sources/skill-project-management/.roles/$(head -1 "$W/p5r/manifest/roles.txt")"; go
echo "D PM setup.sh unreadable (partial read must NOT look like a match)"; setup; rm -f "$W/p5r/sources/skill-project-management/scripts/setup.sh"; go
echo "E .roles dir missing"; setup; rm -rf "$W/p5r/sources/skill-project-management/.roles"; go
