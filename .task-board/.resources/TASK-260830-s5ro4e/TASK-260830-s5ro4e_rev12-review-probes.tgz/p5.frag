# Both halves always: the released one from its release tree, the other from the snapshot source.
PM_SRC="$RECOVERY_ROOT/sources/skill-project-management"   # Steps 2/5: PM_SRC="$PM_RELEASE"
AI_SRC="$RECOVERY_ROOT/sources/relux-agents-infra"         # Steps 3/6: AI_SRC="$AI_RELEASE"
{ sed -nE 's/^[[:space:]]*install_binary "([^"]+)".*/\1/p' "$PM_SRC/scripts/setup.sh"
  sed -nE 's/^(BINARY_NAME|MODEL_HARNESS_BINARY_NAME)="([^"]+)".*/\2/p' "$AI_SRC/scripts/setup.sh"
} | sort -u > "$RECOVERY_ROOT/p5-binaries.txt"; test -s "$RECOVERY_ROOT/p5-binaries.txt"
ls -1A "$PM_SRC/.roles" | sort -u > "$RECOVERY_ROOT/p5-roles.txt"
diff <(sort -u "$RECOVERY_ROOT/manifest/binaries.txt") "$RECOVERY_ROOT/p5-binaries.txt"
diff <(sort -u "$RECOVERY_ROOT/manifest/roles.txt")    "$RECOVERY_ROOT/p5-roles.txt"
